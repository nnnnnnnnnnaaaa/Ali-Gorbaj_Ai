from __future__ import annotations

from pathlib import Path

import numpy as np

from media_quality import MediaQualityEngine


def test_corner_mask_shape_and_type(tmp_path: Path) -> None:
    engine = MediaQualityEngine(tmp_path)
    frame = np.zeros((240, 320, 3), dtype=np.uint8)
    frame[20:45, 260:315] = 255
    mask = engine.auto_corner_watermark_mask(frame)
    assert mask.shape == frame.shape[:2]
    assert mask.dtype == np.uint8
    assert int(mask.sum()) > 0


def test_clean_image_changes_detected_corner(tmp_path: Path) -> None:
    engine = MediaQualityEngine(tmp_path)
    frame = np.full((240, 320, 3), 120, dtype=np.uint8)
    frame[20:45, 260:315] = 255
    import cv2
    cleaned = engine.clean_image_array(frame)
    assert cleaned.shape == frame.shape
    assert int(np.abs(cleaned.astype(np.int16) - frame.astype(np.int16)).sum()) > 0


def test_musetalk_engine_can_be_constructed(tmp_path: Path) -> None:
    from musetalk import MuseTalkLocalEngine
    engine = MuseTalkLocalEngine(tmp_path)
    assert engine.REPO_URL.startswith("https://github.com/")
    assert engine.venv_python.name in {"python", "python.exe"}
