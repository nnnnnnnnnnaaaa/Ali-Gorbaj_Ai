from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

from media_quality import MediaQualityEngine


def _rect_to_pixels(rect: tuple[float, float, float, float], width: int, height: int) -> tuple[int, int, int, int]:
    x, y, w, h = rect
    x1 = max(0, min(width - 1, int(x * width)))
    y1 = max(0, min(height - 1, int(y * height)))
    x2 = max(x1 + 1, min(width, int((x + w) * width)))
    y2 = max(y1 + 1, min(height, int((y + h) * height)))
    return x1, y1, x2, y2


def auto_corner_overlay_mask(frame_bgr: np.ndarray, strength: int = 4) -> np.ndarray:
    if cv2 is None:
        raise RuntimeError("OpenCV غير مثبت.")
    engine = MediaQualityEngine()
    engine.env = {**engine.env, "AUTO_CLEANUP_INPAINT_RADIUS": str(max(3, int(strength) + 1))}
    return engine.auto_corner_watermark_mask(frame_bgr)


def cleanup_owned_image(
    input_path: str | Path,
    output_path: str | Path,
    rectangles: Iterable[tuple[float, float, float, float]] | None = None,
    auto_detect: bool = False,
) -> Path:
    if cv2 is None:
        raise RuntimeError("OpenCV غير مثبت.")
    image = cv2.imread(str(input_path), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("تعذر قراءة الصورة.")
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    h, w = mask.shape
    for rect in rectangles or []:
        x1, y1, x2, y2 = _rect_to_pixels(rect, w, h)
        mask[y1:y2, x1:x2] = 255
    if auto_detect:
        mask = cv2.bitwise_or(mask, auto_corner_overlay_mask(image))
    cleaned = cv2.inpaint(image, mask, 5, cv2.INPAINT_NS) if mask.any() else image
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(output), cleaned, [int(cv2.IMWRITE_PNG_COMPRESSION), 3]):
        raise RuntimeError("تعذر حفظ الصورة بعد المعالجة.")
    return output
