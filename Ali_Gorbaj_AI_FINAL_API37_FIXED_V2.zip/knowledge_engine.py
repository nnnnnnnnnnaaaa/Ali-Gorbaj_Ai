from __future__ import annotations

import hashlib
import json
import re
import threading
from functools import lru_cache
from pathlib import Path
from typing import Any

try:
    import chromadb
except ImportError:
    chromadb = None

try:
    import networkx as nx
except ImportError:
    nx = None

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None

DEFAULT_EMBEDDING_MODEL = "sentence-transformers/paraphrase-multilingual-mpnet-base-v2"
MAX_CHUNK_CHARS = 2400
CHUNK_OVERLAP_CHARS = 300
_GRAPH_LOCK = threading.RLock()


@lru_cache(maxsize=4)
def load_embedding_model(model_name: str, device: str) -> Any:
    if SentenceTransformer is None:
        raise RuntimeError("sentence-transformers غير مثبت.")
    return SentenceTransformer(model_name, device=device)


def chunk_text(text: str, max_chars: int = MAX_CHUNK_CHARS, overlap: int = CHUNK_OVERLAP_CHARS) -> list[str]:
    normalized = re.sub(r"\r\n?", "\n", text or "").strip()
    if not normalized:
        return []
    max_chars = max(400, int(max_chars))
    overlap = max(0, min(int(overlap), max_chars // 3))
    chunks: list[str] = []
    start = 0
    while start < len(normalized):
        end = min(len(normalized), start + max_chars)
        if end < len(normalized):
            candidates = [normalized.rfind("\n\n", start, end), normalized.rfind("\n", start, end), normalized.rfind(" ", start, end)]
            boundary = max(candidates)
            if boundary > start + max_chars // 2:
                end = boundary
        chunk = normalized[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(normalized):
            break
        start = max(0, end - overlap)
    return chunks


def stable_source_hash(source_name: str, text: str) -> str:
    digest = hashlib.sha256()
    digest.update(source_name.encode("utf-8", errors="ignore"))
    digest.update(b"\0")
    digest.update(text.encode("utf-8", errors="ignore"))
    return digest.hexdigest()


def _extract_entities(text: str, limit: int = 24) -> list[str]:
    arabic = re.findall(r"[\u0600-\u06FF]{3,}(?:\s+[\u0600-\u06FF]{3,}){0,2}", text or "")
    latin = re.findall(r"\b[A-Z][A-Za-z0-9_-]{2,}(?:\s+[A-Z][A-Za-z0-9_-]{2,}){0,2}\b", text or "")
    candidates = arabic + latin
    unique: list[str] = []
    seen: set[str] = set()
    for value in candidates:
        clean = re.sub(r"\s+", " ", value.strip())
        key = clean.casefold()
        if len(clean) < 3 or key in seen:
            continue
        seen.add(key)
        unique.append(clean[:180])
        if len(unique) >= limit:
            break
    return unique


def _detect_preferences(prompt: str) -> list[str]:
    patterns = [
        r"(?:أحب|احب|أفضل|افضل|يفضل|أفضل أن|افضل ان)\s+([^.!؟\n]{2,160})",
        r"(?:لا أحب|لا احب|لا أفضل|لا افضل|لا أريد|لا اريد)\s+([^.!؟\n]{2,160})",
    ]
    values: list[str] = []
    for pattern in patterns:
        values.extend(match.group(1).strip() for match in re.finditer(pattern, prompt or "", flags=re.IGNORECASE))
    return values[:8]


class KnowledgeEngine:
    def __init__(self, root: str | Path, user_id: int, embedding_model: str = DEFAULT_EMBEDDING_MODEL) -> None:
        if chromadb is None:
            raise RuntimeError("ChromaDB غير مثبت.")
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.user_id = int(user_id)
        self.embedding_model_name = embedding_model
        self._client = chromadb.PersistentClient(path=str(self.root / "chroma"))
        self._collection_name = f"user_{self.user_id}_knowledge"
        self._collection = self._client.get_or_create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine", "owner_user_id": str(self.user_id)},
        )
        self._graph_path = self.root / "graph" / f"user_{self.user_id}.json"
        self._graph_path.parent.mkdir(parents=True, exist_ok=True)
        self._graph = self._load_graph()

    def _load_graph(self) -> Any:
        if nx is None:
            return None
        if not self._graph_path.exists():
            return nx.MultiDiGraph()
        try:
            payload = json.loads(self._graph_path.read_text(encoding="utf-8"))
            graph = nx.node_link_graph(payload, directed=True, multigraph=True, edges="edges")
            return graph
        except Exception:
            return nx.MultiDiGraph()

    def _save_graph(self) -> None:
        if nx is None or self._graph is None:
            return
        with _GRAPH_LOCK:
            payload = nx.node_link_data(self._graph, edges="edges")
            temp_path = self._graph_path.with_suffix(".tmp")
            temp_path.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            temp_path.replace(self._graph_path)

    def _graph_add_source(self, source_name: str, source_kind: str, text: str, source_hash: str) -> None:
        if nx is None or self._graph is None:
            return
        source_id = f"source:{source_hash}"
        self._graph.add_node(source_id, label=source_name[:200], node_type="source", source_kind=source_kind[:80])
        for entity in _extract_entities(text):
            entity_id = f"entity:{entity.casefold()}"
            self._graph.add_node(entity_id, label=entity, node_type="entity")
            self._graph.add_edge(source_id, entity_id, relation="MENTIONS")
        self._save_graph()

    def _graph_add_interaction(self, prompt: str, answer: str, conversation_id: str) -> None:
        if nx is None or self._graph is None:
            return
        user_node = f"user:{self.user_id}"
        self._graph.add_node(user_node, label=f"user_{self.user_id}", node_type="user")
        source_id = f"interaction:{conversation_id}:{stable_source_hash(conversation_id, prompt + answer)[:16]}"
        self._graph.add_node(source_id, label="conversation interaction", node_type="interaction")
        self._graph.add_edge(user_node, source_id, relation="HAS_INTERACTION")
        for entity in _extract_entities(prompt):
            entity_id = f"entity:{entity.casefold()}"
            self._graph.add_node(entity_id, label=entity, node_type="entity")
            self._graph.add_edge(user_node, entity_id, relation="INTERESTED_IN")
            self._graph.add_edge(source_id, entity_id, relation="MENTIONS")
        for preference in _detect_preferences(prompt):
            pref_id = f"preference:{hashlib.sha256(preference.encode('utf-8')).hexdigest()[:20]}"
            self._graph.add_node(pref_id, label=preference, node_type="preference")
            relation = "PREFERS" if not re.search(r"\b(?:لا|ليس|لن)\b", prompt) else "DISLIKES"
            self._graph.add_edge(user_node, pref_id, relation=relation)
        for correction in re.findall(r"(?:الصحيح|التصحيح|صحح(?:ني|ه)?|بل الصحيح)[:：]?\s*([^.!؟\n]{2,180})", prompt or "", flags=re.IGNORECASE):
            corr_id = f"correction:{hashlib.sha256(correction.encode('utf-8')).hexdigest()[:20]}"
            self._graph.add_node(corr_id, label=correction.strip(), node_type="correction")
            self._graph.add_edge(user_node, corr_id, relation="CORRECTS")
        self._save_graph()

    def _model(self) -> Any:
        device = "cuda" if self._cuda_available() else "cpu"
        return load_embedding_model(self.embedding_model_name, device)

    @staticmethod
    def _cuda_available() -> bool:
        try:
            import torch
            return bool(torch.cuda.is_available())
        except Exception:
            return False

    def _embed(self, texts: list[str]) -> list[list[float]]:
        model = self._model()
        vectors = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
        return vectors.tolist()

    def source_exists(self, source_hash: str) -> bool:
        try:
            result = self._collection.get(where={"source_hash": source_hash}, limit=1, include=[])
            return bool(result.get("ids"))
        except Exception:
            return False

    def index_document(self, source_name: str, source_kind: str, text: str, source_hash: str | None = None) -> dict[str, Any]:
        clean = (text or "").strip()
        if not clean:
            return {"indexed": False, "chunks": 0, "source_hash": ""}
        source_hash = source_hash or stable_source_hash(source_name, clean)
        if self.source_exists(source_hash):
            self._graph_add_source(source_name, source_kind, clean, source_hash)
            return {"indexed": False, "chunks": 0, "source_hash": source_hash, "duplicate": True}
        chunks = chunk_text(clean)
        if not chunks:
            return {"indexed": False, "chunks": 0, "source_hash": source_hash}
        ids = [hashlib.sha256(f"{self.user_id}:{source_hash}:{index}".encode("utf-8")).hexdigest() for index in range(len(chunks))]
        metadatas = [
            {
                "user_id": str(self.user_id),
                "source_name": source_name[:500],
                "source_kind": source_kind[:100],
                "source_hash": source_hash,
                "chunk_index": index,
            }
            for index in range(len(chunks))
        ]
        embeddings = self._embed(chunks)
        self._collection.add(ids=ids, documents=chunks, metadatas=metadatas, embeddings=embeddings)
        self._graph_add_source(source_name, source_kind, clean, source_hash)
        return {"indexed": True, "chunks": len(chunks), "source_hash": source_hash, "duplicate": False}

    def index_interaction(self, prompt: str, answer: str, conversation_id: str) -> dict[str, Any]:
        text = f"سؤال المستخدم:\n{prompt.strip()}\n\nإجابة المساعد:\n{answer.strip()}"
        source_name = f"conversation:{conversation_id}"
        source_hash = stable_source_hash(source_name, text)
        result = self.index_document(source_name, "interaction", text, source_hash)
        self._graph_add_interaction(prompt, answer, conversation_id)
        return result

    def record_preference(self, preference: str) -> None:
        clean = (preference or "").strip()
        if not clean or nx is None or self._graph is None:
            return
        self._graph.add_node(f"user:{self.user_id}", label=f"user_{self.user_id}", node_type="user")
        node_id = f"preference:{hashlib.sha256(clean.encode('utf-8')).hexdigest()[:20]}"
        self._graph.add_node(node_id, label=clean[:180], node_type="preference")
        self._graph.add_edge(f"user:{self.user_id}", node_id, relation="PREFERS")
        self._save_graph()

    def record_correction(self, correction: str) -> None:
        clean = (correction or "").strip()
        if not clean or nx is None or self._graph is None:
            return
        self._graph.add_node(f"user:{self.user_id}", label=f"user_{self.user_id}", node_type="user")
        node_id = f"correction:{hashlib.sha256(clean.encode('utf-8')).hexdigest()[:20]}"
        self._graph.add_node(node_id, label=clean[:200], node_type="correction")
        self._graph.add_edge(f"user:{self.user_id}", node_id, relation="CORRECTS")
        self._save_graph()

    def query(self, query_text: str, n_results: int = 5) -> list[dict[str, Any]]:
        clean = (query_text or "").strip()
        if not clean or self._collection.count() <= 0:
            return []
        query_embedding = self._embed([clean])[0]
        result = self._collection.query(
            query_embeddings=[query_embedding],
            n_results=min(max(1, int(n_results)), self._collection.count()),
            include=["documents", "metadatas", "distances"],
        )
        documents = (result.get("documents") or [[]])[0]
        metadatas = (result.get("metadatas") or [[]])[0]
        distances = (result.get("distances") or [[]])[0]
        return [
            {"text": str(document), "metadata": metadata or {}, "distance": float(distance)}
            for document, metadata, distance in zip(documents, metadatas, distances)
        ]

    def graph_context(self, query_text: str, max_nodes: int = 12) -> str:
        if nx is None or self._graph is None:
            return ""
        entities = _extract_entities(query_text, limit=8)
        candidates: list[str] = []
        for entity in entities:
            node_id = f"entity:{entity.casefold()}"
            if node_id in self._graph:
                candidates.append(node_id)
        user_node = f"user:{self.user_id}"
        if user_node in self._graph:
            candidates.append(user_node)
        blocks: list[str] = []
        seen: set[str] = set()
        for source in candidates:
            for neighbor in list(self._graph.neighbors(source)):
                if neighbor in seen:
                    continue
                seen.add(neighbor)
                node_data = self._graph.nodes.get(neighbor, {})
                label = str(node_data.get("label", neighbor))
                relations = sorted(
                    {
                        str(edge_data.get("relation", "RELATED_TO"))
                        for source_node, target_node, edge_data in self._graph.out_edges(source, data=True)
                        if target_node == neighbor
                    }
                )
                relation = relations[0] if relations else "RELATED_TO"
                blocks.append(f"[KnowledgeGraph] {relation}: {label}")
                if len(blocks) >= max_nodes:
                    return "\n".join(blocks)
        return "\n".join(blocks)

    def context_for(self, query_text: str, n_results: int = 5, max_chars: int = 12000) -> str:
        vector_results = self.query(query_text, n_results=n_results)
        graph_text = self.graph_context(query_text)
        blocks: list[str] = []
        used = 0
        if graph_text:
            blocks.append(graph_text)
            used += len(graph_text) + 2
        for item in vector_results:
            source_name = str(item["metadata"].get("source_name", "مصدر معرفي"))
            text = item["text"].strip()
            block = f"[المصدر: {source_name}]\n{text}"
            remaining = max_chars - used
            if remaining <= 0:
                break
            block = block[:remaining]
            blocks.append(block)
            used += len(block) + 2
        return "\n\n".join(blocks)

    def stats(self) -> dict[str, int]:
        graph_nodes = int(self._graph.number_of_nodes()) if nx is not None and self._graph is not None else 0
        graph_edges = int(self._graph.number_of_edges()) if nx is not None and self._graph is not None else 0
        return {"chunks": int(self._collection.count()), "graph_nodes": graph_nodes, "graph_edges": graph_edges}

    def delete_all(self) -> None:
        try:
            self._client.delete_collection(self._collection.name)
        except Exception:
            pass
        self._collection = self._client.get_or_create_collection(
            name=self._collection.name,
            metadata={"hnsw:space": "cosine", "owner_user_id": str(self.user_id)},
        )
        if nx is not None:
            self._graph = nx.MultiDiGraph()
            self._save_graph()
