# AI Media Quality Pipeline

## Images

1. Generate with FLUX.1-dev when compatible CUDA VRAM is available.
2. Fall back to FLUX.1-schnell or the configured remote provider.
3. Request no-logo output where the provider exposes that control.
4. Run `MediaQualityEngine.process_image_bytes()` for PNG mastering.

## Spoken Video

1. Normalize speech to mono PCM 16 kHz with loudness control.
2. Normalize video to 25 FPS for the local lip-sync pipeline.
3. Prefer MuseTalk 1.5 when its local runtime and weights are available.
4. Fall back to Wav2Lip with VRAM-aware batch retries.
5. Master the final video using H.264 CRF 16 and AAC 320 kbps/48 kHz.
6. Use FFmpeg `+faststart` for web/mobile playback.

## Long Videos

Long generation is chunked so the diffusion model never has to hold the entire timeline in memory. Consecutive chunks share anchors and overlap frames; overlap is trimmed before concatenation.

## Safety of cleanup

The quality layer is intended for generated project outputs and overlays the application is authorized to process. It does not depend on guessing the ownership of arbitrary third-party media.
