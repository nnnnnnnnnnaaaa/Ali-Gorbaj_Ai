# Ali Gorbaj-AI — AI Runtime Architecture 2026

## Model tiers

The runtime uses a hardware-aware policy rather than forcing a single model on every machine.

- Image: `FLUX.1-dev` is preferred for quality; `FLUX.1-schnell` is the automatic recovery path for memory-constrained runs.
- Video: `CogVideoX1.5-5B` is preferred for text-to-video, `CogVideoX1.5-5B-I2V` for image-to-video, and `CogVideoX-Fun-V1.1-5b-Pose` for pose/control workloads. `CogVideoX-2b` is retained as an automatic memory fallback.
- PyTorch 2.14.x is the desktop/server inference core. TorchAO 0.18 adds native quantization and compile-friendly optimization.
- Android uses the separate ExecuTorch runtime for edge models because current Chaquopy Android wheels do not provide modern PyTorch 2.x as a drop-in Python package.

## Acceleration policy

At startup the engine detects CUDA, GPU count, compute capability, BF16 support, VRAM, and TorchAO availability. It enables TF32 and high matmul precision where applicable, selects BF16/FP16, applies TorchAO quantization when supported, uses model or sequential CPU offload according to VRAM, and can compile the transformer on sufficiently large GPUs.

CogVideoX 1.5 is generated at its model-native frame geometry and normalized back to the dimensions requested by the existing UI. The long-video pipeline generates valid model frame counts, overlaps segments through temporal anchors, concatenates, interpolates, and clamps the final output to the requested duration.

## Model cache

Models are downloaded lazily to `MODEL_ROOT`. `scripts/prefetch_models.py --best` prefetches the best models selected for detected hardware. The repository does not store model weights in Git history.

## Android

The Android project keeps the existing Streamlit/Python application source intact and adds an Android-side native execution layer. ExecuTorch is used for exportable edge models; large diffusion pipelines remain in the full desktop/server PyTorch runtime. This prevents a misleading APK which pretends to contain CUDA-class desktop PyTorch while actually lacking its native runtime.
