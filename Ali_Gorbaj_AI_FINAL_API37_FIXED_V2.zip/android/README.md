# Ali Gorbaj-AI Android

هذا المشروع يبني APK ذاتي التشغيل لواجهة Streamlit الأصلية. عند تشغيل APK يتم بدء Python + Streamlit محليًا داخل مساحة التطبيق ثم عرض الواجهة نفسها داخل WebView على localhost.

## متطلبات البناء

- Android Gradle Plugin 9.2.0
- Gradle 9.4.1
- JDK 17
- Python 3.10 على آلة البناء (يُثبت تلقائيًا في GitHub Actions)
- Chaquopy 17.0.0

## البناء عبر GitHub

لا تحتاج إلى تثبيت Android Studio. ارفع المستودع كما هو إلى GitHub؛ ملف `.github/workflows/android-apk.yml` يبني Release APK تلقائيًا.

## التشغيل على الهاتف

APK يشغل خادم Streamlit محليًا على `127.0.0.1:8501`، ثم يفتح الواجهة. لا توجد شاشة إدخال عنوان خادم.

## المصدر

`app.py` وملفات Python الأخرى في جذر المستودع هي مصدر الحقيقة ويتم نسخها تلقائيًا إلى موارد APK أثناء البناء، لذلك لا توجد نسخة يدوية ثانية من التطبيق قد تتعارض معها.

## Edge AI Runtime

The Android module includes `org.pytorch:executorch-android:1.5.1` and `EdgeModelRuntime.java` for verified `.pte` model execution. ExecuTorch supports XNNPACK CPU execution on Android and provides Android GPU/NPU backends such as Vulkan, Qualcomm, and MediaTek depending on build/device support.

Place verified `.pte` files in `app/src/main/assets/edge_models/` before building when an on-device edge model is required.
