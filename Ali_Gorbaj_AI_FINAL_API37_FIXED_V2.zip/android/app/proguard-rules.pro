# Application uses Android framework WebView APIs only; no custom keep rules are required.
