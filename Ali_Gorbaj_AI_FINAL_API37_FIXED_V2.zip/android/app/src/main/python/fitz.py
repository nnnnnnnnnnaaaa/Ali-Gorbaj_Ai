from __future__ import annotations

from io import BytesIO
from typing import Any


class _Page:
    def __init__(self, page: Any) -> None:
        self._page = page

    def get_text(self, mode: str = "text") -> str:
        return str(self._page.extract_text() or "")


class _Document:
    def __init__(self, source: Any) -> None:
        from pypdf import PdfReader
        if hasattr(source, "read"):
            self._reader = PdfReader(source)
        elif isinstance(source, (bytes, bytearray)):
            self._reader = PdfReader(BytesIO(bytes(source)))
        else:
            self._reader = PdfReader(str(source))

    def __enter__(self) -> "_Document":
        return self

    def __exit__(self, *_: Any) -> None:
        return None

    def __iter__(self):
        for page in self._reader.pages:
            yield _Page(page)

    def __len__(self) -> int:
        return len(self._reader.pages)

    @property
    def pages(self):
        return [_Page(page) for page in self._reader.pages]


def open(stream: Any = None, filetype: str | None = None, filename: str | None = None):
    if stream is None and filename is None:
        raise ValueError("fitz.open requires stream or filename")
    return _Document(stream if stream is not None else filename)
