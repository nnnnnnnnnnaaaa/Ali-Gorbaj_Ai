from __future__ import annotations

import json
import math
import re
import threading
from pathlib import Path
from typing import Any

_LOCK = threading.RLock()


def _cosine_distance(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 1.0
    aa = sum(float(x) * float(x) for x in a)
    bb = sum(float(x) * float(x) for x in b)
    if aa <= 0 or bb <= 0:
        return 1.0
    dot = sum(float(x) * float(y) for x, y in zip(a, b))
    return max(0.0, min(2.0, 1.0 - dot / math.sqrt(aa * bb)))


class Collection:
    def __init__(self, owner: "PersistentClient", name: str, metadata: dict[str, Any] | None = None) -> None:
        self._owner = owner
        self.name = name
        self.metadata = metadata or {}
        self._path = owner.root / f"{name}.json"
        self._data = {"ids": [], "documents": [], "metadatas": [], "embeddings": []}
        self._load()

    def _load(self) -> None:
        if self._path.exists():
            try:
                payload = json.loads(self._path.read_text(encoding="utf-8"))
                if isinstance(payload, dict):
                    self._data.update({key: payload.get(key, []) for key in self._data})
            except Exception:
                self._data = {"ids": [], "documents": [], "metadatas": [], "embeddings": []}

    def _save(self) -> None:
        self._owner.root.mkdir(parents=True, exist_ok=True)
        temp = self._path.with_suffix(".tmp")
        temp.write_text(json.dumps(self._data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        temp.replace(self._path)

    def count(self) -> int:
        with _LOCK:
            return len(self._data["ids"])

    def add(self, ids: list[str], documents: list[str], metadatas: list[dict[str, Any]], embeddings: list[list[float]]) -> None:
        if not (len(ids) == len(documents) == len(metadatas) == len(embeddings)):
            raise ValueError("ids/documents/metadatas/embeddings must have equal lengths")
        with _LOCK:
            existing = set(self._data["ids"])
            for item_id, document, metadata, embedding in zip(ids, documents, metadatas, embeddings):
                if item_id in existing:
                    continue
                self._data["ids"].append(str(item_id))
                self._data["documents"].append(str(document))
                self._data["metadatas"].append(dict(metadata or {}))
                self._data["embeddings"].append([float(value) for value in embedding])
                existing.add(str(item_id))
            self._save()

    def get(self, where: dict[str, Any] | None = None, limit: int | None = None, include: list[str] | None = None, **_: Any) -> dict[str, Any]:
        with _LOCK:
            indexes = list(range(len(self._data["ids"])))
            if where:
                indexes = [
                    index for index in indexes
                    if all(self._data["metadatas"][index].get(key) == value for key, value in where.items())
                ]
            if limit is not None:
                indexes = indexes[: max(0, int(limit))]
            result: dict[str, Any] = {"ids": [self._data["ids"][i] for i in indexes]}
            requested = include or ["documents", "metadatas", "embeddings"]
            if "documents" in requested:
                result["documents"] = [self._data["documents"][i] for i in indexes]
            if "metadatas" in requested:
                result["metadatas"] = [self._data["metadatas"][i] for i in indexes]
            if "embeddings" in requested:
                result["embeddings"] = [self._data["embeddings"][i] for i in indexes]
            return result

    def query(self, query_embeddings: list[list[float]], n_results: int = 5, include: list[str] | None = None, **_: Any) -> dict[str, Any]:
        include = include or ["documents", "metadatas", "distances"]
        with _LOCK:
            if not self._data["ids"]:
                return {"ids": [[]], "documents": [[]], "metadatas": [[]], "distances": [[]]}
            output = {"ids": [], "documents": [], "metadatas": [], "distances": []}
            for query in query_embeddings:
                ranking = [
                    (_cosine_distance(query, embedding), i)
                    for i, embedding in enumerate(self._data["embeddings"])
                ]
                ranking.sort(key=lambda item: item[0])
                selected = ranking[: max(1, min(int(n_results), len(ranking)))]
                output["ids"].append([self._data["ids"][i] for _, i in selected])
                output["documents"].append([self._data["documents"][i] for _, i in selected])
                output["metadatas"].append([self._data["metadatas"][i] for _, i in selected])
                output["distances"].append([float(distance) for distance, _ in selected])
            return output

    def delete(self, where: dict[str, Any] | None = None, ids: list[str] | None = None) -> None:
        with _LOCK:
            ids_set = set(ids or [])
            keep = []
            for i, item_id in enumerate(self._data["ids"]):
                matches_where = bool(where) and all(self._data["metadatas"][i].get(k) == v for k, v in (where or {}).items())
                should_delete = item_id in ids_set or matches_where
                if not should_delete:
                    keep.append(i)
            self._data = {
                "ids": [self._data["ids"][i] for i in keep],
                "documents": [self._data["documents"][i] for i in keep],
                "metadatas": [self._data["metadatas"][i] for i in keep],
                "embeddings": [self._data["embeddings"][i] for i in keep],
            }
            self._save()


class PersistentClient:
    def __init__(self, path: str, **_: Any) -> None:
        self.root = Path(path).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._collections: dict[str, Collection] = {}

    def get_or_create_collection(self, name: str, metadata: dict[str, Any] | None = None, **_: Any) -> Collection:
        with _LOCK:
            if name not in self._collections:
                self._collections[name] = Collection(self, name, metadata)
            return self._collections[name]

    def get_collection(self, name: str, **kwargs: Any) -> Collection:
        return self.get_or_create_collection(name, **kwargs)

    def delete_collection(self, name: str) -> None:
        with _LOCK:
            path = self.root / f"{name}.json"
            if path.exists():
                path.unlink()
            self._collections.pop(name, None)
