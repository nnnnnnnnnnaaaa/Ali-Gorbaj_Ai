from __future__ import annotations

__version__ = "0.0.0-android-compat"


class ArrowException(Exception):
    pass


ArrowInvalid = ArrowTypeError = ArrowNotImplementedError = ArrowMemoryError = ArrowException


def table(*args, **kwargs):
    raise RuntimeError("PyArrow dataframe operations are disabled in Android standalone mode.")


class Table:
    @classmethod
    def from_pandas(cls, *args, **kwargs):
        raise RuntimeError("PyArrow dataframe operations are disabled in Android standalone mode.")
