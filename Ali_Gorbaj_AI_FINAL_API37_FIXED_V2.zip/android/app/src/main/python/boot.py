from __future__ import annotations

import os
import runpy
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import NoReturn

_STARTED = False
_LOCK = threading.RLock()


def _configure_environment(app_dir: Path, port: int) -> None:
    app_dir = app_dir.resolve()
    runtime_root = Path(os.environ.get("HOME", str(app_dir.parent / "runtime"))).resolve()
    runtime_root.mkdir(parents=True, exist_ok=True)
    os.environ["HOME"] = str(runtime_root)
    os.environ["TMPDIR"] = str(runtime_root / "tmp")
    os.environ["TEMP"] = str(runtime_root / "tmp")
    os.environ["TMP"] = str(runtime_root / "tmp")
    Path(os.environ["TMPDIR"]).mkdir(parents=True, exist_ok=True)
    os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
    os.environ["STREAMLIT_SERVER_ADDRESS"] = "127.0.0.1"
    os.environ["STREAMLIT_SERVER_PORT"] = str(port)
    os.environ["STREAMLIT_SERVER_FILE_WATCHER_TYPE"] = "none"
    os.environ["STREAMLIT_BROWSER_GATHER_USAGE_STATS"] = "false"
    os.environ["STREAMLIT_SERVER_ENABLE_CORS"] = "false"
    os.environ["STREAMLIT_SERVER_ENABLE_XSRF_PROTECTION"] = "false"
    os.environ["STREAMLIT_SERVER_RUN_ON_SAVE"] = "false"
    os.environ["STREAMLIT_THEME_BASE"] = os.getenv("STREAMLIT_THEME_BASE", "dark")
    existing = [str(app_dir), str(app_dir / "android_compat")]
    for item in existing:
        if item not in sys.path:
            sys.path.insert(0, item)
    os.chdir(app_dir)


def _write_runtime_error(app_dir: Path, exc: BaseException) -> None:
    """Persist startup exceptions so the Android screen can explain failures."""
    error_file = app_dir / ".android_runtime_error.txt"
    try:
        error_file.write_text(
            f"{type(exc).__name__}: {exc}\n\n{traceback.format_exc()[-5000:]}",
            encoding="utf-8",
        )
    except Exception:
        pass


def start_streamlit(app_dir: str, port: int = 8501) -> None:
    """Start Streamlit in its own Python thread and return to Android immediately.

    The previous implementation called the blocking Streamlit CLI inline. That
    prevented the Java activity from starting its localhost health poll until the
    server exited, and it also hid the underlying exception behind a generic screen.
    """
    global _STARTED
    root = Path(app_dir).resolve()
    app_path = root / "app.py"
    if not app_path.is_file():
        raise FileNotFoundError(f"Streamlit app not found: {app_path}")
    with _LOCK:
        if _STARTED:
            return
        _STARTED = True

    error_file = root / ".android_runtime_error.txt"
    try:
        error_file.unlink(missing_ok=True)
    except OSError:
        pass
    _configure_environment(root, int(port))

    def run_server() -> None:
        global _STARTED
        try:
            from streamlit.web import bootstrap
            # Streamlit's CLI installs process signal handlers. Android lifecycle
            # owns this embedded server, and signal.signal may fail in an embedded
            #/worker-thread runtime; don't let that tear down server startup.
            if hasattr(bootstrap, "_set_up_signal_handler"):
                bootstrap._set_up_signal_handler = lambda _server: None
            bootstrap.run(str(app_path), False, [], {})
        except BaseException as exc:
            _write_runtime_error(root, exc)
            with _LOCK:
                _STARTED = False

    threading.Thread(
        target=run_server,
        name="ali-gorbaj-streamlit-server",
        daemon=True,
    ).start()
    # Give immediate import/configuration failures a chance to be recorded. The
    # Java activity performs the authoritative localhost health check afterwards.
    time.sleep(0.15)
    if error_file.is_file():
        detail = error_file.read_text(encoding="utf-8", errors="replace").strip()
        if detail:
            raise RuntimeError(detail[-2500:])


def health_probe(app_dir: str) -> dict[str, str | bool]:
    path = Path(app_dir).resolve() / "app.py"
    return {
        "app_exists": path.is_file(),
        "app_dir": str(path.parent),
        "python": sys.version,
    }
