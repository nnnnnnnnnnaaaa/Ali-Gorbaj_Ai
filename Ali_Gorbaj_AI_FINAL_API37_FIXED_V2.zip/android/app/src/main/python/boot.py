from __future__ import annotations

import os
import runpy
import sys
import threading
import time
from pathlib import Path
from typing import NoReturn

_STARTED = False
_LOCK = threading.RLock()


def _configure_environment(app_dir: Path, port: int) -> None:
    app_dir = app_dir.resolve()
    runtime_root = Path(os.environ.get("HOME", str(app_dir.parent / "runtime"))).resolve()
    runtime_root.mkdir(parents=True, exist_ok=True)
    os.environ["HOME"] = str(runtime_root)
    os.environ["TMPDIR"] = str(runtime_root / "tmp")
    os.environ["TEMP"] = str(runtime_root / "tmp")
    os.environ["TMP"] = str(runtime_root / "tmp")
    Path(os.environ["TMPDIR"]).mkdir(parents=True, exist_ok=True)
    os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
    os.environ["STREAMLIT_SERVER_ADDRESS"] = "127.0.0.1"
    os.environ["STREAMLIT_SERVER_PORT"] = str(port)
    os.environ["STREAMLIT_SERVER_FILE_WATCHER_TYPE"] = "none"
    os.environ["STREAMLIT_BROWSER_GATHER_USAGE_STATS"] = "false"
    os.environ["STREAMLIT_SERVER_ENABLE_CORS"] = "false"
    os.environ["STREAMLIT_SERVER_ENABLE_XSRF_PROTECTION"] = "false"
    os.environ["STREAMLIT_SERVER_RUN_ON_SAVE"] = "false"
    os.environ["STREAMLIT_THEME_BASE"] = os.getenv("STREAMLIT_THEME_BASE", "dark")
    existing = [str(app_dir), str(app_dir / "android_compat")]
    for item in existing:
        if item not in sys.path:
            sys.path.insert(0, item)
    os.chdir(app_dir)


def start_streamlit(app_dir: str, port: int = 8501) -> None:
    global _STARTED
    with _LOCK:
        if _STARTED:
            return
        _STARTED = True
    app_path = Path(app_dir).resolve() / "app.py"
    if not app_path.is_file():
        raise FileNotFoundError(f"Streamlit app not found: {app_path}")
    _configure_environment(Path(app_dir), int(port))
    sys.argv = [
        "streamlit",
        "run",
        str(app_path),
        "--server.address=127.0.0.1",
        f"--server.port={int(port)}",
        "--server.headless=true",
        "--server.fileWatcherType=none",
        "--browser.gatherUsageStats=false",
    ]
    from streamlit.web import cli
    cli.main()


def health_probe(app_dir: str) -> dict[str, str | bool]:
    path = Path(app_dir).resolve() / "app.py"
    return {
        "app_exists": path.is_file(),
        "app_dir": str(path.parent),
        "python": sys.version,
    }
