from __future__ import annotations

import hashlib
import math
import re
from typing import Any

try:
    import numpy as np
except Exception:
    np = None


class SentenceTransformer:
    """Deterministic multilingual hashing encoder for Android/offline RAG.

    It preserves the application's SentenceTransformer API without shipping a
    hundreds-of-megabytes neural encoder. The representation is stable between
    launches and handles Arabic/Latin/Unicode text directly.
    """

    def __init__(self, model_name: str, device: str = "cpu", **_: Any) -> None:
        self.model_name = model_name
        self.device = device
        self.dim = 384

    @staticmethod
    def _features(text: str) -> list[str]:
        normalized = re.sub(r"\s+", " ", (text or "").strip().casefold())
        tokens = re.findall(r"[\w\u0600-\u06ff]+", normalized, flags=re.UNICODE)
        pieces = [f"tok:{token}" for token in tokens]
        for token in tokens:
            for n in (2, 3, 4):
                pieces.extend(f"ng{n}:{token[i:i+n]}" for i in range(max(0, len(token) - n + 1)))
        return pieces or ["empty"]

    def encode(self, sentences: str | list[str], normalize_embeddings: bool = True, show_progress_bar: bool = False, **_: Any):
        values = [sentences] if isinstance(sentences, str) else list(sentences)
        vectors = []
        for text in values:
            vector = [0.0] * self.dim
            for feature in self._features(str(text)):
                digest = hashlib.blake2b(feature.encode("utf-8"), digest_size=8).digest()
                index = int.from_bytes(digest[:4], "big") % self.dim
                sign = 1.0 if digest[4] & 1 else -1.0
                weight = 1.0 + (digest[5] / 255.0)
                vector[index] += sign * weight
            if normalize_embeddings:
                norm = math.sqrt(sum(value * value for value in vector)) or 1.0
                vector = [value / norm for value in vector]
            vectors.append(vector)
        if np is not None:
            return np.asarray(vectors, dtype="float32")
        return vectors
