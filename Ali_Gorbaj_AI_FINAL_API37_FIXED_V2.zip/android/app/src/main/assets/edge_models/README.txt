Ali Gorbaj-AI Edge Model Pack
=============================

This directory is reserved for ExecuTorch .pte programs that have been
exported and verified for Android.

Recommended deployment path:
1. Export a compatible model to .pte with scripts/export_executorch_model.py.
2. Verify the model on the target Android ABI/device class.
3. Place the verified .pte file in this directory before the APK build.

The Android runtime uses ExecuTorch 1.5.1 and XNNPACK-compatible execution
through the official Maven AAR. Large desktop diffusion pipelines such as
FLUX and CogVideoX remain available through the full PyTorch/Diffusers
runtime in the Linux/CUDA production stack; they are not silently replaced by
smaller incompatible mobile models.
