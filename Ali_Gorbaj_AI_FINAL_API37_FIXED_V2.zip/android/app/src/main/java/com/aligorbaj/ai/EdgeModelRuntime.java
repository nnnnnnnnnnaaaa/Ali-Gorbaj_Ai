package com.aligorbaj.ai;

import org.pytorch.executorch.EValue;
import org.pytorch.executorch.Module;
import org.pytorch.executorch.Tensor;

import java.io.File;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Thread-safe Android edge inference wrapper.
 *
 * Models are supplied as ExecuTorch .pte programs. The class deliberately
 * does not alter the visible Streamlit experience; it is an execution layer
 * for packaged edge models and can be used by future native acceleration
 * paths without replacing the Python application.
 */
public final class EdgeModelRuntime implements AutoCloseable {
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private Module module;
    private String loadedPath = "";

    public EdgeModelRuntime() {
    }

    public boolean isLoaded() {
        lock.readLock().lock();
        try {
            return module != null;
        } finally {
            lock.readLock().unlock();
        }
    }

    public String getLoadedPath() {
        lock.readLock().lock();
        try {
            return loadedPath;
        } finally {
            lock.readLock().unlock();
        }
    }

    public void load(String modelPath) {
        File file = new File(modelPath);
        if (!file.isFile() || !file.canRead()) {
            throw new IllegalArgumentException("ExecuTorch model does not exist or is unreadable: " + modelPath);
        }
        lock.writeLock().lock();
        try {
            Module previous = module;
            module = null;
            loadedPath = "";
            if (previous != null) {
                previous.destroy();
            }
            module = Module.load(file.getAbsolutePath());
            loadedPath = file.getAbsolutePath();
        } catch (RuntimeException exception) {
            module = null;
            loadedPath = "";
            throw exception;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public float[] runFloatTensor(float[] input, long[] shape) {
        lock.readLock().lock();
        try {
            if (module == null) {
                throw new IllegalStateException("No ExecuTorch model is loaded.");
            }
            Tensor tensor = Tensor.fromBlob(input, shape);
            EValue inputValue = EValue.from(tensor);
            EValue[] output = module.forward(inputValue);
            if (output == null || output.length == 0 || output[0] == null) {
                throw new IllegalStateException("ExecuTorch model returned no output.");
            }
            return output[0].toTensor().getDataAsFloatArray();
        } finally {
            lock.readLock().unlock();
        }
    }

    @Override
    public void close() {
        lock.writeLock().lock();
        try {
            if (module != null) {
                module.destroy();
                module = null;
                loadedPath = "";
            }
        } finally {
            lock.writeLock().unlock();
        }
    }
}
