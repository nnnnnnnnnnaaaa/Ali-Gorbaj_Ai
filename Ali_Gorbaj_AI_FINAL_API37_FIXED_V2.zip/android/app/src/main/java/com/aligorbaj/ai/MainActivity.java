package com.aligorbaj.ai;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.AndroidPlatform;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int REQUEST_MEDIA_PERMISSIONS = 1407;
    private static final int REQUEST_FILE_CHOOSER = 1408;
    private static final String LOCAL_URL = "http://localhost:8501";
    private static final int LOCAL_PORT = 8501;
    private static final int HEALTH_TIMEOUT_MS = 600;
    private static final long HEALTH_POLL_MS = 450L;
    private static final long STARTUP_TIMEOUT_MS = 45000L;
    private static final String ASSET_ROOT = "python_app";
    private static final String RUNTIME_DIR = "python_app";
    private static final String RUNTIME_MARKER = ".runtime_build";

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private PermissionRequest pendingPermissionRequest;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService runtimeExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean pythonStarted = false;
    private volatile boolean webAppOpened = false;
    private long startupDeadline;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(26, 26, 26));
        getWindow().setNavigationBarColor(Color.BLACK);
        ensureRuntimePermissions();
        showRuntimeView("جاري تشغيل Ali Gorbaj-AI…");
        startupDeadline = System.currentTimeMillis() + STARTUP_TIMEOUT_MS;
        startLocalRuntime();
    }

    private void startLocalRuntime() {
        runtimeExecutor.submit(() -> {
            try {
                copyRuntimeAssets();
                startPythonRuntime();
                mainHandler.post(this::pollLocalHealth);
            } catch (Throwable throwable) {
                android.util.Log.e("AliGorbajAI", "Local runtime failed", throwable);
                mainHandler.post(() -> showRuntimeView("جاري إعادة تشغيل محرك التطبيق…"));
                mainHandler.postDelayed(this::fallbackToBuiltInOrDiscovery, 2000L);
            }
        });
    }

    private void startPythonRuntime() {
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        pythonStarted = true;
        Python python = Python.getInstance();
        PyObject boot = python.getModule("boot");
        File appDir = new File(getFilesDir(), RUNTIME_DIR);
        boot.callAttr("health_probe", appDir.getAbsolutePath());
        boot.callAttr("start_streamlit", appDir.getAbsolutePath(), LOCAL_PORT);
    }

    private void copyRuntimeAssets() throws IOException {
        File target = new File(getFilesDir(), RUNTIME_DIR);
        target.mkdirs();
        String expectedMarker = BuildConfig.VERSION_NAME + ":" + BuildConfig.VERSION_CODE;
        File marker = new File(target, RUNTIME_MARKER);
        String actual = marker.isFile() ? readText(marker).trim() : "";
        if (!expectedMarker.equals(actual) || !new File(target, "app.py").isFile()) {
            deleteChildrenExceptMarker(target);
            copyAssetTree(ASSET_ROOT, target);
            writeText(marker, expectedMarker);
        }
    }

    private void deleteChildrenExceptMarker(File directory) {
        File[] children = directory.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.getName().equals(RUNTIME_MARKER)) continue;
            deleteRecursively(child);
        }
    }

    private void deleteRecursively(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) deleteRecursively(child);
            }
        }
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }

    private void copyAssetTree(String assetPath, File destination) throws IOException {
        String[] children = getAssets().list(assetPath);
        if (children == null || children.length == 0) {
            copyAssetFile(assetPath, destination);
            return;
        }
        if (!destination.exists() && !destination.mkdirs()) {
            throw new IOException("Unable to create " + destination);
        }
        for (String child : children) {
            File childDest = new File(destination, child);
            String childAsset = assetPath + "/" + child;
            String[] grandChildren = getAssets().list(childAsset);
            if (grandChildren != null && grandChildren.length > 0) {
                copyAssetTree(childAsset, childDest);
            } else {
                copyAssetFile(childAsset, childDest);
            }
        }
    }

    private void copyAssetFile(String assetPath, File destination) throws IOException {
        File parent = destination.getParentFile();
        if (parent != null) parent.mkdirs();
        try (InputStream input = getAssets().open(assetPath); OutputStream output = new FileOutputStream(destination)) {
            byte[] buffer = new byte[32768];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
        }
    }

    private String readText(File file) throws IOException {
        try (FileInputStream input = new FileInputStream(file)) {
            byte[] buffer = new byte[(int) Math.min(file.length(), 4096)];
            int read = input.read(buffer);
            return read <= 0 ? "" : new String(buffer, 0, read, java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    private void writeText(File file, String value) throws IOException {
        try (FileOutputStream output = new FileOutputStream(file, false)) {
            output.write(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }
    }

    private void pollLocalHealth() {
        if (webAppOpened || isFinishing()) return;
        runtimeExecutor.submit(() -> {
            boolean healthy = probeHealth(LOCAL_URL);
            mainHandler.post(() -> {
                if (healthy) {
                    openWebApp(LOCAL_URL);
                } else if (System.currentTimeMillis() < startupDeadline) {
                    mainHandler.postDelayed(this::pollLocalHealth, HEALTH_POLL_MS);
                } else {
                    showRuntimeView("تعذر تشغيل المحرك المحلي، تتم إعادة المحاولة تلقائيًا…");
                    mainHandler.postDelayed(this::restartLocalRuntime, 2500L);
                }
            });
        });
    }

    private void restartLocalRuntime() {
        if (isFinishing() || webAppOpened) return;
        startupDeadline = System.currentTimeMillis() + STARTUP_TIMEOUT_MS;
        startLocalRuntime();
    }

    private boolean probeHealth(String baseUrl) {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(baseUrl + "/_stcore/health");
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(HEALTH_TIMEOUT_MS);
            connection.setReadTimeout(HEALTH_TIMEOUT_MS);
            connection.setRequestMethod("GET");
            connection.setInstanceFollowRedirects(false);
            int code = connection.getResponseCode();
            if (code != HttpURLConnection.HTTP_OK) return false;
            return true;
        } catch (Exception ignored) {
            return false;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void fallbackToBuiltInOrDiscovery() {
        String configured = BuildConfig.STREAMLIT_APP_URL == null ? "" : BuildConfig.STREAMLIT_APP_URL.trim();
        if (isValidUrl(configured)) {
            openWebApp(configured);
        } else {
            showRuntimeView("تعذر بدء المحرك المحلي. أعد فتح التطبيق لإعادة المحاولة.");
        }
    }

    private void showRuntimeView(String messageText) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(32), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(11, 13, 18));

        TextView title = new TextView(this);
        title.setText(getString(R.string.app_name));
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView message = new TextView(this);
        message.setText(messageText);
        message.setTextColor(Color.LTGRAY);
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);
        message.setPadding(0, dp(16), 0, dp(20));

        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminate(true);

        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(message, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }

    private void openWebApp(String url) {
        if (webAppOpened && webView != null) {
            webView.loadUrl(url);
            return;
        }
        webAppOpened = true;
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUserAgentString(settings.getUserAgentString() + " AliGorbajAI/Standalone-2026");

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, false);

        final String allowedHost = Uri.parse(url).getHost();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                String scheme = target.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    String host = target.getHost();
                    boolean sameHost = host != null && allowedHost != null && host.equalsIgnoreCase(allowedHost);
                    boolean localHttp = "http".equalsIgnoreCase(scheme) && isLocalHost(host);
                    boolean sameHostHttps = "https".equalsIgnoreCase(scheme) && sameHost;
                    if (localHttp || sameHostHttps) return false;
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, target));
                    } catch (Exception ignored) {
                        Toast.makeText(MainActivity.this, "لا يوجد تطبيق لمعالجة هذا الرابط", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, target));
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "لا يوجد تطبيق لمعالجة هذا الرابط", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                if ("http".equalsIgnoreCase(target.getScheme()) && !isLocalHost(target.getHost())) {
                    return new WebResourceResponse("text/plain", "utf-8", null);
                }
                return super.shouldInterceptRequest(view, request);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    pendingPermissionRequest = request;
                    requestAndroidMediaPermissionsIfNeeded(request);
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = filePathCallback;
                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                } catch (Exception ignored) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.setType("*/*");
                }
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(intent, REQUEST_FILE_CHOOSER);
                } catch (Exception e) {
                    fileChooserCallback = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح منتقي الملفات", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String downloadUrl, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                try {
                    Uri downloadUri = Uri.parse(downloadUrl);
                    String scheme = downloadUri.getScheme();
                    if (!("https".equalsIgnoreCase(scheme) || ("http".equalsIgnoreCase(scheme) && isLocalHost(downloadUri.getHost())))) {
                        Toast.makeText(MainActivity.this, "رابط التنزيل غير مسموح", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    DownloadManager.Request request = new DownloadManager.Request(downloadUri);
                    request.setMimeType(mimetype);
                    String cookies = CookieManager.getInstance().getCookie(downloadUrl);
                    if (cookies != null) request.addRequestHeader("Cookie", cookies);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, guessFilename(downloadUrl, contentDisposition));
                    DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (manager != null) {
                        manager.enqueue(request);
                        Toast.makeText(MainActivity.this, "بدأ تنزيل الملف", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "تعذر تنزيل الملف", Toast.LENGTH_SHORT).show();
                }
            }
        });

        setContentView(webView);
        webView.loadUrl(url);
    }

    private boolean isValidUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            if (scheme == null || host == null) return false;
            if ("https".equalsIgnoreCase(scheme)) return true;
            return "http".equalsIgnoreCase(scheme) && isLocalHost(host);
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean isLocalHost(String host) {
        if (host == null) return false;
        String normalized = host.toLowerCase(Locale.ROOT);
        return normalized.equals("localhost") || normalized.equals("127.0.0.1") || normalized.equals("10.0.2.2");
    }

    private String guessFilename(String url, String contentDisposition) {
        if (contentDisposition != null) {
            String marker = "filename=";
            int index = contentDisposition.toLowerCase(Locale.ROOT).indexOf(marker);
            if (index >= 0) {
                String value = contentDisposition.substring(index + marker.length()).replace("\"", "").trim();
                if (!value.isEmpty()) return value;
            }
        }
        String path = Uri.parse(url).getLastPathSegment();
        return (path == null || path.isEmpty()) ? "download" : path;
    }

    private void ensureRuntimePermissions() {
        if (android.os.Build.VERSION.SDK_INT < 23) return;
        boolean camera = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean audio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (!camera || !audio) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQUEST_MEDIA_PERMISSIONS);
        }
    }

    private void requestAndroidMediaPermissionsIfNeeded(PermissionRequest request) {
        boolean needsCamera = false;
        boolean needsAudio = false;
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) needsCamera = true;
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) needsAudio = true;
        }
        boolean cameraGranted = !needsCamera || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean audioGranted = !needsAudio || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (cameraGranted && audioGranted) {
            request.grant(request.getResources());
            pendingPermissionRequest = null;
            return;
        }
        requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQUEST_MEDIA_PERMISSIONS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_MEDIA_PERMISSIONS || pendingPermissionRequest == null) return;
        boolean camera = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean audio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        for (String resource : pendingPermissionRequest.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && camera) continue;
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && audio) continue;
            pendingPermissionRequest.deny();
            pendingPermissionRequest = null;
            return;
        }
        pendingPermissionRequest.grant(pendingPermissionRequest.getResources());
        pendingPermissionRequest = null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_FILE_CHOOSER || fileChooserCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        fileChooserCallback.onReceiveValue(results);
        fileChooserCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        runtimeExecutor.shutdownNow();
        if (webView != null) {
            webView.stopLoading();
            webView.clearHistory();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
