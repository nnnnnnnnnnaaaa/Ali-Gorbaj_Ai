from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Any

import streamlit as st
import streamlit.components.v1 as components

_COMPONENT_DIR = Path(__file__).resolve().parent / "components" / "omni_capture"
_omni_component = components.declare_component("omni_capture", path=str(_COMPONENT_DIR))


def omni_capture(
    key: str,
    enabled: bool,
    interval_ms: int = 1500,
    jpeg_quality: float = 0.55,
    width: int = 640,
    include_system_audio: bool = False,
    websocket_url: str = "",
    language: str = "auto",
    dialect: str = "auto",
    default: Any | None = None,
) -> dict[str, Any] | None:
    if not enabled:
        return default
    value = _omni_component(
        key=key,
        intervalMs=int(interval_ms),
        jpegQuality=float(jpeg_quality),
        frameWidth=int(width),
        includeSystemAudio=bool(include_system_audio),
        websocketUrl=str(websocket_url),
        language=str(language),
        dialect=str(dialect),
        default=default or {},
        height=580,
    )
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            return default
    if not isinstance(value, dict):
        return default
    return value


def data_url_to_bytes(value: str) -> bytes:
    if not value or "," not in value:
        return b""
    encoded = value.split(",", 1)[1]
    return base64.b64decode(encoded)


def decode_data_url(value: str) -> tuple[bytes, str]:
    if not value or "," not in value:
        return b"", "application/octet-stream"
    header, encoded = value.split(",", 1)
    mime = header[5:].split(";", 1)[0] if header.startswith("data:") else "application/octet-stream"
    return base64.b64decode(encoded), mime


def compact_event(event: dict[str, Any] | None) -> dict[str, Any]:
    if not event:
        return {}
    return {key: event.get(key) for key in ("timestamp", "camera_frame", "screen_frame", "fused_frame", "audio_chunk", "audio_mime", "status") if key in event}
