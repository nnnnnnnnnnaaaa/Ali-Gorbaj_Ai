from __future__ import annotations

import base64
import hashlib
import hmac
import importlib.util
import json
import os
from pathlib import Path

import pytest


def test_module_imports() -> None:
    for name in ["long_video_engine", "task_queue", "realtime_gateway", "knowledge_engine", "controlled_generation", "omni_multimodal", "hardware", "lipsync", "owned_media_cleanup", "swarm_orchestrator"]:
        assert importlib.util.find_spec(name) is not None


def test_token_roundtrip() -> None:
    secret = b"unit-test-secret"
    uid = 7
    exp = 9999999999
    sig = hmac.new(secret, f"{uid}:{exp}".encode("utf-8"), hashlib.sha256).hexdigest()
    token = base64.urlsafe_b64encode(json.dumps({"uid": uid, "exp": exp, "sig": sig}, separators=(",", ":")).encode("utf-8")).decode("ascii").rstrip("=")
    raw = base64.urlsafe_b64decode(token + "=" * (-len(token) % 4))
    payload = json.loads(raw.decode("utf-8"))
    assert payload["uid"] == uid
    assert hmac.compare_digest(payload["sig"], sig)


def test_config_bounds() -> None:
    try:
        from long_video_engine import LongVideoConfig
    except ModuleNotFoundError as exc:
        pytest.skip(f"optional ML dependency not installed in lightweight CI: {exc}")
    cfg = LongVideoConfig()
    assert 1 <= cfg.fps <= 60
    assert 1 <= cfg.chunk_seconds <= 30
    assert 1 <= cfg.max_seconds <= 3600


def test_hardware_profile_shape() -> None:
    try:
        from hardware import detect_hardware
    except ModuleNotFoundError as exc:
        pytest.skip(f"optional hardware dependency not installed in lightweight CI: {exc}")
    profile = detect_hardware()
    assert profile.device in {"cpu", "cuda", "mps"}
    assert profile.cpu_count >= 1
    assert profile.recommended_video_chunk_seconds >= 1


def test_owned_overlay_detector_is_scoped() -> None:
    try:
        import numpy as np
        from owned_media_cleanup import auto_corner_overlay_mask
    except ModuleNotFoundError as exc:
        pytest.skip(f"optional vision dependency not installed in lightweight CI: {exc}")
    frame = np.zeros((120, 160, 3), dtype=np.uint8)
    mask = auto_corner_overlay_mask(frame)
    assert mask.shape == frame.shape[:2]
    assert mask.dtype == np.uint8


def test_edge_runtime_module_shape() -> None:
    from edge_runtime import EdgeModelRecord, discover_edge_models
    assert "name" in EdgeModelRecord.__annotations__
    assert isinstance(discover_edge_models(), list)


def test_model_catalog_has_quality_tiers() -> None:
    from model_manager import MODEL_CATALOG
    names = {item.name for item in MODEL_CATALOG}
    assert "flux-dev" in names
    assert "cogvideox-1.5-5b" in names
    assert "cogvideox-1.5-5b-i2v" in names
