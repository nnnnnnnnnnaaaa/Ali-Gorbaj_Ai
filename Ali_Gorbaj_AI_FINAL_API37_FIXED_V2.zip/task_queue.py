from __future__ import annotations

import os
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent / ".env", override=False)
except Exception:
    pass

try:
    from celery import Celery
except ImportError:
    Celery = None

from long_video_engine import get_long_video_engine
from media_quality import MediaQualityEngine

try:
    import requests
except ImportError:
    requests = None

BROKER_URL = os.getenv("CELERY_BROKER_URL", os.getenv("REDIS_URL", "")).strip()
RESULT_BACKEND = os.getenv("CELERY_RESULT_BACKEND", BROKER_URL).strip()
TASK_ALWAYS_EAGER = os.getenv("CELERY_TASK_ALWAYS_EAGER", "0").lower() in {"1", "true", "yes", "on"}

celery_app = None
if Celery is not None and BROKER_URL:
    celery_app = Celery("nova_enterprise_ai", broker=BROKER_URL, backend=RESULT_BACKEND or BROKER_URL)
    celery_app.conf.update(
        task_serializer="json",
        result_serializer="json",
        accept_content=["json"],
        task_track_started=True,
        task_acks_late=True,
        task_reject_on_worker_lost=True,
        worker_prefetch_multiplier=1,
        worker_max_tasks_per_child=max(1, int(os.getenv("CELERY_MAX_TASKS_PER_CHILD", "1"))),
        worker_disable_rate_limits=True,
        task_compression=os.getenv("CELERY_TASK_COMPRESSION", "gzip"),
        result_compression=os.getenv("CELERY_RESULT_COMPRESSION", "gzip"),
        broker_connection_retry_on_startup=True,
        task_default_queue=os.getenv("CELERY_DEFAULT_QUEUE", "ai-heavy"),
        result_expires=int(os.getenv("CELERY_RESULT_EXPIRES", "86400")),
        broker_transport_options={"visibility_timeout": int(os.getenv("CELERY_VISIBILITY_TIMEOUT", "21600"))},
        result_backend_transport_options={"global_keyprefix": os.getenv("CELERY_RESULT_KEY_PREFIX", "nova:")},
        task_soft_time_limit=int(os.getenv("CELERY_SOFT_TIME_LIMIT", "7200")),
        task_time_limit=int(os.getenv("CELERY_TIME_LIMIT", "7800")),
    )
    celery_app.conf.task_always_eager = TASK_ALWAYS_EAGER

_executor = ThreadPoolExecutor(max_workers=max(1, int(os.getenv("LOCAL_BACKGROUND_WORKERS", "1"))))
_local_lock = threading.Lock()
_local_tasks: dict[str, dict[str, Any]] = {}


def _update_local(task_id: str, state: str, progress: int, message: str = "", result: Any = None, error: str = "") -> None:
    with _local_lock:
        current = _local_tasks.get(task_id, {})
        current.update({"state": state, "progress": int(progress), "message": message, "result": result, "error": error})
        _local_tasks[task_id] = current


def _pollinations_image_request(prompt: str, kwargs: dict[str, Any]) -> tuple[str, dict[str, str]]:
    quality = str(kwargs.get("quality", "high")).lower()
    quality_suffix = {
        "standard": "high quality, clean composition",
        "high": "highly detailed, crisp focus, professional lighting",
        "ultra": "ultra-detailed, cinematic, crisp micro-textures, professional color grading",
    }.get(quality, "highly detailed, crisp focus, professional lighting")
    enhanced_prompt = f"{prompt.strip()}, {quality_suffix}"
    params = {
        "model": str(kwargs.get("model", "flux")),
        "width": str(int(kwargs.get("width", 1024))),
        "height": str(int(kwargs.get("height", 1024))),
        "enhance": "true" if kwargs.get("enhance", True) else "false",
        "nologo": "true",
        "safe": "true",
    }
    import urllib.parse
    url = "https://gen.pollinations.ai/image/" + urllib.parse.quote(enhanced_prompt, safe="")
    return url, params


def _run_local_long_video(task_id: str, kwargs: dict[str, Any]) -> dict[str, Any]:
    _update_local(task_id, "STARTED", 1, "بدأت مهمة الفيديو الطويل")
    engine = get_long_video_engine(str(kwargs["work_root"]))
    try:
        result = engine.generate(progress=lambda p, m: _update_local(task_id, "PROGRESS", p, m), **{k: v for k, v in kwargs.items() if k != "work_root"})
        _update_local(task_id, "SUCCESS", 100, "اكتملت المهمة", result=result)
        return result
    except Exception as exc:
        _update_local(task_id, "FAILURE", 100, "فشلت المهمة", error=str(exc))
        raise


def _run_local_pollinations_image(task_id: str, kwargs: dict[str, Any]) -> dict[str, Any]:
    _update_local(task_id, "STARTED", 1, "بدأت مهمة الصورة")
    if requests is None:
        error = "requests غير مثبتة."
        _update_local(task_id, "FAILURE", 100, "فشلت المهمة", error=error)
        raise RuntimeError(error)
    api_key = os.getenv("POLLINATIONS_API_KEY", "").strip()
    if not api_key:
        error = "POLLINATIONS_API_KEY غير مضبوط."
        _update_local(task_id, "FAILURE", 100, "فشلت المهمة", error=error)
        raise RuntimeError(error)
    prompt = str(kwargs.get("prompt", "")).strip()
    if not prompt:
        error = "وصف الصورة فارغ."
        _update_local(task_id, "FAILURE", 100, "فشلت المهمة", error=error)
        raise ValueError(error)
    url, params = _pollinations_image_request(prompt, kwargs)
    _update_local(task_id, "PROGRESS", 25, "إرسال الصورة إلى Pollinations")
    response = requests.get(url, headers={"Authorization": f"Bearer {api_key}"}, params=params, timeout=(10, 300))
    response.raise_for_status()
    jobs_root = Path(str(kwargs["work_root"])).resolve()
    jobs_root.mkdir(parents=True, exist_ok=True)
    output_path = jobs_root / f"image_{uuid.uuid4().hex}.png"
    output_path.write_bytes(response.content)
    cleaned_path = output_path.with_name(output_path.stem + "_clean.png")
    quality = MediaQualityEngine(jobs_root / "quality")
    cleaned_bytes = quality.process_image_bytes(output_path.read_bytes(), "PNG")
    cleaned_path.write_bytes(cleaned_bytes)
    output_path.unlink(missing_ok=True)
    output_path = cleaned_path
    result = {"path": str(output_path), "mime_type": "image/png"}
    _update_local(task_id, "SUCCESS", 100, "اكتملت الصورة", result=result)
    return result


if celery_app is not None:
    @celery_app.task(bind=True, name="nova.generate_pollinations_image", autoretry_for=(RuntimeError,), retry_backoff=True, retry_kwargs={"max_retries": 1})
    def generate_pollinations_image_task(self: Any, **kwargs: Any) -> dict[str, Any]:
        if requests is None:
            raise RuntimeError("requests غير مثبتة.")
        api_key = os.getenv("POLLINATIONS_API_KEY", "").strip()
        if not api_key:
            raise RuntimeError("POLLINATIONS_API_KEY غير مضبوط.")
        prompt = str(kwargs.get("prompt", "")).strip()
        if not prompt:
            raise ValueError("وصف الصورة فارغ.")
        url, params = _pollinations_image_request(prompt, kwargs)
        self.update_state(state="PROGRESS", meta={"progress": 25, "message": "إرسال الصورة إلى Pollinations"})
        response = requests.get(url, headers={"Authorization": f"Bearer {api_key}"}, params=params, timeout=(10, 300))
        response.raise_for_status()
        jobs_root = Path(str(kwargs["work_root"])).resolve()
        jobs_root.mkdir(parents=True, exist_ok=True)
        output_path = jobs_root / f"image_{uuid.uuid4().hex}.png"
        output_path.write_bytes(response.content)
        quality = MediaQualityEngine(jobs_root / "quality")
        cleaned_bytes = quality.process_image_bytes(output_path.read_bytes(), "PNG")
        output_path.write_bytes(cleaned_bytes)
        self.update_state(state="PROGRESS", meta={"progress": 100, "message": "اكتملت الصورة"})
        return {"path": str(output_path), "mime_type": "image/png"}

if celery_app is not None:
    @celery_app.task(bind=True, name="nova.generate_long_video", autoretry_for=(RuntimeError,), retry_backoff=True, retry_kwargs={"max_retries": 1})
    def generate_long_video_task(self: Any, **kwargs: Any) -> dict[str, Any]:
        def progress_callback(percent: int, message: str) -> None:
            self.update_state(state="PROGRESS", meta={"progress": int(percent), "message": message})
        engine = get_long_video_engine(str(kwargs["work_root"]))
        return engine.generate(progress=progress_callback, **{k: v for k, v in kwargs.items() if k != "work_root"})


if celery_app is not None:
    def enqueue_long_video(**kwargs: Any) -> str:
        async_result = generate_long_video_task.delay(**kwargs)
        return str(async_result.id)
else:
    def enqueue_long_video(**kwargs: Any) -> str:
        task_id = uuid.uuid4().hex
        _update_local(task_id, "PENDING", 0, "بانتظار عامل محلي")
        _executor.submit(_run_local_long_video, task_id, kwargs)
        return task_id


def enqueue_pollinations_image(**kwargs: Any) -> str:
    if celery_app is not None:
        async_result = generate_pollinations_image_task.delay(**kwargs)
        return str(async_result.id)
    task_id = uuid.uuid4().hex
    _update_local(task_id, "PENDING", 0, "بانتظار عامل محلي")
    _executor.submit(_run_local_pollinations_image, task_id, kwargs)
    return task_id


def task_state(task_id: str) -> dict[str, Any]:
    if celery_app is not None:
        result = celery_app.AsyncResult(task_id)
        info = result.info if isinstance(result.info, dict) else {}
        if result.state == "PROGRESS":
            return {"state": result.state, "progress": int(info.get("progress", 0)), "message": str(info.get("message", "")), "result": None, "error": ""}
        if result.state == "SUCCESS":
            return {"state": result.state, "progress": 100, "message": "اكتملت المهمة", "result": result.result, "error": ""}
        if result.state == "FAILURE":
            return {"state": result.state, "progress": 100, "message": "فشلت المهمة", "result": None, "error": str(result.result)}
        return {"state": result.state, "progress": 0, "message": "بانتظار العامل...", "result": None, "error": ""}
    with _local_lock:
        return dict(_local_tasks.get(task_id, {"state": "UNKNOWN", "progress": 0, "message": "", "result": None, "error": "مهمة غير معروفة"}))
