# Nova Enterprise AI — Ultimate Production Architecture 2026

منصة AI متعددة الوسائط مبنية بـ Python، Streamlit، FastAPI، Celery، Redis، ChromaDB، NetworkX، Diffusers وXTTS-v2، مع فصل الواجهة عن الأعمال الثقيلة، وطبقة WebSocket للإدراك منخفض الكمون، ومحرك فيديو طويل قائم على التقسيم الزمني.

**المطور الرئيسي:** Ali Ahmed Gorbaj  
**الإصدار:** `2026.10-Ultimate-Production-MaxQuality`

> المشروع مُصمم ليكون أساسًا تجاريًا قويًا وقابلًا للتوسع، لكن لا يمكن ضمان حرفيًا "صفر أخطاء" على كل جهاز أو كل بنية سحابية؛ النماذج الثقيلة، تعريفات GPU، تراخيص الأوزان، الشبكات وحدود مزودي الخدمات الخارجية عوامل تشغيلية يجب اختبارها في بيئة الإطلاق نفسها.

## المعمارية

```text
                         ┌─────────────────────────┐
                         │        Browser          │
                         │ Camera / Mic / Screen   │
                         └────────────┬────────────┘
                                      │ WebSocket
                                      ▼
┌───────────────────┐        ┌─────────────────────────┐
│     Streamlit     │───────▶│   FastAPI Realtime      │
│ UI / Auth / Chat  │        │   Omni WebSocket GW      │
└────────┬──────────┘        └──────────┬──────────────┘
         │                              │
         │ Dynamic RAG                   │ STT → Vision → TTS
         ▼                              ▼
┌───────────────────┐          ┌────────────────────────┐
│ ChromaDB + Graph  │          │ Groq / external APIs   │
│ NetworkX          │          └────────────────────────┘
└────────┬──────────┘
         │
         │ async heavy jobs
         ▼
┌───────────────────┐        ┌─────────────────────────┐
│       Redis       │───────▶│ Celery AI-heavy Worker  │
│ Broker/Backend    │        │ Flux / CogVideoX / XTTS │
└───────────────────┘        └──────────┬──────────────┘
                                        │
                                        ▼
                              ┌─────────────────────────┐
                              │ Long Video Engine        │
                              │ chunks → overlap →      │
                              │ concat → interpolation → │
                              │ XTTS → optional lipsync │
                              └─────────────────────────┘
```

## الملفات

```text
Nova Enterprise AI/
├── app.py
├── controlled_generation.py
├── long_video_engine.py
├── knowledge_engine.py
├── task_queue.py
├── realtime_gateway.py
├── omni_multimodal.py
├── components/
│   └── omni_capture/
│       └── index.html
├── tests_runtime.py
├── VERSION.txt
├── .github/
│   └── workflows/
│       └── ci.yml
├── .env.example
├── .gitignore
├── .dockerignore
├── Dockerfile
├── docker-compose.yml
├── .streamlit/
│   └── config.toml
├── data/                 # Runtime only; ignored by Git
└── README.md
```

## 1. Hybrid LLM + Fallback

- Groq هو المسار الأساسي.
- يمكن تغيير النموذج من `.env` دون تعديل الشفرة.
- Groq Vision يعالج الرسائل متعددة الوسائط.
- Phi-3 محلي كمسار fallback للنص عندما يفشل المسار الخارجي.
- الأسئلة الثابتة الخاصة بالهوية/القدرات تحكمها قاعدة تطبيقية مباشرة.
- مسائل العلوم والرياضيات تُوجَّه إلى Markdown/LaTeX من خلال system prompt.

## 2. الإنتاج الخلفي Celery + Redis

`task_queue.py` يعرض طبقة موحدة:

- Celery + Redis عندما تكون `CELERY_BROKER_URL` مضبوطة.
- Local Thread Executor عند عدم توفر Redis/Celery، حتى يبقى التطبيق قابلًا للتطوير محليًا.
- `task_track_started`, `acks_late`, `reject_on_worker_lost`, `prefetch=1`.
- Redis broker/backend منفصلان.
- نتيجة المهمة تُعاد إلى التطبيق عبر `task_state()`.
- واجهة Streamlit تستخدم `st.fragment(run_every="1s")` لمراقبة التقدم بدون إعادة بناء الواجهة كاملة.

### تشغيل العامل

```bash
celery -A task_queue.celery_app worker --loglevel=INFO --concurrency=1 -Q ai-heavy
```

### المهام المدعومة

- توليد صور Pollinations في الخلفية.
- توليد فيديو طويل CogVideoX في الخلفية.

## 3. Ultra-Long Video Engine

`long_video_engine.py` لا يحاول إنشاء فيديو طويل كاملًا داخل الذاكرة.

المسار هو:

```text
Prompt
  ↓
Starter Frame (Flux عند عدم وجود مرجع)
  ↓
Chunk 1
  ↓ last frame
Chunk 2 + overlap frames
  ↓ last frame
Chunk 3 + overlap frames
  ↓
Trim overlap
  ↓
FFmpeg concat / H.264
  ↓
Optional frame interpolation
  ↓
XTTS-v2 narration
  ↓
Optional configured lip-sync endpoint
  ↓
AAC audio mux + faststart
  ↓
Final MP4
```

### اتساق الشخصية

كل قطعة تحصل على آخر إطار من القطعة السابقة كـanchor مع prompt استمرار يصر على ثبات:

- الوجه والشخصية.
- الملابس.
- البيئة.
- الإضاءة.
- أسلوب الكاميرا.
- Color grade.
- Seed متسلسل.

هذا يعزز الاتساق لكنه لا يمثل ضمانًا رياضيًا لتطابق الوجه في كل إطار.

### منع خسارة زمن القطع

للحفاظ على المدة المستهدفة، القطع اللاحقة تولد هامش `LONG_VIDEO_OVERLAP_FRAMES` إضافيًا ثم تُقص الإطارات المتداخلة قبل الدمج. لذلك لا تتناقص المدة المستهدفة بمقدار التداخل عند كل وصلة.

### Frame interpolation

يُستخدم FFmpeg `minterpolate` اختياريًا لرفع السلاسة من FPS الأساس إلى `LONG_VIDEO_INTERPOLATION_FPS`.

## 4. الصوت وXTTS-v2

المشروع يستخدم `coqui-tts` الحديثة، وتُستدعى واجهة `TTS.api.TTS` مع XTTS-v2.

يدعم:

- العربية واللغات التي يدعمها النموذج.
- Voice reference عبر `speaker_wav`.
- سرعة الصوت عبر FFmpeg `atempo`.
- دمج الصوت مع الفيديو باستخدام AAC.
- `aresample=async=1:first_pts=0` لمزامنة خط الزمن الصوتي.
- `lipsync.py` يشغّل Wav2Lip محليًا، مع bootstrap تلقائي اختياري، التحقق من الوزن، وإعادة محاولة بخفض batch size عند ضغط VRAM. `LIPSYNC_ENDPOINT` مسار اختياري فقط للاستضافة المنفصلة.

### خط مزامنة الشفاه عالي الجودة

مسار الفيديو المتكلم يجهز الصوت إلى PCM أحادي 16kHz ويطبع المستوى، ثم يحاول MuseTalk 1.5 محليًا أولاً عند تهيئته، ويعود إلى Wav2Lip عند عدم توفره، ثم يمرر الناتج عبر mastering صوت/فيديو بــ AAC 320kbps و48kHz و`faststart`. MuseTalk 1.5 موصى له بتشغيل 25fps، وهو الإعداد الافتراضي لهذا المسار. لا يوجد ادعاء علمي بأن أي نموذج يطابق كل phoneme وكل حركة وجه بنسبة 100% على كل فيديو؛ النظام مصمم لأعلى جودة عملية مع فشل آمن.

## 5. Media Quality Pipeline

المخرجات المولدة تمر عبر طبقة جودة موحدة في `media_quality.py`:

- الصور: PNG مع تنظيف آلي محافظ لمناطق الزوايا عند تفعيل سياسة الإنتاج، ثم micro-detail sharpening وتباين طفيف.
- الفيديو: فحص عينات زمنية، بناء mask مستقر للـoverlays في الزوايا، وإعادة بناء البكسلات عبر OpenCV inpainting، ثم إخراج MP4 متوافق مع الويب.
- الصوت: loudness normalization إلى مستوى حواري ثابت، إعادة أخذ العينات بـSoX-resampler، ثم AAC 320kbps/48kHz في master النهائي.
- خدمات التوليد التي تدعم ذلك تُطلب منها مخرجات بلا شعار (`nologo`) من المصدر نفسه.

نظام المعالجة لا يتجاوز حقوق المصدر أو يلتف على حماية المنصة؛ يستخدم تنظيفًا مخصصًا لمخرجات المشروع والـoverlays المسموح بمعالجتها.

## 6. Omni Realtime WebSocket

`realtime_gateway.py` خدمة FastAPI مستقلة.

النقطة:

```text
/ws/omni/{user_id}?token=...
```

التوثيق يتم عبر token HMAC قصير العمر يولده `app.py`، والبوابة تتحقق منه قبل قبول التدفق.

### التدفق

```text
Camera + Screen → browser fusion
Microphone → short audio chunk
          ↓
      WebSocket
          ↓
       Whisper STT
          ↓
   Groq Vision / LLM
          ↓
        TTS
          ↓
   omni_response JSON
```

التدفق يستخدم **latest-frame semantics**: إذا كانت المعالجة السابقة تعمل، لا يراكم النظام عشرات الإطارات المتأخرة؛ يفضل أحدث snapshot لتقليل الكمون.

### ملاحظات الإنتاج

- الكاميرا/الميكروفون/مشاركة الشاشة تتطلب صلاحيات المتصفح.
- HTTPS مطلوب للميزات الحساسة في الاستضافة العامة.
- استخدم `wss://` في الإنتاج.
- عيّن `OMNI_GATEWAY_SECRET` طويلًا وعشوائيًا.
- `OMNI_WS_MAX_MESSAGE_BYTES` يضع حدًا لحجم رسائل WebSocket.
- `OMNI_GATEWAY_MIN_INTERVAL` يطبق Backpressure بسيطًا على snapshots.

### رابط WebSocket في السحابة

غيّر:

```env
OMNI_WS_URL=wss://realtime.example.com/ws/omni
```

وفي Docker Compose يجب تمرير نفس القيمة العامة/الخارجية إلى خدمة `app` بدل `ws://localhost:8000`.


### Adaptive Swarm AI

`swarm_orchestrator.py` ينفذ نمطًا تكيفيًا من ثلاثة أدوار: planner وspecialist وsynthesizer. يتم تفعيل المسار فقط للمهمات المعقدة أو الطويلة، بينما تبقى الأسئلة البسيطة على مسار الاستدعاء المباشر. لا يتم تعديل أوزان النموذج تلقائيًا؛ التعلم طويل المدى يتم عبر ChromaDB وKnowledge Graph في `knowledge_engine.py`.

## 7. Hybrid RAG + Knowledge Graph

`knowledge_engine.py` يجمع:

- ChromaDB PersistentClient للبحث الدلالي.
- Sentence-Transformers embeddings متعددة اللغات.
- NetworkX MultiDiGraph لتمثيل العلاقات.

### ما الذي تتم فهرسته؟

- PDF.
- النصوص والكود.
- الصفحات التي يقرؤها التطبيق عبر HTTPS.
- التفاعلات، عند `MEMORY_INDEX_INTERACTIONS=true`.
- تفضيلات المستخدم الصريحة.
- التصحيحات التي يذكرها المستخدم.

### Dynamic Context Injection

كل prompt يمر عبر:

```text
User Query
   ├── Vector Retrieval
   └── Graph Retrieval
           ↓
      Context Fusion
           ↓
        LLM Prompt
```

تُستخدم الذاكرة لتوسيع السياق، وليس لتعديل أوزان النموذج تلقائيًا.

### التخزين

```text
data/knowledge/
├── chroma/
└── graph/
```

لكل مستخدم collection/graph خاص به.

## 8. الأمان

- `.env` مستبعد من Git.
- PBKDF2-HMAC-SHA256 لكلمات المرور مع Salt فريد.
- Rate Limiting لكل جلسة.
- SSRF hardening لروابط HTTPS العامة.
- فحص التحويلات في الروابط.
- حدود لحجم الملفات والـHTTP body.
- عزل ملفات المستخدم داخل مجلدات خاصة به.
- HMAC token للـWebSocket.
- لا تُضمّن مفاتيح حقيقية داخل المستودع.

## 9. Docker Compose

المكدس الكامل محليًا:

```text
Redis
 ├── Streamlit app :8501
 ├── Celery worker
 └── Realtime FastAPI :8000
```

التشغيل:

```bash
cp .env.example .env
docker compose up --build
```

ثم:

- Streamlit: `http://localhost:8501`
- Realtime health: `http://localhost:8000/health`

### السحابة

في بيئة Cloud حقيقية استخدم:

- خدمة Streamlit/Container مستقلة.
- Redis مُدار أو Redis Cluster عند الحاجة.
- Worker مستقل، ويفضل GPU node للتوليد المحلي.
- خدمة Realtime مستقلة خلف Load Balancer يدعم WebSocket.
- Persistent Volume أو Object Storage للملفات.
- قاعدة بيانات مُدارة عند التوسع بدل SQLite/Chroma المحليين.
- HTTPS/WSS أمام الواجهات العامة.
- Secrets Manager / environment secrets بدل `.env` داخل الصورة.

يمكن استخدام `redis://` داخل شبكة خاصة و`rediss://` مع TLS في البنية السحابية التي تفرض تشفير Redis.

## 10. النشر مع GPU

النماذج الثقيلة:

- Flux.
- ControlNet.
- IP-Adapter.
- CogVideoX.
- XTTS-v2.

تستفيد جدًا من NVIDIA CUDA.

CPU fallback موجود لبعض المسارات، لكنه ليس مناسبًا عادةً لإنتاج فيديو محلي طويل بزمن تفاعلي.

## 11. Local Runtime

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
cp .env.example .env
streamlit run app.py
```

لتشغيل Realtime محليًا في terminal مستقل:

```bash
uvicorn realtime_gateway:app --host 0.0.0.0 --port 8000
```

ولتفعيل Redis/Celery محليًا:

```bash
redis-server
celery -A task_queue.celery_app worker --loglevel=INFO --concurrency=1 -Q ai-heavy
```

## 12. نماذج البيئة

الملف `.env.example` يحتوي على مفاتيح/إعدادات:

- Groq.
- Pollinations.
- Hugging Face.
- SQLite.
- Chroma.
- Celery/Redis.
- WebSocket gateway.
- Long-video engine.
- XTTS-v2.
- Local Wav2Lip lip-sync with deterministic bootstrap and VRAM-aware retries.
- Owner-controlled overlay rectangles.

لا تضع قيمًا حقيقية في GitHub.

## 13. الاختبارات

الفحوصات الأساسية:

```bash
python -m py_compile app.py
python -m py_compile controlled_generation.py
python -m py_compile knowledge_engine.py
python -m py_compile long_video_engine.py
python -m py_compile omni_multimodal.py
python -m py_compile realtime_gateway.py
python -m py_compile task_queue.py
python -m compileall -q .
python tests_runtime.py
```

تشمل اختبارات runtime المحلية استيراد الطبقات الاختيارية عند توفرها وفحص حدود إعدادات الفيديو واختبار token HMAC للبوابة.

### Make targets

```bash
make test
make compile
make health
make up
make bootstrap-lipsync
```

## 14. GitHub Checklist

قبل الرفع:

```bash
git status
git add .
git commit -m "Build ultimate production AI architecture"
git push
```

ولا ترفع:

```text
.env
data/
*.db
*.sqlite
*.sqlite3
*.safetensors
*.bin
*.pt
*.pth
*.ckpt
```

## 15. حدود هندسية مهمة

- Streamlit ليس إطار WebRTC أو media server بحد ذاته؛ لذلك طبقة Omni منخفضة الكمون منفصلة في FastAPI/WebSocket.
- Chroma + NetworkX تمثل ذاكرة واسترجاعًا متراكمًا، وليست تدريبًا ذاتيًا لأوزان النموذج.
- الاتساق الزمني في التوليد يعتمد على جودة checkpoint والـanchor والـprompt وseed؛ لا توجد ضمانة نظرية لثبات الوجه 100%.
- Lip-Sync يمر عبر Wav2Lip محليًا عند تهيئة الوزن، بينما `LIPSYNC_ENDPOINT` يبقى مسار استضافة منفصل اختياري.
- توليد 30 دقيقة من CogVideoX محليًا عملية ثقيلة جدًا؛ تقسيم القطع يمنع الحاجة للاحتفاظ بالفيديو الكامل في ذاكرة النموذج، لكن تكلفة الحساب تظل متناسبة مع طول الفيديو.

## 16. الترخيص

لا يفرض هذا المستودع ترخيصًا تلقائيًا. أضف License مناسبًا لحقوقك، ثم راجع تراخيص الأوزان والنماذج والمزودات الخارجية قبل التوزيع التجاري.


## Android APK

تمت إضافة غلاف Android باسم `Ali Gorbaj-AI` دون إعادة كتابة `app.py`. بعد بناء APK من GitHub Actions، يفتح التطبيق واجهة Streamlit نفسها ويكتشف خادم backend محليًا تلقائيًا على الشبكة؛ لا توجد شاشة إدخال رابط. يتطلب ذلك أن يكون backend نفسه قابلًا للوصول من الجهاز. راجع `ANDROID_BUILD.md` للتفاصيل.
## Android Standalone Mode (2026)

The repository now includes a self-contained Android launcher/runtime based on Chaquopy. The existing Streamlit application files remain the source of truth: the Android build stages the root Python application into the APK and starts Streamlit on `localhost` automatically. The user does not enter a server URL. See [`ANDROID_BUILD.md`](ANDROID_BUILD.md) for the exact build flow.

## 10. Maximum PyTorch / Diffusion Acceleration

The runtime now includes `ai_acceleration.py` and `model_manager.py` for adaptive selection of the strongest compatible local model and runtime profile.

### Flux

- `FLUX.1-dev` is selected on sufficiently large NVIDIA GPUs.
- `FLUX.1-schnell` is the automatic speed fallback.
- BF16/FP16 is chosen from hardware capability.
- TorchAO int8/FP8 weight-only paths are attempted when supported.
- Flash / memory-efficient / math SDPA backends are enabled according to environment settings.
- CUDA device selection can be `auto` and chooses the GPU with the most currently free memory.
- `torch.compile` is used only for configurations where offloading does not defeat the expected benefit.

### CogVideoX

- `CogVideoX1.5-5B` and `CogVideoX1.5-5B-I2V` are the high-quality local tiers.
- `CogVideoX-2b` remains the automatic recovery tier for smaller VRAM budgets.
- The long-video engine respects the native 81/161 frame families of CogVideoX 1.5 rather than requesting unsupported frame counts.
- VAE slicing/tiling and CPU/model offload are selected dynamically to reduce peak memory.

### Model prefetch

Use:

```bash
python scripts/prefetch_models.py --best --root data/models
```

Set `PREFETCH_MODELS_ON_START=1` in the production worker environment when automatic model acquisition at worker startup is desired. Production deployments should also pin reviewed Hugging Face revisions through the corresponding environment overrides.

## 11. Android Edge Runtime

Android includes the official ExecuTorch 1.5.1 AAR and a native `EdgeModelRuntime` wrapper. ExecuTorch's Android runtime exposes the Java `Module`, `Tensor`, and `EValue` APIs and supports XNNPACK CPU execution plus additional Android acceleration backends. The packaged app can therefore execute verified `.pte` edge models locally without changing the Streamlit UI.

The repository also provides:

- `scripts/export_executorch_model.py` for XNNPACK-targeted `.pte` export of exportable `torch.nn.Module` components.
- `edge_runtime.py` for discovery and integrity metadata of packaged `.pte` models.
- `android/app/src/main/java/com/aligorbaj/ai/EdgeModelRuntime.java` for on-device execution.
- `android/app/src/main/assets/edge_models/` as the verified model-pack location.

Large diffusion systems such as FLUX and CogVideoX remain in the full Linux/CUDA PyTorch stack because their desktop/server implementations and Android edge runtimes use different execution formats. The Android layer does not silently replace them with an unrelated small model.
