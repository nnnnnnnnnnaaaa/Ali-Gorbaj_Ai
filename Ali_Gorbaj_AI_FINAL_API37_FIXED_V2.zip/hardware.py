from __future__ import annotations

import os
import platform
import sys
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class HardwareProfile:
    platform: str
    python: str
    cpu_count: int
    ram_gb: float
    torch_version: str
    device: str
    gpu_name: str
    gpu_count: int
    gpu_memory_gb: float
    compute_capability: str
    bf16: bool
    fp16: bool
    recommended_dtype: str
    recommended_video_chunk_seconds: int
    recommended_quantization: str


def detect_hardware() -> HardwareProfile:
    ram_gb = 0.0
    try:
        import psutil
        ram_gb = float(psutil.virtual_memory().total) / (1024 ** 3)
    except Exception:
        try:
            pages = os.sysconf("SC_PHYS_PAGES")
            page_size = os.sysconf("SC_PAGE_SIZE")
            ram_gb = pages * page_size / (1024 ** 3)
        except (AttributeError, OSError, ValueError):
            pass

    torch_version = "unavailable"
    device = "cpu"
    gpu_name = ""
    gpu_count = 0
    gpu_memory_gb = 0.0
    compute_capability = ""
    bf16 = False
    fp16 = False
    try:
        import torch
        torch_version = str(torch.__version__)
        if torch.cuda.is_available():
            device = "cuda"
            gpu_count = int(torch.cuda.device_count())
            props = torch.cuda.get_device_properties(0)
            gpu_name = str(props.name)
            gpu_memory_gb = float(props.total_memory) / (1024 ** 3)
            compute_capability = f"{props.major}.{props.minor}"
            bf16 = bool(torch.cuda.is_bf16_supported())
            fp16 = True
        else:
            mps = getattr(torch.backends, "mps", None)
            if mps is not None and mps.is_available():
                device = "mps"
                fp16 = True
    except Exception:
        pass

    try:
        import torchao  # noqa: F401
        torchao_available = True
    except Exception:
        torchao_available = False

    capability = (0, 0)
    try:
        major, minor = compute_capability.split(".", 1)
        capability = (int(major), int(minor))
    except Exception:
        pass

    requested_quant = os.getenv("AI_QUANTIZATION", "auto").strip().lower()
    if requested_quant in {"", "auto"}:
        if device == "cuda" and torchao_available and capability >= (8, 9):
            quantization = "float8"
        elif device == "cuda" and torchao_available:
            quantization = "int8"
        else:
            quantization = "none"
    else:
        quantization = requested_quant

    if device == "cuda":
        dtype = "bfloat16" if bf16 else "float16"
        if gpu_memory_gb >= 48:
            chunk_seconds = 12
        elif gpu_memory_gb >= 24:
            chunk_seconds = 8
        elif gpu_memory_gb >= 16:
            chunk_seconds = 6
        elif gpu_memory_gb >= 10:
            chunk_seconds = 4
        else:
            chunk_seconds = 3
    elif device == "mps":
        dtype = "float16"
        chunk_seconds = 3
    else:
        dtype = "float32"
        chunk_seconds = 2 if ram_gb < 32 else 3

    return HardwareProfile(
        platform=platform.platform(),
        python=sys.version.split()[0],
        cpu_count=max(1, int(os.cpu_count() or 1)),
        ram_gb=round(max(0.0, ram_gb), 2),
        torch_version=torch_version,
        device=device,
        gpu_name=gpu_name,
        gpu_count=gpu_count,
        gpu_memory_gb=round(gpu_memory_gb, 2),
        compute_capability=compute_capability,
        bf16=bf16,
        fp16=fp16,
        recommended_dtype=dtype,
        recommended_video_chunk_seconds=chunk_seconds,
        recommended_quantization=quantization,
    )


def model_load_kwargs() -> dict[str, Any]:
    profile = detect_hardware()
    kwargs: dict[str, Any] = {"low_cpu_mem_usage": True}
    try:
        import torch
        if profile.device == "cuda":
            kwargs["torch_dtype"] = torch.bfloat16 if profile.bf16 else torch.float16
            if profile.gpu_count > 1 and os.getenv("AI_MULTI_GPU", "1").lower() in {"1", "true", "yes", "on"}:
                kwargs["device_map"] = "balanced"
        elif profile.device == "mps":
            kwargs["torch_dtype"] = torch.float16
        else:
            kwargs["torch_dtype"] = torch.float32
    except Exception:
        pass

    if profile.device == "cuda" and profile.recommended_quantization == "4bit-bnb":
        try:
            import torch
            from transformers import BitsAndBytesConfig
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type=os.getenv("BNB_4BIT_QUANT_TYPE", "nf4"),
                bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=torch.bfloat16 if profile.bf16 else torch.float16,
            )
            kwargs.pop("torch_dtype", None)
        except Exception:
            pass
    return kwargs


def configure_runtime() -> HardwareProfile:
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
    try:
        import torch
        profile = detect_hardware()
        cpu_threads = os.getenv("AI_CPU_THREADS", "auto").strip().lower()
        interop_threads = os.getenv("AI_INTEROP_THREADS", "auto").strip().lower()
        if cpu_threads != "auto":
            try:
                torch.set_num_threads(max(1, int(cpu_threads)))
            except Exception:
                pass
        if interop_threads != "auto":
            try:
                torch.set_num_interop_threads(max(1, int(interop_threads)))
            except Exception:
                pass
        torch.set_float32_matmul_precision("high")
        if torch.cuda.is_available():
            requested_device = os.getenv("AI_CUDA_DEVICE", "auto").strip().lower()
            if requested_device == "auto":
                try:
                    best_index = 0
                    best_free = -1
                    for index in range(torch.cuda.device_count()):
                        free_bytes, _ = torch.cuda.mem_get_info(index)
                        if int(free_bytes) > best_free:
                            best_free = int(free_bytes)
                            best_index = index
                    torch.cuda.set_device(best_index)
                    os.environ["AI_SELECTED_CUDA_DEVICE"] = str(best_index)
                except Exception:
                    os.environ.setdefault("AI_SELECTED_CUDA_DEVICE", "0")
            else:
                try:
                    selected = int(requested_device)
                    torch.cuda.set_device(selected)
                    os.environ["AI_SELECTED_CUDA_DEVICE"] = str(selected)
                except Exception:
                    os.environ.setdefault("AI_SELECTED_CUDA_DEVICE", "0")
            os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True,max_split_size_mb:256,garbage_collection_threshold:0.80")
            try:
                torch.backends.cuda.matmul.allow_tf32 = True
                torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = True
                torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = True
                torch.backends.cudnn.allow_tf32 = True
                torch.backends.cudnn.benchmark = True
                enable_flash = os.getenv("AI_ENABLE_FLASH_SDP", "1").lower() in {"1", "true", "yes", "on"}
                enable_mem = os.getenv("AI_ENABLE_MEM_EFFICIENT_SDP", "1").lower() in {"1", "true", "yes", "on"}
                enable_math = os.getenv("AI_ENABLE_MATH_SDP", "1").lower() in {"1", "true", "yes", "on"}
                if hasattr(torch.backends.cuda, "enable_flash_sdp"):
                    torch.backends.cuda.enable_flash_sdp(enable_flash)
                if hasattr(torch.backends.cuda, "enable_mem_efficient_sdp"):
                    torch.backends.cuda.enable_mem_efficient_sdp(enable_mem)
                if hasattr(torch.backends.cuda, "enable_math_sdp"):
                    torch.backends.cuda.enable_math_sdp(enable_math)
            except Exception:
                pass
        return detect_hardware()
    except Exception:
        return detect_hardware()

def as_dict() -> dict[str, Any]:
    return asdict(detect_hardware())
