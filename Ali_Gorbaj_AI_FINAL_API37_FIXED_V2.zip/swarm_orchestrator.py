from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable

LLMCallable = Callable[[list[dict[str, str]]], str]


@dataclass(frozen=True)
class SwarmResult:
    answer: str
    used_agents: tuple[str, ...]
    mode: str


class SwarmOrchestrator:
    """Adaptive multi-agent reasoning built on one LLM interface.

    Roles are deliberately small and deterministic: planner, specialist/critic, and synthesizer.
    The orchestrator never mutates model weights; persistent learning belongs to the RAG/graph layer.
    """

    def __init__(self, llm: LLMCallable, max_chars: int = 9000) -> None:
        self.llm = llm
        self.max_chars = max(2000, int(max_chars))

    @staticmethod
    def should_swarm(prompt: str) -> bool:
        text = (prompt or "").strip()
        if len(text) >= 900:
            return True
        markers = re.compile(
            r"(حلل|قارن|صمم|خطط|ابحث|راجع|دقق|اشرح بالتفصيل|برمج|هندسة|معمارية|استراتيجية|analy[sz]e|compare|design|architect|debug|research|plan|implement)",
            re.I,
        )
        return bool(markers.search(text))

    def _call(self, system: str, user: str) -> str:
        result = self.llm([
            {"role": "system", "content": system},
            {"role": "user", "content": user[: self.max_chars]},
        ])
        return str(result).strip()

    def run(self, prompt: str, context: str = "") -> SwarmResult:
        planner = self._call(
            "أنت مخطط في فريق وكلاء ذكاء اصطناعي. حدد هدف المهمة والقيود والمخرجات المطلوبة. لا تجب عن المهمة نهائيًا.",
            f"المهمة:\n{prompt}\n\nالسياق:\n{context[:5000]}",
        )
        specialist = self._call(
            "أنت خبير متخصص ومراجع تقني. افحص خطة الوكيل الآخر، استخرج النقاط التي تحتاج تحققًا، ثم اقترح تصحيحات عملية دون كتابة الإجابة النهائية.",
            f"المهمة الأصلية:\n{prompt}\n\nخطة الوكيل:\n{planner}",
        )
        final = self._call(
            "أنت الوكيل المنسق النهائي. استخدم المهمة وخطة الوكيل ومراجعة الخبير لصياغة إجابة واحدة دقيقة ومباشرة. لا تذكر وجود وكلاء أو خطوات داخلية، ولا تدّع أي تحقق لم يحدث.",
            f"المهمة:\n{prompt}\n\nالخطة:\n{planner}\n\nمراجعة الخبير:\n{specialist}\n\nالسياق المرجعي:\n{context[:4000]}",
        )
        return SwarmResult(answer=final, used_agents=("planner", "specialist", "synthesizer"), mode="adaptive")
