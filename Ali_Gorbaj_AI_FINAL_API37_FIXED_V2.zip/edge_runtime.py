from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class EdgeModelRecord:
    name: str
    path: str
    size_bytes: int
    sha256: str
    manifest: dict[str, Any]


def edge_model_root() -> Path:
    root = Path(os.getenv("EDGE_MODEL_ROOT", "./data/edge_models")).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def discover_edge_models(root: Path | None = None) -> list[EdgeModelRecord]:
    root = root or edge_model_root()
    records: list[EdgeModelRecord] = []
    if not root.exists():
        return records
    for path in sorted(root.rglob("*.pte")):
        if not path.is_file():
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        manifest_path = Path(str(path) + ".json")
        manifest: dict[str, Any] = {}
        if manifest_path.is_file():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                manifest = {}
        records.append(EdgeModelRecord(path.stem, str(path), path.stat().st_size, digest, manifest))
    return records


def best_edge_model(name: str | None = None) -> EdgeModelRecord | None:
    records = discover_edge_models()
    if name:
        target = name.casefold()
        for item in records:
            if item.name.casefold() == target:
                return item
    return records[0] if records else None
