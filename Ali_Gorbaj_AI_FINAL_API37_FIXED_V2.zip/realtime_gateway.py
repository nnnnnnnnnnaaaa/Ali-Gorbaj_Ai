from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent / ".env", override=False)
except Exception:
    pass

import httpx
from fastapi import FastAPI, WebSocket, WebSocketDisconnect

APP_NAME = os.getenv("APP_NAME", "Nova Enterprise AI")
OMNI_SECRET = os.getenv("OMNI_GATEWAY_SECRET", "").encode("utf-8")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "").strip()
GROQ_MODEL = os.getenv("GROQ_VISION_MODEL", "qwen/qwen3.8-27b")
POLLINATIONS_API_KEY = os.getenv("POLLINATIONS_API_KEY", "").strip()
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "").strip()
WS_MIN_INTERVAL_SECONDS = float(os.getenv("OMNI_GATEWAY_MIN_INTERVAL", "1.2"))
MAX_MESSAGE_BYTES = int(os.getenv("OMNI_WS_MAX_MESSAGE_BYTES", str(4 * 1024 * 1024)))
ALLOWED_ORIGINS = {item.strip() for item in os.getenv("OMNI_ALLOWED_ORIGINS", "").split(",") if item.strip()}

app = FastAPI(title=f"{APP_NAME} Realtime Gateway", version="2026.10")


@dataclass
class SessionState:
    last_timestamp: int = 0
    last_processed: float = 0.0
    busy: bool = False
    latest_fused_frame: str = ""
    latest_audio_chunk: str = ""
    language: str = "auto"
    dialect: str = "auto"
    task: asyncio.Task[Any] | None = field(default=None, repr=False)


def verify_token(user_id: int, token: str) -> bool:
    try:
        raw = base64.urlsafe_b64decode(token.encode("ascii") + b"=" * (-len(token) % 4))
        payload = json.loads(raw.decode("utf-8"))
        exp = int(payload.get("exp", 0))
        token_user = int(payload.get("uid", -1))
        signature = str(payload.get("sig", ""))
        body = f"{token_user}:{exp}".encode("utf-8")
        expected = hmac.new(OMNI_SECRET, body, hashlib.sha256).hexdigest()
        return token_user == int(user_id) and exp >= int(time.time()) and hmac.compare_digest(signature, expected)
    except Exception:
        return False


def data_url_bytes(data_url: str) -> tuple[bytes, str]:
    if not data_url or "," not in data_url:
        return b"", "application/octet-stream"
    header, encoded = data_url.split(",", 1)
    mime = header[5:].split(";", 1)[0] if header.startswith("data:") else "application/octet-stream"
    try:
        return base64.b64decode(encoded), mime
    except Exception:
        return b"", mime


async def transcribe(audio_data_url: str, language: str, dialect: str) -> str:
    if not POLLINATIONS_API_KEY or not audio_data_url:
        return ""
    audio_bytes, mime = data_url_bytes(audio_data_url)
    if not audio_bytes:
        return ""
    data: dict[str, str] = {"model": "whisper-large-v3", "response_format": "json", "temperature": "0"}
    if language != "auto":
        data["language"] = language.split("-", 1)[0]
    if dialect.startswith("ar-"):
        data["prompt"] = f"Arabic dialect hint: {dialect}. Preserve colloquial vocabulary and names."
    headers = {"Authorization": f"Bearer {POLLINATIONS_API_KEY}"}
    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0, connect=10.0)) as client:
        response = await client.post(
            "https://gen.pollinations.ai/v1/audio/transcriptions",
            headers=headers,
            files={"file": ("omni.webm", audio_bytes, mime)},
            data=data,
        )
    response.raise_for_status()
    payload = response.json()
    return str(payload.get("text", "")).strip()


async def groq_vision(fused_frame: str, transcript: str, language: str, dialect: str) -> str:
    if not GROQ_API_KEY:
        return "لم يتم ضبط GROQ_API_KEY في بوابة البث الحي."
    language_hint = language if language != "auto" else "لغة المستخدم الحالية"
    dialect_hint = dialect if dialect != "auto" else "مجاراة اللهجة تلقائيًا"
    prompt = (
        f"أنت مساعد Omni منخفض الكمون. حلل الإطار المرئي المشترك بين الكاميرا والشاشة. "
        f"رد مباشرة وباختصار مفيد بلغة {language_hint} ولهجة {dialect_hint}. "
        f"النص الصوتي الأخير: {transcript or 'لا يوجد نص صوتي متاح.'}"
    )
    content = [{"type": "text", "text": prompt}]
    if fused_frame:
        content.append({"type": "image_url", "image_url": {"url": fused_frame}})
    body = {"model": GROQ_MODEL, "messages": [{"role": "user", "content": content}], "temperature": 0.2, "max_tokens": 700}
    headers = {"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=httpx.Timeout(60.0, connect=10.0)) as client:
        response = await client.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=body)
    response.raise_for_status()
    payload = response.json()
    return str(payload["choices"][0]["message"]["content"]).strip()


async def tts(answer: str, language: str) -> str:
    if not POLLINATIONS_API_KEY or not answer:
        return ""
    voice = os.getenv("OMNI_TTS_VOICE", "nova")
    body = {"model": "tts-1", "input": answer, "voice": voice, "response_format": "mp3", "speed": 1.0}
    headers = {"Authorization": f"Bearer {POLLINATIONS_API_KEY}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0, connect=10.0)) as client:
        response = await client.post("https://gen.pollinations.ai/v1/audio/speech", headers=headers, json=body)
    response.raise_for_status()
    return f"data:audio/mpeg;base64,{base64.b64encode(response.content).decode('ascii')}"


async def process_snapshot(websocket: WebSocket, state: SessionState) -> None:
    state.busy = True
    try:
        transcript = await transcribe(state.latest_audio_chunk, state.language, state.dialect)
        answer = await groq_vision(state.latest_fused_frame, transcript, state.language, state.dialect)
        audio_task = asyncio.create_task(tts(answer, state.language))
        audio_data_url = await audio_task
        await websocket.send_json({
            "type": "omni_response",
            "timestamp": int(time.time() * 1000),
            "transcript": transcript,
            "answer": answer,
            "audio": audio_data_url,
            "status": "ok",
        })
    except Exception as exc:
        await websocket.send_json({"type": "omni_response", "timestamp": int(time.time() * 1000), "status": "error", "error": str(exc)})
    finally:
        state.busy = False


@app.get("/health")
async def health() -> dict[str, Any]:
    secret_ready = bool(OMNI_SECRET) and len(OMNI_SECRET) >= 32
    return {
        "status": "ok" if secret_ready else "degraded",
        "service": "realtime_gateway",
        "websocket": True,
        "secret_configured": secret_ready,
        "origin_allowlist_enabled": bool(ALLOWED_ORIGINS),
    }


@app.websocket("/ws/omni/{user_id}")
async def omni_socket(websocket: WebSocket, user_id: int, token: str) -> None:
    if not OMNI_SECRET or len(OMNI_SECRET) < 32:
        await websocket.close(code=1011, reason="gateway secret is not configured securely")
        return
    origin = websocket.headers.get("origin", "")
    if ALLOWED_ORIGINS and origin not in ALLOWED_ORIGINS:
        await websocket.close(code=1008, reason="origin not allowed")
        return
    await websocket.accept()
    if not verify_token(user_id, token):
        await websocket.close(code=1008, reason="invalid token")
        return
    state = SessionState()
    try:
        while True:
            raw = await websocket.receive_text()
            if len(raw.encode("utf-8")) > MAX_MESSAGE_BYTES:
                await websocket.send_json({"type": "error", "error": "message too large"})
                continue
            payload = json.loads(raw)
            event_type = str(payload.get("type", "snapshot"))
            if event_type == "settings":
                state.language = str(payload.get("language", "auto"))
                state.dialect = str(payload.get("dialect", "auto"))
                continue
            if event_type == "snapshot":
                timestamp = int(payload.get("timestamp", 0))
                if timestamp <= state.last_timestamp:
                    continue
                state.last_timestamp = timestamp
                state.latest_fused_frame = str(payload.get("fused_frame", ""))
                state.latest_audio_chunk = str(payload.get("audio_chunk", ""))
                now = time.monotonic()
                if state.latest_fused_frame and not state.busy and now - state.last_processed >= WS_MIN_INTERVAL_SECONDS:
                    state.last_processed = now
                    state.task = asyncio.create_task(process_snapshot(websocket, state))
                await websocket.send_json({"type": "ack", "timestamp": timestamp, "status": "accepted"})
    except WebSocketDisconnect:
        if state.task and not state.task.done():
            state.task.cancel()
    except Exception:
        if state.task and not state.task.done():
            state.task.cancel()
        try:
            await websocket.close(code=1011)
        except Exception:
            pass
