from __future__ import annotations

import gc
import os
import time
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class AccelerationProfile:
    device: str
    gpu_count: int
    gpu_name: str
    gpu_memory_gb: float
    compute_capability: tuple[int, int] | None
    bf16: bool
    fp16: bool
    torch_compile: bool
    torchao: bool
    recommended_quantization: str
    recommended_offload: str


def _import_torch() -> Any:
    try:
        import torch
        return torch
    except Exception:
        return None


def profile() -> AccelerationProfile:
    torch = _import_torch()
    if torch is None:
        return AccelerationProfile("cpu", 0, "", 0.0, None, False, False, False, False, "none", "none")
    if torch.cuda.is_available():
        count = int(torch.cuda.device_count())
        props = torch.cuda.get_device_properties(0)
        memory = float(props.total_memory) / (1024 ** 3)
        cap = (int(props.major), int(props.minor))
        bf16 = bool(torch.cuda.is_bf16_supported())
        compile_enabled = os.getenv("AI_TORCH_COMPILE", "1").lower() in {"1", "true", "yes", "on"}
        try:
            import torchao  # noqa: F401
            torchao_available = True
        except Exception:
            torchao_available = False
        quant = os.getenv("AI_QUANTIZATION", "auto").strip().lower()
        if quant == "auto":
            # Preserve maximum fidelity on very large GPUs; quantize only when
            # memory pressure makes it materially useful.
            if memory >= 48:
                quant = "none"
            elif memory >= 24:
                quant = "int8" if torchao_available else "none"
            elif cap >= (8, 9) and torchao_available:
                quant = "float8"
            else:
                quant = "int8" if torchao_available else "none"
        if memory >= 48:
            offload = "none"
        elif memory >= 24:
            offload = "model"
        else:
            offload = "sequential"
        return AccelerationProfile(
            "cuda", count, str(props.name), round(memory, 2), cap, bf16, True,
            compile_enabled, torchao_available, quant, offload,
        )
    mps = getattr(torch.backends, "mps", None)
    if mps is not None and mps.is_available():
        return AccelerationProfile("mps", 0, "Apple GPU", 0.0, None, False, True, False, False, "none", "none")
    try:
        import torchao  # noqa: F401
        torchao_available = True
    except Exception:
        torchao_available = False
    return AccelerationProfile("cpu", 0, "", 0.0, None, False, False, False, torchao_available, "none", "none")


def configure_environment() -> AccelerationProfile:
    torch = _import_torch()
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
    if torch is None:
        return profile()
    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass
    p = profile()
    if p.device == "cuda":
        os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True,max_split_size_mb:256,garbage_collection_threshold:0.80")
        requested = os.getenv("AI_CUDA_DEVICE", "auto").strip().lower()
        try:
            if requested == "auto":
                best_index = 0
                best_free = -1
                for index in range(torch.cuda.device_count()):
                    free_bytes, _ = torch.cuda.mem_get_info(index)
                    if int(free_bytes) > best_free:
                        best_free = int(free_bytes)
                        best_index = index
                torch.cuda.set_device(best_index)
                os.environ["AI_SELECTED_CUDA_DEVICE"] = str(best_index)
            else:
                torch.cuda.set_device(int(requested))
                os.environ["AI_SELECTED_CUDA_DEVICE"] = str(int(requested))
        except Exception:
            os.environ.setdefault("AI_SELECTED_CUDA_DEVICE", "0")
        try:
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = True
            torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = True
            torch.backends.cudnn.allow_tf32 = True
            torch.backends.cudnn.benchmark = True
            flags = {
                "flash": os.getenv("AI_ENABLE_FLASH_SDP", "1").lower() in {"1", "true", "yes", "on"},
                "mem": os.getenv("AI_ENABLE_MEM_EFFICIENT_SDP", "1").lower() in {"1", "true", "yes", "on"},
                "math": os.getenv("AI_ENABLE_MATH_SDP", "1").lower() in {"1", "true", "yes", "on"},
            }
            if hasattr(torch.backends.cuda, "enable_flash_sdp"):
                torch.backends.cuda.enable_flash_sdp(flags["flash"])
            if hasattr(torch.backends.cuda, "enable_mem_efficient_sdp"):
                torch.backends.cuda.enable_mem_efficient_sdp(flags["mem"])
            if hasattr(torch.backends.cuda, "enable_math_sdp"):
                torch.backends.cuda.enable_math_sdp(flags["math"])
        except Exception:
            pass
    return p

def clear_device_memory() -> None:
    gc.collect()
    torch = _import_torch()
    if torch is None:
        return
    try:
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
    except Exception:
        pass
    try:
        mps = getattr(torch, "mps", None)
        if mps is not None and hasattr(mps, "empty_cache"):
            mps.empty_cache()
    except Exception:
        pass


def maybe_compile(module: Any, name: str) -> Any:
    p = profile()
    if not p.torch_compile or p.device != "cuda" or module is None:
        return module
    if p.gpu_memory_gb < float(os.getenv("AI_COMPILE_MIN_VRAM_GB", "16")):
        return module
    try:
        import torch
        mode = os.getenv("AI_TORCH_COMPILE_MODE", "max-autotune").strip() or "max-autotune"
        dynamic = os.getenv("AI_TORCH_COMPILE_DYNAMIC", "0").lower() in {"1", "true", "yes", "on"}
        return torch.compile(module, mode=mode, dynamic=dynamic, fullgraph=False)
    except Exception:
        return module


def _quantize_module(module: Any, mode: str) -> Any:
    if module is None or mode in {"", "none", "off", "false", "0"}:
        return module
    try:
        from torchao.quantization import quantize_
        if mode == "int8":
            from torchao.quantization import int8_weight_only
            quantize_(module, int8_weight_only())
            return module
        if mode == "float8":
            from torchao.quantization import Float8DynamicActivationFloat8WeightConfig, PerRow
            quantize_(module, Float8DynamicActivationFloat8WeightConfig(granularity=PerRow()))
            return module
    except Exception:
        return module
    return module


def optimize_diffusion_pipeline(pipe: Any, family: str) -> tuple[Any, dict[str, Any]]:
    p = configure_environment()
    meta: dict[str, Any] = {
        "device": p.device,
        "gpu_memory_gb": p.gpu_memory_gb,
        "quantization": p.recommended_quantization,
        "offload": p.recommended_offload,
        "compiled": False,
    }
    if pipe is None:
        return pipe, meta
    if hasattr(pipe, "vae"):
        try:
            if hasattr(pipe.vae, "enable_slicing"):
                pipe.vae.enable_slicing()
            if hasattr(pipe.vae, "enable_tiling"):
                pipe.vae.enable_tiling()
        except Exception:
            pass
    if p.device == "cuda":
        quant_mode = os.getenv("AI_QUANTIZATION", "auto").strip().lower()
        if quant_mode == "auto":
            quant_mode = p.recommended_quantization
        components: list[tuple[str, Any]] = []
        if family == "flux":
            components = [("transformer", getattr(pipe, "transformer", None))]
        elif family == "cogvideox":
            components = [
                ("transformer", getattr(pipe, "transformer", None)),
                ("text_encoder", getattr(pipe, "text_encoder", None)),
                ("vae", getattr(pipe, "vae", None)),
            ]
        for name, component in components:
            if component is not None and p.torchao:
                before = time.monotonic()
                _quantize_module(component, quant_mode)
                meta[f"quantized_{name}"] = True
                meta[f"quantized_{name}_seconds"] = round(time.monotonic() - before, 3)
        if p.recommended_offload == "none":
            try:
                pipe.to("cuda")
            except Exception:
                if hasattr(pipe, "enable_model_cpu_offload"):
                    pipe.enable_model_cpu_offload()
        elif p.recommended_offload == "model" and hasattr(pipe, "enable_model_cpu_offload"):
            pipe.enable_model_cpu_offload()
        elif hasattr(pipe, "enable_sequential_cpu_offload"):
            pipe.enable_sequential_cpu_offload()
        else:
            pipe.to("cuda")
        if p.torch_compile and p.recommended_offload == "none":
            transformer = getattr(pipe, "transformer", None)
            if transformer is not None:
                compiled = maybe_compile(transformer, f"{family}.transformer")
                if compiled is not transformer:
                    pipe.transformer = compiled
                    meta["compiled"] = True
    elif p.device == "mps":
        pipe.to("mps")
    else:
        pipe.to("cpu")
    return pipe, meta


@contextmanager
def inference_guard(max_retries: int = 1, on_retry: Callable[[int], None] | None = None):
    attempt = 0
    while True:
        try:
            yield attempt
            return
        except RuntimeError as exc:
            message = str(exc).lower()
            oom = "out of memory" in message or "cuda error" in message and "memory" in message
            if not oom or attempt >= max_retries:
                raise
            attempt += 1
            clear_device_memory()
            if on_retry is not None:
                on_retry(attempt)
