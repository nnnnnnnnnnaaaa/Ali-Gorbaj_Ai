from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


class MuseTalkLocalEngine:
    REPO_URL = "https://github.com/TMElyralab/MuseTalk.git"

    def __init__(self, root: str | Path, env: dict[str, str] | None = None) -> None:
        self.root = Path(root).resolve()
        self.repo = self.root / "MuseTalk"
        self.env = env or os.environ
        self.root.mkdir(parents=True, exist_ok=True)

    def _run(self, command: list[str], timeout: int = 7200) -> subprocess.CompletedProcess[str]:
        proc = subprocess.run(
            command,
            cwd=str(self.repo),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
            timeout=timeout,
            env={**os.environ, **self.env},
        )
        if proc.returncode != 0:
            raise RuntimeError(proc.stdout[-12000:])
        return proc

    def ensure_repo(self) -> Path:
        required = [self.repo / "scripts" / "inference.py", self.repo / "configs" / "inference"]
        if all(path.exists() for path in required):
            return self.repo
        if not shutil.which("git"):
            raise RuntimeError("Git مطلوب لتهيئة MuseTalk محليًا.")
        branch = self.env.get("MUSETALK_REPO_REF", "main").strip()
        temp = self.root / "MuseTalk.bootstrap"
        if temp.exists():
            shutil.rmtree(temp)
        proc = subprocess.run(
            ["git", "clone", "--depth", "1", "--branch", branch, self.REPO_URL, str(temp)],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=1800,
            check=False,
        )
        if proc.returncode != 0:
            raise RuntimeError(proc.stdout[-10000:])
        if self.repo.exists():
            shutil.rmtree(self.repo)
        temp.rename(self.repo)
        return self.repo

    def _python_bin(self) -> str:
        explicit = self.env.get("MUSETALK_PYTHON", "").strip()
        if explicit:
            return explicit
        for candidate in ("python3.10", "python3", sys.executable):
            resolved = shutil.which(candidate) if not Path(candidate).exists() else candidate
            if resolved:
                return str(resolved)
        return sys.executable

    @property
    def venv_python(self) -> Path:
        if os.name == "nt":
            return self.root / "musetalk_venv" / "Scripts" / "python.exe"
        return self.root / "musetalk_venv" / "bin" / "python"

    def ensure_python_env(self) -> str:
        explicit = self.env.get("MUSETALK_PYTHON", "").strip()
        if explicit:
            return explicit
        if self.venv_python.exists():
            return str(self.venv_python)
        auto_install = self.env.get("MUSETALK_AUTO_INSTALL_DEPS", "1").lower() in {"1", "true", "yes", "on"}
        if not auto_install:
            return self._python_bin()
        subprocess.run([self._python_bin(), "-m", "venv", str(self.root / "musetalk_venv")], check=True, timeout=900)
        python = str(self.venv_python)
        subprocess.run([python, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], check=True, timeout=1800)
        requirements = self.repo / "requirements.txt"
        if requirements.exists():
            subprocess.run([python, "-m", "pip", "install", "-r", str(requirements)], check=True, timeout=7200)
        packages = [
            "openmim",
            "mmengine",
            "mmcv==2.0.1",
            "mmdet==3.1.0",
            "mmpose==1.1.0",
        ]
        subprocess.run([python, "-m", "pip", "install", *packages], check=True, timeout=7200)
        return python

    def ensure_weights(self) -> None:
        model_dir = self.repo / "models"
        if (model_dir / "musetalkV15" / "unet.pth").exists() and (model_dir / "whisper").exists():
            return
        if self.env.get("MUSETALK_AUTO_DOWNLOAD_WEIGHTS", "0").lower() not in {"1", "true", "yes", "on"}:
            raise RuntimeError("أوزان MuseTalk 1.5 غير موجودة. فعّل MUSETALK_AUTO_DOWNLOAD_WEIGHTS=1 للتهيئة التلقائية.")
        script = self.repo / "download_weights.sh"
        if not script.exists():
            raise RuntimeError("سكريبت أوزان MuseTalk غير موجود.")
        self._run(["bash", str(script)], timeout=7200)
        if not (model_dir / "musetalkV15" / "unet.pth").exists():
            raise RuntimeError("تعذر تنزيل أوزان MuseTalk 1.5 بالكامل.")

    def sync(self, video_path: str | Path, audio_path: str | Path, output_path: str | Path) -> Path:
        self.ensure_repo()
        python_bin = self.ensure_python_env()
        self.ensure_weights()
        video_path = Path(video_path).resolve()
        audio_path = Path(audio_path).resolve()
        output_path = Path(output_path).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        ffmpeg_path = shutil.which("ffmpeg") or self.env.get("FFMPEG_PATH", "").strip() or "ffmpeg"
        ffmpeg_dir = str(Path(ffmpeg_path).resolve().parent) if Path(ffmpeg_path).exists() else ffmpeg_path
        gpu_id = int(self.env.get("MUSETALK_GPU_ID", "0"))
        batch_size = max(1, int(self.env.get("MUSETALK_BATCH_SIZE", "8")))
        extra_margin = max(0, int(self.env.get("MUSETALK_EXTRA_MARGIN", "10")))
        left_cheek = max(20, int(self.env.get("MUSETALK_LEFT_CHEEK_WIDTH", "90")))
        right_cheek = max(20, int(self.env.get("MUSETALK_RIGHT_CHEEK_WIDTH", "90")))
        use_fp16 = self.env.get("MUSETALK_USE_FLOAT16", "1").lower() in {"1", "true", "yes", "on"}
        with tempfile.TemporaryDirectory(prefix="musetalk_job_", dir=str(self.root)) as tmp:
            tmp_dir = Path(tmp)
            cfg = tmp_dir / "test.yaml"
            result_dir = tmp_dir / "results"
            result_dir.mkdir(parents=True, exist_ok=True)
            output_name = "lipsynced.mp4"
            cfg.write_text(
                "task_0:\n"
                f"  video_path: {video_path.as_posix()!r}\n"
                f"  audio_path: {audio_path.as_posix()!r}\n"
                f"  result_name: {output_name!r}\n",
                encoding="utf-8",
            )
            cmd = [
                python_bin, "-m", "scripts.inference",
                "--inference_config", str(cfg),
                "--result_dir", str(result_dir),
                "--unet_model_path", str(self.repo / "models" / "musetalkV15" / "unet.pth"),
                "--unet_config", str(self.repo / "models" / "musetalkV15" / "musetalk.json"),
                "--version", "v15",
                "--ffmpeg_path", ffmpeg_dir,
                "--gpu_id", str(gpu_id),
                "--fps", "25",
                "--batch_size", str(batch_size),
                "--extra_margin", str(extra_margin),
                "--left_cheek_width", str(left_cheek),
                "--right_cheek_width", str(right_cheek),
                "--whisper_dir", str(self.repo / "models" / "whisper"),
                "--vae_type", "sd-vae",
            ]
            if use_fp16:
                cmd.append("--use_float16")
            try:
                self._run(cmd, timeout=int(self.env.get("MUSETALK_TIMEOUT_SECONDS", "14400")))
            except RuntimeError as exc:
                if "out of memory" in str(exc).lower() or "cuda" in str(exc).lower():
                    for fallback in (4, 2, 1):
                        cmd2 = [part if part != str(batch_size) else str(fallback) for part in cmd]
                        try:
                            self._run(cmd2, timeout=int(self.env.get("MUSETALK_TIMEOUT_SECONDS", "14400")))
                            break
                        except RuntimeError:
                            if fallback == 1:
                                raise
                else:
                    raise
            matches = list(result_dir.rglob(output_name))
            if not matches:
                matches = list(result_dir.rglob("*.mp4"))
            if not matches:
                raise RuntimeError("MuseTalk أنهى العملية بدون إخراج فيديو.")
            shutil.copy2(matches[0], output_path)
        return output_path
