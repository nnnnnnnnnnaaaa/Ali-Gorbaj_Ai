from __future__ import annotations

import math
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image, ImageFilter, ImageEnhance

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import imageio_ffmpeg
except ImportError:
    imageio_ffmpeg = None


class MediaQualityEngine:
    def __init__(self, root: str | Path | None = None, env: dict[str, str] | None = None) -> None:
        self.root = Path(root or os.getenv("MEDIA_QUALITY_ROOT", "data/media_quality")).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.env = env or os.environ

    def ffmpeg(self) -> str:
        if imageio_ffmpeg is not None:
            return imageio_ffmpeg.get_ffmpeg_exe()
        path = shutil.which("ffmpeg")
        if path:
            return path
        raise RuntimeError("FFmpeg غير متاح لمعالجة الوسائط عالية الجودة.")

    def _run(self, command: list[str], timeout: int = 3600) -> subprocess.CompletedProcess[bytes]:
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, timeout=timeout)
        if proc.returncode != 0:
            message = proc.stderr.decode("utf-8", errors="ignore")[-8000:]
            raise RuntimeError(message or "فشلت عملية FFmpeg.")
        return proc

    def normalize_audio_for_lipsync(self, input_path: str | Path, output_path: str | Path) -> Path:
        ffmpeg = self.ffmpeg()
        output = Path(output_path).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        filter_chain = "loudnorm=I=-16:LRA=7:TP=-1.5:linear=true,aresample=16000:resampler=soxr"
        self._run([
            ffmpeg, "-y", "-i", str(Path(input_path).resolve()),
            "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le",
            "-af", filter_chain, str(output),
        ], timeout=1800)
        if not output.is_file() or output.stat().st_size < 2048:
            raise RuntimeError("تعذر تجهيز الصوت لمحرك مزامنة الشفاه.")
        return output

    def normalize_video_for_lipsync(self, input_path: str | Path, output_path: str | Path) -> Path:
        ffmpeg = self.ffmpeg()
        output = Path(output_path).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        max_width = max(640, int(self.env.get("LIPSYNC_MAX_WIDTH", "1920")))
        vf = (
            f"fps=25,scale='min({max_width},iw)':-2:flags=lanczos:force_original_aspect_ratio=decrease,"
            "format=yuv420p,setsar=1"
        )
        self._run([
            ffmpeg, "-y", "-i", str(Path(input_path).resolve()),
            "-vf", vf,
            "-c:v", "libx264", "-preset", "slow", "-crf", "16",
            "-pix_fmt", "yuv420p", "-an", "-movflags", "+faststart", str(output),
        ], timeout=3600)
        if not output.is_file() or output.stat().st_size < 10000:
            raise RuntimeError("تعذر تجهيز الفيديو لمحرك مزامنة الشفاه.")
        return output

    def duration_seconds(self, media_path: str | Path) -> float:
        ffmpeg = self.ffmpeg()
        proc = subprocess.run(
            [ffmpeg, "-hide_banner", "-i", str(Path(media_path).resolve()), "-f", "null", "-"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, timeout=600,
        )
        text = proc.stderr.decode("utf-8", errors="ignore")
        match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
        if not match:
            raise RuntimeError("تعذر قياس مدة ملف الوسائط.")
        hours, minutes, seconds = match.groups()
        return (int(hours) * 3600) + (int(minutes) * 60) + float(seconds)

    def master_audio_video(
        self,
        video_path: str | Path,
        audio_path: str | Path,
        output_path: str | Path,
        video_crf: int = 16,
        audio_bitrate: str = "320k",
    ) -> Path:
        ffmpeg = self.ffmpeg()
        output = Path(output_path).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        audio_filter = "loudnorm=I=-16:LRA=7:TP=-1.5:linear=true,aresample=48000:resampler=soxr"
        command = [
            ffmpeg, "-y", "-i", str(Path(video_path).resolve()), "-i", str(Path(audio_path).resolve()),
            "-map", "0:v:0", "-map", "1:a:0",
            "-c:v", "libx264", "-preset", "slow", "-crf", str(int(video_crf)),
            "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", audio_bitrate, "-ar", "48000",
            "-af", audio_filter, "-shortest", "-movflags", "+faststart", "-threads", os.getenv("FFMPEG_THREADS", "2"),
            str(output),
        ]
        self._run(command, timeout=3600)
        if not output.is_file() or output.stat().st_size < 10000:
            raise RuntimeError("تعذر إخراج الفيديو النهائي بجودة الصوت المطلوبة.")
        return output

    def _corner_rois(self, width: int, height: int) -> list[tuple[int, int, int, int]]:
        fraction = max(0.08, min(0.30, float(self.env.get("AUTO_CLEANUP_CORNER_FRACTION", "0.22"))))
        x = max(1, int(width * fraction))
        y = max(1, int(height * fraction))
        inset = max(0, int(min(width, height) * float(self.env.get("AUTO_CLEANUP_BORDER_INSET", "0.01"))))
        return [
            (inset, inset, min(width, x), min(height, y)),
            (max(0, width - x), inset, max(0, width - inset), min(height, y)),
            (inset, max(0, height - y), min(width, x), max(0, height - inset)),
            (max(0, width - x), max(0, height - y), max(0, width - inset), max(0, height - inset)),
        ]

    @staticmethod
    def _component_mask(gray: np.ndarray) -> np.ndarray:
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        diff = cv2.absdiff(gray, blur)
        std = float(np.std(gray))
        t = max(7, min(48, int(std * 0.6)))
        _, diff_mask = cv2.threshold(diff, t, 255, cv2.THRESH_BINARY)
        adaptive = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 7,
        )
        inv_adaptive = cv2.bitwise_not(adaptive)
        edges = cv2.Canny(blur, 70, 170)
        combined = cv2.bitwise_or(diff_mask, cv2.bitwise_and(adaptive, edges))
        combined = cv2.bitwise_or(combined, cv2.bitwise_and(inv_adaptive, edges))
        combined = cv2.bitwise_or(combined, edges)
        kernel_small = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        combined = cv2.morphologyEx(combined, cv2.MORPH_CLOSE, kernel_small, iterations=2)
        combined = cv2.dilate(combined, kernel_small, iterations=1)

        n, labels, stats, _ = cv2.connectedComponentsWithStats(combined, connectivity=8)
        out = np.zeros_like(combined)
        roi_area = gray.shape[0] * gray.shape[1]
        for i in range(1, n):
            x, y, w, h, area = [int(v) for v in stats[i]]
            if area < 4 or area > max(128, int(roi_area * 0.60)):
                continue
            aspect = max(w / max(h, 1), h / max(w, 1))
            fill_ratio = area / max(1, w * h)
            if aspect > 60 and fill_ratio < 0.12:
                continue
            out[labels == i] = 255
        return out

    def auto_corner_watermark_mask(self, frame_bgr: np.ndarray, temporal_reference: np.ndarray | None = None) -> np.ndarray:
        if cv2 is None:
            raise RuntimeError("OpenCV غير مثبت.")
        h, w = frame_bgr.shape[:2]
        result = np.zeros((h, w), dtype=np.uint8)
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        for x1, y1, x2, y2 in self._corner_rois(w, h):
            roi = gray[y1:y2, x1:x2]
            if roi.size == 0:
                continue
            candidate = self._component_mask(roi)
            if temporal_reference is not None:
                ref_roi = temporal_reference[y1:y2, x1:x2]
                candidate = cv2.bitwise_and(candidate, ref_roi)
            border_guard = max(1, int(min(roi.shape[:2]) * 0.02))
            candidate[:border_guard, :] = 0
            candidate[-border_guard:, :] = 0
            candidate[:, :border_guard] = 0
            candidate[:, -border_guard:] = 0
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
            candidate = cv2.dilate(candidate, kernel, iterations=2)
            result[y1:y2, x1:x2] = cv2.bitwise_or(result[y1:y2, x1:x2], candidate)
        return result

    def clean_image_array(self, frame_bgr: np.ndarray) -> np.ndarray:
        if cv2 is None:
            raise RuntimeError("OpenCV غير مثبت.")
        mask = self.auto_corner_watermark_mask(frame_bgr)
        if not np.any(mask):
            return frame_bgr
        radius = max(3, min(9, int(self.env.get("AUTO_CLEANUP_INPAINT_RADIUS", "5"))))
        return cv2.inpaint(frame_bgr, mask, radius, cv2.INPAINT_NS)

    def clean_generated_image(self, image: Image.Image) -> Image.Image:
        rgb = image.convert("RGB")
        arr = cv2.cvtColor(np.asarray(rgb), cv2.COLOR_RGB2BGR) if cv2 is not None else None
        if arr is not None:
            arr = self.clean_image_array(arr)
            rgb = Image.fromarray(cv2.cvtColor(arr, cv2.COLOR_BGR2RGB))
        if self.env.get("IMAGE_MICRO_DETAIL_ENHANCE", "1").lower() in {"1", "true", "yes", "on"}:
            radius = float(self.env.get("IMAGE_SHARPEN_RADIUS", "1.2"))
            percent = int(self.env.get("IMAGE_SHARPEN_PERCENT", "90"))
            threshold = int(self.env.get("IMAGE_SHARPEN_THRESHOLD", "3"))
            rgb = rgb.filter(ImageFilter.UnsharpMask(radius=radius, percent=percent, threshold=threshold))
            rgb = ImageEnhance.Contrast(rgb).enhance(float(self.env.get("IMAGE_CONTRAST", "1.02")))
        return rgb

    def clean_generated_video(self, input_path: str | Path, output_path: str | Path) -> Path:
        if cv2 is None:
            raise RuntimeError("OpenCV غير مثبت لمعالجة الفيديو.")
        source = Path(input_path).resolve()
        output = Path(output_path).resolve()
        capture = cv2.VideoCapture(str(source))
        if not capture.isOpened():
            raise RuntimeError("تعذر فتح الفيديو لمعالجة الجودة.")
        fps = float(capture.get(cv2.CAP_PROP_FPS) or 25.0)
        width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total = int(capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if width <= 0 or height <= 0:
            capture.release()
            raise RuntimeError("دقة الفيديو غير صالحة.")
        output.parent.mkdir(parents=True, exist_ok=True)
        codec = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(output), codec, fps, (width, height))
        if not writer.isOpened():
            capture.release()
            raise RuntimeError("تعذر إنشاء فيديو التنظيف.")
        try:
            sample_count = max(3, int(self.env.get("AUTO_CLEANUP_TEMPORAL_SAMPLES", "5")))
            positions = sorted(set(int(round((total - 1) * i / max(1, sample_count - 1))) for i in range(sample_count))) if total > 1 else [0]
            masks: list[np.ndarray] = []
            for pos in positions:
                capture.set(cv2.CAP_PROP_POS_FRAMES, pos)
                ok, frame = capture.read()
                if ok and frame is not None:
                    masks.append(self.auto_corner_watermark_mask(frame))
            stable_mask = np.zeros((height, width), dtype=np.uint8)
            if masks:
                stack = np.stack([(m > 0).astype(np.uint8) for m in masks], axis=0)
                votes = np.sum(stack, axis=0)
                required = max(2, int(math.ceil(len(masks) * float(self.env.get("AUTO_CLEANUP_TEMPORAL_PERSISTENCE", "0.4")))))
                stable_mask[votes >= required] = 255
                stable_mask = cv2.dilate(stable_mask, np.ones((5, 5), np.uint8), iterations=1)
            capture.set(cv2.CAP_PROP_POS_FRAMES, 0)
            radius = max(3, min(9, int(self.env.get("AUTO_CLEANUP_INPAINT_RADIUS", "5"))))
            while True:
                ok, frame = capture.read()
                if not ok:
                    break
                frame_mask = stable_mask.copy()
                current = self.auto_corner_watermark_mask(frame)
                frame_mask = cv2.bitwise_or(frame_mask, current)
                if np.any(frame_mask):
                    frame = cv2.inpaint(frame, frame_mask, radius, cv2.INPAINT_NS)
                writer.write(frame)
        finally:
            capture.release()
            writer.release()
        if not output.is_file() or output.stat().st_size < 10000:
            raise RuntimeError("فشل إخراج الفيديو بعد تحسين الجودة والتنظيف.")
        return output

    def process_image_bytes(self, data: bytes, output_format: str = "PNG") -> bytes:
        with tempfile.NamedTemporaryFile(suffix=".img", delete=False) as temp:
            temp.write(data)
            source = Path(temp.name)
        try:
            image = Image.open(source)
            cleaned = self.clean_generated_image(image)
            import io
            buffer = io.BytesIO()
            cleaned.save(buffer, format=output_format, optimize=True)
            return buffer.getvalue()
        finally:
            source.unlink(missing_ok=True)

    def process_video_file(self, input_path: str | Path, output_path: str | Path) -> Path:
        return self.clean_generated_video(input_path, output_path)


def quality_engine(root: str | Path | None = None, env: dict[str, str] | None = None) -> MediaQualityEngine:
    return MediaQualityEngine(root, env)
