from __future__ import annotations

import gc
import io
import os
import tempfile
from pathlib import Path
from typing import Any

from PIL import Image

from ai_acceleration import clear_device_memory, optimize_diffusion_pipeline
from media_quality import MediaQualityEngine
from model_manager import select_best

try:
    import numpy as np
except ImportError:
    np = None

try:
    import torch
except ImportError:
    torch = None

try:
    from diffusers import (
        CogVideoXFunControlPipeline,
        CogVideoXImageToVideoPipeline,
        CogVideoXPipeline,
        FluxControlNetModel,
        FluxControlNetPipeline,
        FluxPipeline,
    )
    from diffusers.utils import export_to_video, load_video
except ImportError:
    CogVideoXFunControlPipeline = None
    CogVideoXImageToVideoPipeline = None
    CogVideoXPipeline = None
    FluxControlNetModel = None
    FluxControlNetPipeline = None
    FluxPipeline = None
    export_to_video = None
    load_video = None

try:
    import cv2
except ImportError:
    cv2 = None


class ControlledGenerationService:
    def __init__(self, cache_dir: str | Path, env: dict[str, str] | None = None) -> None:
        self.cache_dir = Path(cache_dir).resolve()
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.env = env or os.environ
        self._flux_cache: dict[tuple[Any, ...], Any] = {}
        self._cog_cache: dict[tuple[Any, ...], Any] = {}

    def _require_diffusers(self) -> None:
        if torch is None or FluxPipeline is None:
            raise RuntimeError("PyTorch وDiffusers غير متاحين في بيئة التشغيل المحلية.")

    def _device(self) -> str:
        if torch is not None and torch.cuda.is_available():
            return "cuda"
        if torch is not None and getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
            return "mps"
        return "cpu"

    def _dtype(self) -> Any:
        device = self._device()
        if device == "cuda":
            return torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        if device == "mps":
            return torch.float16
        return torch.float32

    def _auth_kwargs(self) -> dict[str, Any]:
        token = self.env.get("HF_TOKEN", "").strip()
        return {"token": token} if token else {}

    @staticmethod
    def _dtype_name(dtype: Any) -> str:
        return str(dtype).replace("torch.", "")

    def prepare_control_image(self, image: Image.Image, mode: str) -> Image.Image:
        rgb = image.convert("RGB")
        if mode == "canny":
            if cv2 is None or np is None:
                raise RuntimeError("OpenCV وNumPy مطلوبان لإنشاء Canny ControlNet.")
            arr = cv2.cvtColor(np.array(rgb), cv2.COLOR_RGB2GRAY)
            edges = cv2.Canny(arr, 100, 200)
            return Image.fromarray(edges).convert("RGB")
        if mode in {"depth", "pose", "sketch"}:
            return rgb
        raise ValueError("نوع التحكم غير معروف.")

    def _load_flux_pipeline(
        self,
        base_model: str,
        control_model: str,
        use_control: bool,
        reference_enabled: bool,
        ip_repo: str,
        ip_weight: str,
        image_encoder: str,
        dtype: Any,
        device: str,
    ) -> Any:
        key = (base_model, control_model, use_control, reference_enabled, ip_repo, ip_weight, image_encoder, self._dtype_name(dtype), device)
        if key in self._flux_cache:
            return self._flux_cache[key]
        kwargs = {"torch_dtype": dtype, **self._auth_kwargs()}
        if use_control:
            if FluxControlNetPipeline is None or FluxControlNetModel is None:
                raise RuntimeError("Flux ControlNet غير متاح في إصدار Diffusers الحالي.")
            controlnet = FluxControlNetModel.from_pretrained(control_model, **kwargs)
            pipe = FluxControlNetPipeline.from_pretrained(base_model, controlnet=controlnet, **kwargs)
        else:
            pipe = FluxPipeline.from_pretrained(base_model, **kwargs)
        if reference_enabled:
            pipe.load_ip_adapter(ip_repo, weight_name=ip_weight, image_encoder_pretrained_model_name_or_path=image_encoder)
        pipe, metadata = optimize_diffusion_pipeline(pipe, "flux")
        setattr(pipe, "_ali_acceleration_metadata", metadata)
        self._flux_cache[key] = pipe
        return pipe

    def generate_flux(
        self,
        prompt: str,
        width: int,
        height: int,
        guidance_scale: float,
        steps: int,
        seed: int,
        control_image: Image.Image | None = None,
        reference_image: Image.Image | None = None,
        control_mode: str = "canny",
        controlnet_scale: float | None = None,
        ip_adapter_scale: float = 0.75,
    ) -> bytes:
        self._require_diffusers()
        requested_model = self.env.get("LOCAL_IMAGE_MODEL_ID", "auto").strip()
        primary = requested_model if requested_model and requested_model.lower() != "auto" else select_best("image", self.env).repo_id
        speed_fallback = self.env.get("LOCAL_IMAGE_FALLBACK_MODEL_ID", "black-forest-labs/FLUX.1-schnell")
        base_model = primary
        control_model = self.env.get("LOCAL_CONTROLNET_MODEL_ID", "InstantX/FLUX.1-dev-Controlnet-Canny")
        ip_repo = self.env.get("LOCAL_IP_ADAPTER_REPO", "XLabs-AI/flux-ip-adapter")
        ip_weight = self.env.get("LOCAL_IP_ADAPTER_WEIGHT", "ip_adapter.safetensors")
        image_encoder = self.env.get("LOCAL_IP_ADAPTER_IMAGE_ENCODER", "openai/clip-vit-large-patch14")
        dtype = self._dtype()
        device = self._device()

        attempts = [(base_model, int(steps), 1.0)]
        if speed_fallback and speed_fallback != base_model:
            attempts.append((speed_fallback, max(4, int(steps * 0.75)), 1.0))
        last_exc: Exception | None = None
        for model_id, attempt_steps, resize_factor in attempts:
            try:
                pipe = self._load_flux_pipeline(
                    model_id, control_model, control_image is not None, reference_image is not None,
                    ip_repo, ip_weight, image_encoder, dtype, device,
                )
                if reference_image is not None:
                    pipe.set_ip_adapter_scale(float(ip_adapter_scale))
                generator_device = device if device != "mps" else "cpu"
                generator = torch.Generator(device=generator_device).manual_seed(int(seed))
                call_kwargs: dict[str, Any] = {
                    "prompt": prompt, "width": int(width), "height": int(height),
                    "guidance_scale": float(guidance_scale), "num_inference_steps": attempt_steps,
                    "max_sequence_length": int(self.env.get("FLUX_MAX_SEQUENCE_LENGTH", "512")),
                    "generator": generator,
                }
                if control_image is not None:
                    prepared = self.prepare_control_image(control_image, control_mode)
                    call_kwargs.update({
                        "control_image": prepared,
                        "controlnet_conditioning_scale": float(self.env.get("LOCAL_CONTROLNET_SCALE", "0.9") if controlnet_scale is None else controlnet_scale),
                        "control_guidance_start": 0.0,
                        "control_guidance_end": 1.0,
                    })
                if reference_image is not None:
                    call_kwargs["ip_adapter_image"] = reference_image.convert("RGB")
                result = pipe(**call_kwargs).images[0]
                if resize_factor != 1.0:
                    result = result.resize((int(width), int(height)), Image.Resampling.LANCZOS)
                quality_engine = MediaQualityEngine(self.cache_dir / "quality", self.env)
                result = quality_engine.clean_generated_image(result)
                output = io.BytesIO()
                result.save(output, format="PNG", optimize=True)
                return output.getvalue()
            except RuntimeError as exc:
                last_exc = exc
                if "out of memory" not in str(exc).lower() and "cuda" not in str(exc).lower():
                    raise
                clear_device_memory()
                gc.collect()
        raise RuntimeError(f"تعذر تشغيل Flux بعد محاولات الاسترداد: {last_exc}") from last_exc

    def _select_video_model(self, mode: str) -> str:
        if mode == "control":
            override = self.env.get("LOCAL_VIDEO_CONTROL_MODEL_ID", "auto").strip()
            if override and override.lower() != "auto":
                return override
            return select_best("video-control", self.env).repo_id
        if mode == "i2v":
            override = self.env.get("LOCAL_VIDEO_I2V_MODEL_ID", "auto").strip()
            if override and override.lower() != "auto":
                return override
            return select_best("video-i2v", self.env).repo_id
        override = self.env.get("LOCAL_VIDEO_MODEL_ID", "auto").strip()
        if override and override.lower() != "auto":
            return override
        return select_best("video", self.env).repo_id

    def _load_cog_pipeline(self, mode: str, model_id: str, dtype: Any, device: str) -> Any:
        key = (mode, model_id, self._dtype_name(dtype), device)
        if key in self._cog_cache:
            return self._cog_cache[key]
        auth = self._auth_kwargs()
        if mode == "control":
            if CogVideoXFunControlPipeline is None:
                raise RuntimeError("CogVideoXFunControlPipeline غير متاح.")
            pipe = CogVideoXFunControlPipeline.from_pretrained(model_id, torch_dtype=dtype, **auth)
        elif mode == "i2v":
            if CogVideoXImageToVideoPipeline is None:
                raise RuntimeError("CogVideoXImageToVideoPipeline غير متاح.")
            pipe = CogVideoXImageToVideoPipeline.from_pretrained(model_id, torch_dtype=dtype, **auth)
        else:
            if CogVideoXPipeline is None:
                raise RuntimeError("CogVideoXPipeline غير متاح.")
            pipe = CogVideoXPipeline.from_pretrained(model_id, torch_dtype=dtype, **auth)
        pipe, metadata = optimize_diffusion_pipeline(pipe, "cogvideox")
        setattr(pipe, "_ali_acceleration_metadata", metadata)
        self._cog_cache[key] = pipe
        return pipe

    def _model_video_size(self, mode: str, width: int, height: int) -> tuple[int, int]:
        model_name = self._select_video_model(mode).lower()
        is_15 = "1.5" in model_name or "1_5" in model_name
        if not is_15:
            return max(16, width - width % 16), max(16, height - height % 16)
        if mode in {"i2v", "t2v"}:
            ratio = max(0.25, min(4.0, width / max(1.0, height)))
            h = 768
            w = int(round(h * ratio / 16.0) * 16)
            w = max(768, min(1360, w))
            return w, h
        return max(768, int(round(width / 16.0) * 16)), max(480, int(round(height / 16.0) * 16))

    def _resize_video(self, input_path: Path, output_path: Path, width: int, height: int) -> None:
        import subprocess
        ffmpeg = os.getenv("FFMPEG_BINARY", "ffmpeg")
        command = [ffmpeg, "-y", "-i", str(input_path), "-vf", f"scale={int(width)}:{int(height)}:flags=lanczos", "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(output_path)]
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        if proc.returncode != 0 or not output_path.exists():
            raise RuntimeError(proc.stderr.decode("utf-8", errors="ignore")[-4000:])

    def generate_cogvideox(
        self,
        prompt: str,
        guidance_scale: float = 6.0,
        steps: int = 50,
        seed: int = 42,
        control_video_bytes: bytes | None = None,
        reference_image: Image.Image | None = None,
        width: int = 768,
        height: int = 480,
    ) -> bytes:
        self._require_diffusers()
        dtype = self._dtype()
        device = self._device()
        mode = "control" if control_video_bytes is not None else ("i2v" if reference_image is not None else "t2v")
        model_id = self._select_video_model(mode)
        model_width, model_height = self._model_video_size(mode, width, height)
        num_frames = int(self.env.get("LOCAL_VIDEO_NUM_FRAMES", "81"))
        if "1.5" in model_id.lower() and num_frames not in {81, 161}:
            num_frames = 81
        attempts = [(model_id, int(steps))]
        if mode in {"t2v", "i2v"} and "2b" not in model_id.lower():
            attempts.append(("THUDM/CogVideoX-2b", max(16, int(steps * 0.75))))
        last_exc: Exception | None = None
        for attempt_model, attempt_steps in attempts:
            try:
                pipe = self._load_cog_pipeline(mode, attempt_model, dtype, device)
                kwargs: dict[str, Any] = {
                    "prompt": prompt,
                    "guidance_scale": float(guidance_scale),
                    "num_inference_steps": int(attempt_steps),
                    "num_frames": num_frames,
                    "height": model_height,
                    "width": model_width,
                }
                if control_video_bytes is not None:
                    if load_video is None:
                        raise RuntimeError("دالة تحميل الفيديو غير متاحة في Diffusers الحالي.")
                    with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as handle:
                        handle.write(control_video_bytes)
                        control_path = handle.name
                    try:
                        kwargs["control_video"] = load_video(control_path)
                    finally:
                        Path(control_path).unlink(missing_ok=True)
                elif reference_image is not None:
                    kwargs["image"] = reference_image.convert("RGB").resize((model_width, model_height), Image.Resampling.LANCZOS)
                generator_device = device if device != "mps" else "cpu"
                kwargs["generator"] = torch.Generator(device=generator_device).manual_seed(int(seed))
                frames = pipe(**kwargs).frames[0]
                if export_to_video is None:
                    raise RuntimeError("export_to_video غير متاح في Diffusers الحالي.")
                raw_path = self.cache_dir / f"cogvideox_{os.getpid()}_{seed}_{attempt_model.replace('/', '_')}.mp4"
                export_to_video(frames, str(raw_path), fps=16 if "1.5" in attempt_model.lower() else 8)
                final_path = raw_path
                if (width, height) != (model_width, model_height):
                    resized = raw_path.with_name(raw_path.stem + "_final.mp4")
                    self._resize_video(raw_path, resized, width, height)
                    raw_path.unlink(missing_ok=True)
                    final_path = resized
                quality_engine = MediaQualityEngine(self.cache_dir / "quality", self.env)
                cleaned_path = final_path.with_name(final_path.stem + "_clean.mp4")
                quality_engine.clean_generated_video(final_path, cleaned_path)
                data = cleaned_path.read_bytes()
                final_path.unlink(missing_ok=True)
                cleaned_path.unlink(missing_ok=True)
                return data
            except RuntimeError as exc:
                last_exc = exc
                clear_device_memory()
                gc.collect()
        raise RuntimeError(f"تعذر تشغيل CogVideoX بعد محاولات الاسترداد: {last_exc}") from last_exc
