#!/usr/bin/env bash
set -euo pipefail

if [[ "${PREFETCH_MODELS_ON_START:-0}" == "1" ]]; then
  python scripts/prefetch_models.py --best --root "${MODEL_ROOT:-/app/data/models}"
fi

exec celery -A task_queue.celery_app worker \
  --loglevel="${CELERY_LOGLEVEL:-INFO}" \
  --concurrency="${CELERY_WORKER_CONCURRENCY:-1}" \
  --prefetch-multiplier=1 \
  --max-tasks-per-child="${CELERY_MAX_TASKS_PER_CHILD:-1}" \
  -Q "${CELERY_DEFAULT_QUEUE:-ai-heavy}"
