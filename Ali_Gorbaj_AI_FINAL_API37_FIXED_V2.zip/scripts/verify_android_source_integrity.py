from __future__ import annotations

import hashlib
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "ANDROID_STANDALONE_INTEGRITY.txt"
FILES = [
    "app.py",
    "hardware.py",
    "knowledge_engine.py",
    "controlled_generation.py",
    "long_video_engine.py",
    "lipsync.py",
    "task_queue.py",
    "omni_multimodal.py",
    "realtime_gateway.py",
    "swarm_orchestrator.py",
    "owned_media_cleanup.py",
    "tests_runtime.py",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_manifest(path: Path) -> dict[str, str]:
    if not path.is_file():
        raise SystemExit("Missing Android integrity manifest: ANDROID_STANDALONE_INTEGRITY.txt")
    entries: dict[str, str] = {}
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        match = re.fullmatch(r"([0-9a-f]{64})\s{2,}([^\s].*)", line.strip())
        if not match:
            continue  # Header/instructions may appear before the file list.
        digest, name = match.groups()
        if name in entries:
            raise SystemExit(f"Duplicate manifest entry at line {line_number}: {name}")
        entries[name] = digest
    return entries


manifest = read_manifest(MANIFEST)
expected_names = set(FILES)
manifest_names = set(manifest)
if manifest_names != expected_names:
    missing = sorted(expected_names - manifest_names)
    unexpected = sorted(manifest_names - expected_names)
    raise SystemExit(f"Integrity manifest file list mismatch; missing={missing}; unexpected={unexpected}")

for name in FILES:
    path = ROOT / name
    if not path.is_file():
        raise SystemExit(f"Missing core source: {name}")
    actual = sha256(path)
    expected = manifest[name]
    if actual != expected:
        raise SystemExit(f"SHA-256 mismatch for {name}: expected {expected}, got {actual}")
    print(f"{name}: SHA-256 OK")

print("Core source integrity check: OK")
