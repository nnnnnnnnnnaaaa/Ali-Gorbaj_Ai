from __future__ import annotations

import importlib.util
import json
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))
import shutil


def main() -> int:
    modules = ["streamlit", "torch", "transformers", "diffusers", "chromadb", "celery", "redis", "fastapi", "cv2", "TTS"]
    report = {"python": os.sys.version.split()[0], "ffmpeg": shutil.which("ffmpeg"), "git": shutil.which("git"), "modules": {name: bool(importlib.util.find_spec(name)) for name in modules}}
    try:
        from hardware import as_dict
        report["hardware"] = as_dict()
    except Exception as exc:
        report["hardware_error"] = str(exc)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
