from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from edge_runtime import discover_edge_models
from model_manager import catalog, disk_status
from hardware import as_dict


def main() -> int:
    payload = {
        "hardware": as_dict(),
        "disk": disk_status(),
        "local_model_catalog": catalog(),
        "edge_models": [record.__dict__ for record in discover_edge_models()],
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
