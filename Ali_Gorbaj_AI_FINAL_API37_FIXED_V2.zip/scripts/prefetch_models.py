from __future__ import annotations

import argparse
import json
from pathlib import Path

from model_manager import catalog, disk_status, prefetch, prefetch_best, select_best


def main() -> int:
    parser = argparse.ArgumentParser(description="Ali Gorbaj-AI local model manager")
    parser.add_argument("--best", action="store_true", help="Download the best model for the detected hardware")
    parser.add_argument("--repo", action="append", default=[], help="Hugging Face repository ID; can be repeated")
    parser.add_argument("--root", default=None, help="Local model cache root")
    parser.add_argument("--catalog", action="store_true", help="Print model catalog and exit")
    args = parser.parse_args()
    root = Path(args.root).resolve() if args.root else None
    if args.catalog:
        print(json.dumps({"catalog": catalog(), "disk": disk_status(root)}, ensure_ascii=False, indent=2))
        return 0
    if args.best:
        results = prefetch_best(root)
    else:
        results = [prefetch(repo, root=root) for repo in args.repo]
    print(json.dumps(results, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
