from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wav2lip", action="store_true")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--root", default="data/models")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    if args.wav2lip or args.all:
        from lipsync import Wav2LipLocalEngine
        env = dict(os.environ)
        env["WAV2LIP_AUTO_BOOTSTRAP"] = "1"
        engine = Wav2LipLocalEngine(root / "wav2lip", env)
        checkpoint = engine.prepare()
        print(f"Wav2Lip ready: {checkpoint}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
