#!/usr/bin/env bash
set -euo pipefail
ROOT="${MODEL_ROOT:-/app/data/models}"
mkdir -p "$ROOT"
python scripts/bootstrap_models.py --wav2lip --root "$ROOT"
python scripts/healthcheck.py
