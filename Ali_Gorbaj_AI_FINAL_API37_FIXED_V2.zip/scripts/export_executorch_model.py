from __future__ import annotations

import argparse
import importlib
import json
import os
from pathlib import Path
from typing import Any


def _load_factory(spec: str) -> Any:
    if ":" not in spec:
        raise ValueError("factory must use module:function syntax")
    module_name, function_name = spec.split(":", 1)
    module = importlib.import_module(module_name)
    factory = getattr(module, function_name, None)
    if factory is None or not callable(factory):
        raise AttributeError(f"Factory {spec!r} is missing or not callable")
    return factory


def _parse_shape(value: str) -> tuple[int, ...]:
    values = tuple(int(part.strip()) for part in value.split(",") if part.strip())
    if not values or any(item <= 0 for item in values):
        raise ValueError("example shape must contain positive integers")
    return values


def export_model(factory_spec: str, shape: tuple[int, ...], output: Path, dtype: str) -> dict[str, Any]:
    try:
        import torch
        from executorch.backends.xnnpack.partition.xnnpack_partitioner import XnnpackPartitioner
        from executorch.backends.xnnpack.utils.configs import get_xnnpack_edge_compile_config
        from executorch.exir import to_edge_transform_and_lower
    except ImportError as exc:
        raise RuntimeError("PyTorch and ExecuTorch export dependencies are required.") from exc

    factory = _load_factory(factory_spec)
    model = factory()
    if not isinstance(model, torch.nn.Module):
        raise TypeError("Factory must return a torch.nn.Module")
    model = model.eval()

    if dtype == "float16":
        sample = torch.randn(*shape, dtype=torch.float16)
    else:
        sample = torch.randn(*shape, dtype=torch.float32)

    with torch.no_grad():
        exported = torch.export.export(model, (sample,), strict=True)
        lowered = to_edge_transform_and_lower(
            exported,
            partitioner=[XnnpackPartitioner()],
            compile_config=get_xnnpack_edge_compile_config(),
        )
        program = lowered.to_executorch()

    output.parent.mkdir(parents=True, exist_ok=True)
    program.save(str(output))
    manifest = {
        "factory": factory_spec,
        "output": str(output.resolve()),
        "input_shape": list(shape),
        "dtype": dtype,
        "torch_version": str(torch.__version__),
        "python_version": os.sys.version,
        "backend": "xnnpack",
        "format": "executorch-pte",
    }
    manifest_path = output.with_suffix(output.suffix + ".json")
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description="Export an exportable torch.nn.Module to an Android ExecuTorch .pte model.")
    parser.add_argument("--factory", required=True, help="Import path in module:function form")
    parser.add_argument("--example-shape", default="1,3,224,224", help="Example input shape, comma-separated")
    parser.add_argument("--output", required=True, help="Output .pte path")
    parser.add_argument("--dtype", choices=("float32", "float16"), default="float32")
    args = parser.parse_args()
    manifest = export_model(args.factory, _parse_shape(args.example_shape), Path(args.output).resolve(), args.dtype)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
