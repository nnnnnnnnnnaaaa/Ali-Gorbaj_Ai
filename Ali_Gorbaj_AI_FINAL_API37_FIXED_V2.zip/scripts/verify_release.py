from __future__ import annotations

import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

EXPECTED = {
    ".github/workflows/build-apk.yml",
    "app.py",
    "android/settings.gradle",
    "android/build.gradle",
    "android/app/build.gradle",
    "android/app/src/main/AndroidManifest.xml",
}

FORBIDDEN_TEXT = [
    'android:usesCleartextTraffic="true"',
    'MIXED_CONTENT_COMPATIBILITY_MODE',
    'setAcceptThirdPartyCookies(webView, true)',
    'opencv-python-headless==4.5.1.48',
    'Pillow==9.2.0',
]

SECRET_PATTERNS = [
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    re.compile(r"(?i)\b(?:GROQ|POLLINATIONS)_API_KEY\s*=\s*[^\s#]{12,}"),
]

for rel in EXPECTED:
    path = ROOT / rel
    if not path.is_file():
        raise SystemExit(f"Missing required release file: {rel}")

# The Android host copies this exact asset directory to app-private storage.
# Guard the Gradle asset root against accidentally flattening the python_app folder.
gradle_text = (ROOT / "android/app/build.gradle").read_text(encoding="utf-8")
activity_text = (ROOT / "android/app/src/main/java/com/aligorbaj/ai/MainActivity.java").read_text(encoding="utf-8")
required_asset_wiring = [
    'def stagedAssetRoot = "$buildDir/generated/assets"',
    'def stagedPythonApp = "$buildDir/generated/assets/python_app"',
    'assets.srcDir(stagedAssetRoot)',
    'into(stagedPythonApp)',
]
for needle in required_asset_wiring:
    if needle not in gradle_text:
        raise SystemExit(f"Broken Android Python asset staging: missing {needle}")
if 'ASSET_ROOT = "python_app"' not in activity_text:
    raise SystemExit("Android runtime asset root does not match staged python_app directory")

# The Android build deliberately uses --no-deps because Chaquopy cannot resolve
# every desktop dependency. Require the pure-Python pieces needed by the embedded
# Streamlit ASGI server and GitPython to be explicitly pinned.
required_runtime_packages = [
    'install("websockets==15.0.1")',
    'install("itsdangerous==2.2.0")',
    'install("gitdb==4.0.12")',
]
for package_line in required_runtime_packages:
    if package_line not in gradle_text:
        raise SystemExit(f"Missing Android Python runtime dependency: {package_line}")

# Only one workflow in the release package.
workflows = sorted((ROOT / ".github/workflows").glob("*.yml"))
workflows += sorted((ROOT / ".github/workflows").glob("*.yaml"))
if [p.name for p in workflows] != ["build-apk.yml"]:
    raise SystemExit(f"Unexpected workflows: {[p.name for p in workflows]}")

SELF = Path(__file__).resolve()
for path in ROOT.rglob("*"):
    if not path.is_file() or path.resolve() == SELF:
        continue
    if any(part in {".git", "__pycache__", ".pytest_cache"} for part in path.parts):
        raise SystemExit(f"Generated/cache content included: {path}")
    if path.suffix.lower() in {".pyc", ".pyo"}:
        raise SystemExit(f"Compiled Python bytecode included: {path}")
    if path.name == ".env":
        raise SystemExit("Real .env must never ship in the release archive")
    try:
        text = path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        continue
    for needle in FORBIDDEN_TEXT:
        if needle in text:
            raise SystemExit(f"Forbidden insecure setting/dependency found in {path}: {needle}")
    # The example env file is intentionally made of placeholders.
    if path.name != ".env.example":
        for line in text.splitlines():
            if "os.getenv(" in line or "st.secrets" in line or "GITHUB_TOKEN" in line:
                continue
            for pattern in SECRET_PATTERNS:
                if pattern.search(line):
                    raise SystemExit(f"Possible embedded secret found in {path}")

# Basic zip path traversal check for any local test archives.
for archive in ROOT.glob("*.zip"):
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            if name.startswith("/") or name.startswith("../") or "/../" in name or name == "..":
                raise SystemExit(f"Unsafe archive member path: {name}")

print("Release security/integrity checks: OK")
