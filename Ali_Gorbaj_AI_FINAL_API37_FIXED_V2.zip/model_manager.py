from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

try:
    from huggingface_hub import HfApi, snapshot_download
except Exception:
    HfApi = None
    snapshot_download = None

from hardware import detect_hardware


@dataclass(frozen=True)
class ModelSpec:
    name: str
    repo_id: str
    kind: str
    min_vram_gb: float
    preferred_vram_gb: float
    quality_rank: int
    estimated_disk_gb: float


MODEL_CATALOG = (
    ModelSpec("flux-dev", "black-forest-labs/FLUX.1-dev", "image", 16.0, 32.0, 100, 60.0),
    ModelSpec("flux-schnell", "black-forest-labs/FLUX.1-schnell", "image", 8.0, 16.0, 90, 30.0),
    ModelSpec("cogvideox-1.5-5b", "THUDM/CogVideoX1.5-5B", "video", 10.0, 24.0, 100, 25.0),
    ModelSpec("cogvideox-1.5-5b-i2v", "THUDM/CogVideoX1.5-5B-I2V", "video-i2v", 10.0, 24.0, 100, 25.0),
    ModelSpec("cogvideox-5b-pose", "alibaba-pai/CogVideoX-Fun-V1.1-5b-Pose", "video-control", 10.0, 24.0, 95, 25.0),
    ModelSpec("cogvideox-2b", "THUDM/CogVideoX-2b", "video", 4.0, 10.0, 80, 15.0),
)


def select_best(kind: str, env: dict[str, str] | None = None) -> ModelSpec:
    env = env or os.environ
    override_key = {
        "image": "LOCAL_IMAGE_MODEL_ID",
        "video": "LOCAL_VIDEO_MODEL_ID",
        "video-i2v": "LOCAL_VIDEO_I2V_MODEL_ID",
        "video-control": "LOCAL_VIDEO_CONTROL_MODEL_ID",
    }.get(kind, "")
    override = env.get(override_key, "").strip()
    if override and override.lower() != "auto":
        for spec in MODEL_CATALOG:
            if spec.repo_id == override:
                return spec
        return ModelSpec("custom", override, kind, 0.0, 0.0, 50, float(os.getenv("CUSTOM_MODEL_ESTIMATED_DISK_GB", "20")))
    profile = detect_hardware()
    candidates = [x for x in MODEL_CATALOG if x.kind == kind]
    candidates.sort(key=lambda x: x.quality_rank, reverse=True)
    viable = [x for x in candidates if profile.gpu_memory_gb >= x.min_vram_gb or profile.device != "cuda"]
    if profile.device == "cuda" and viable:
        return viable[0]
    return candidates[-1] if candidates else ModelSpec("custom", override or "", kind, 0.0, 0.0, 0, 0.0)


def cache_root() -> Path:
    root = Path(os.getenv("MODEL_ROOT", "./data/models")).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def disk_status(root: Path | None = None) -> dict[str, Any]:
    root = root or cache_root()
    usage = shutil.disk_usage(root)
    return {
        "root": str(root),
        "total_gb": round(usage.total / (1024 ** 3), 2),
        "used_gb": round(usage.used / (1024 ** 3), 2),
        "free_gb": round(usage.free / (1024 ** 3), 2),
    }


def _manifest_path(root: Path, repo_id: str) -> Path:
    key = hashlib.sha256(repo_id.encode("utf-8")).hexdigest()[:16]
    return root / f"manifest_{key}.json"


def prefetch(repo_id: str, root: Path | None = None, revision: str | None = None) -> dict[str, Any]:
    if snapshot_download is None:
        raise RuntimeError("huggingface_hub غير مثبت.")
    root = root or cache_root()
    status = disk_status(root)
    requested_min_free = float(os.getenv("MODEL_MIN_FREE_GB", "10"))
    spec = next((item for item in MODEL_CATALOG if item.repo_id == repo_id), None)
    estimated_model_gb = spec.estimated_disk_gb if spec is not None else float(os.getenv("CUSTOM_MODEL_ESTIMATED_DISK_GB", "20"))
    required_free_gb = max(requested_min_free, estimated_model_gb + 5.0)
    if status["free_gb"] < required_free_gb:
        raise RuntimeError(
            f"المساحة الحرة غير كافية لتنزيل النموذج: {status['free_gb']} GB متاحة، "
            f"ويُفضّل وجود {required_free_gb} GB على الأقل."
        )
    local_dir = snapshot_download(
        repo_id=repo_id,
        revision=revision,
        cache_dir=str(root / "huggingface"),
        token=os.getenv("HF_TOKEN") or None,
        local_files_only=False,
    )
    files = []
    for path in Path(local_dir).rglob("*"):
        if path.is_file():
            files.append({"path": str(path.relative_to(local_dir)), "size": path.stat().st_size})
    payload = {
        "repo_id": repo_id,
        "revision": revision,
        "local_dir": local_dir,
        "downloaded_at": time.time(),
        "files": files,
    }
    _manifest_path(root, repo_id).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


def prefetch_best(root: Path | None = None) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for kind in ("image", "video", "video-i2v", "video-control"):
        spec = select_best(kind)
        if not spec.repo_id:
            continue
        result.append(prefetch(spec.repo_id, root=root))
    return result


def catalog() -> list[dict[str, Any]]:
    return [asdict(item) for item in MODEL_CATALOG]


if __name__ == "__main__":
    print(json.dumps({"hardware": detect_hardware().__dict__, "catalog": catalog(), "disk": disk_status()}, ensure_ascii=False, indent=2, default=str))
