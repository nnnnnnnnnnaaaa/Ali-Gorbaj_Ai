from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None


def _rect_to_pixels(rect: tuple[float, float, float, float], width: int, height: int) -> tuple[int, int, int, int]:
    x, y, w, h = rect
    x1 = max(0, min(width - 1, int(x * width)))
    y1 = max(0, min(height - 1, int(y * height)))
    x2 = max(x1 + 1, min(width, int((x + w) * width)))
    y2 = max(y1 + 1, min(height, int((y + h) * height)))
    return x1, y1, x2, y2


def auto_corner_overlay_mask(frame_bgr: np.ndarray, strength: int = 4) -> np.ndarray:
    """Detect likely high-contrast text-like overlays in corner ROIs.

    This detector is intended for user-owned media cleanup. It is deliberately conservative
    and only produces masks inside the four configurable corner regions.
    """
    if cv2 is None:
        raise RuntimeError("OpenCV غير مثبت.")
    h, w = frame_bgr.shape[:2]
    mask = np.zeros((h, w), dtype=np.uint8)
    frac = max(0.08, min(0.28, float(os.getenv("OWNED_OVERLAY_CORNER_FRACTION", "0.18"))))
    rois = [
        (0, 0, int(w * frac), int(h * frac)),
        (int(w * (1 - frac)), 0, w, int(h * frac)),
        (0, int(h * (1 - frac)), int(w * frac), h),
        (int(w * (1 - frac)), int(h * (1 - frac)), w, h),
    ]
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    for x1, y1, x2, y2 in rois:
        roi = gray[y1:y2, x1:x2]
        if roi.size == 0:
            continue
        blur = cv2.GaussianBlur(roi, (3, 3), 0)
        edges = cv2.Canny(blur, 80, 180)
        local_threshold = max(8, int(np.std(roi) * 0.75) + strength * 4)
        diff = cv2.absdiff(roi, blur)
        _, text_like = cv2.threshold(diff, local_threshold, 255, cv2.THRESH_BINARY)
        combined = cv2.bitwise_and(edges, text_like)
        kernel = np.ones((3, 3), np.uint8)
        combined = cv2.morphologyEx(combined, cv2.MORPH_CLOSE, kernel, iterations=2)
        combined = cv2.dilate(combined, kernel, iterations=1)
        mask[y1:y2, x1:x2] = cv2.bitwise_or(mask[y1:y2, x1:x2], combined)
    return mask


def cleanup_owned_image(input_path: str | Path, output_path: str | Path, rectangles: Iterable[tuple[float, float, float, float]] | None = None, auto_detect: bool = False) -> Path:
    if cv2 is None:
        raise RuntimeError("OpenCV غير مثبت.")
    image = cv2.imread(str(input_path), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("تعذر قراءة الصورة.")
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    h, w = mask.shape
    for rect in rectangles or []:
        x1, y1, x2, y2 = _rect_to_pixels(rect, w, h)
        mask[y1:y2, x1:x2] = 255
    if auto_detect:
        mask = cv2.bitwise_or(mask, auto_corner_overlay_mask(image))
    cleaned = cv2.inpaint(image, mask, 3, cv2.INPAINT_TELEA) if mask.any() else image
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(output), cleaned, [int(cv2.IMWRITE_PNG_COMPRESSION), 3]):
        raise RuntimeError("تعذر حفظ الصورة بعد المعالجة.")
    return output
