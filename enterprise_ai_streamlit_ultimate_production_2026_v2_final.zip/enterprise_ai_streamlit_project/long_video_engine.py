from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import tempfile
import uuid
from functools import lru_cache
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from PIL import Image

from hardware import configure_runtime
from lipsync import Wav2LipLocalEngine
from owned_media_cleanup import auto_corner_overlay_mask

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import torch
except ImportError:
    torch = None

try:
    from diffusers import CogVideoXImageToVideoPipeline
except ImportError:
    CogVideoXImageToVideoPipeline = None

try:
    from diffusers.utils import export_to_video, load_image
except ImportError:
    export_to_video = None
    load_image = None

try:
    from TTS.api import TTS
except ImportError:
    TTS = None

try:
    import imageio_ffmpeg
except ImportError:
    imageio_ffmpeg = None

ProgressCallback = Callable[[int, str], None]


@dataclass(frozen=True)
class LongVideoConfig:
    model_id: str = os.getenv("LOCAL_VIDEO_MODEL_ID", "THUDM/CogVideoX-2b")
    fps: int = int(os.getenv("LONG_VIDEO_FPS", "8"))
    chunk_seconds: int = int(os.getenv("LONG_VIDEO_CHUNK_SECONDS", "6"))
    overlap_frames: int = int(os.getenv("LONG_VIDEO_OVERLAP_FRAMES", "5"))
    max_seconds: int = int(os.getenv("LONG_VIDEO_MAX_SECONDS", "1800"))
    interpolation_fps: int = int(os.getenv("LONG_VIDEO_INTERPOLATION_FPS", "16"))
    use_interpolation: bool = os.getenv("LONG_VIDEO_INTERPOLATION", "1").lower() in {"1", "true", "yes", "on"}
    steps: int = int(os.getenv("LONG_VIDEO_STEPS", "28"))
    guidance_scale: float = float(os.getenv("LONG_VIDEO_GUIDANCE_SCALE", "6.0"))
    seed: int = int(os.getenv("LONG_VIDEO_SEED", "42"))
    audio_language: str = os.getenv("XTTS_LANGUAGE", "ar")
    tts_model: str = os.getenv("XTTS_MODEL_ID", "tts_models/multilingual/multi-dataset/xtts_v2")
    ffmpeg_threads: int = int(os.getenv("FFMPEG_THREADS", "2"))


class UltraLongVideoEngine:
    def __init__(self, work_root: str | Path, env: dict[str, str] | None = None) -> None:
        self.work_root = Path(work_root).resolve()
        self.work_root.mkdir(parents=True, exist_ok=True)
        self.env = env or os.environ
        self.cfg = LongVideoConfig()
        self.hardware = configure_runtime()
        self._pipe_cache: dict[tuple[str, str, str], Any] = {}
        self._tts_cache: dict[tuple[str, bool], Any] = {}

    def _ffmpeg(self) -> str:
        if imageio_ffmpeg is not None:
            return imageio_ffmpeg.get_ffmpeg_exe()
        path = shutil.which("ffmpeg")
        if path:
            return path
        raise RuntimeError("FFmpeg غير متاح. ثبّت imageio-ffmpeg أو ffmpeg على النظام.")

    def _device_dtype(self) -> tuple[str, Any]:
        if torch is None:
            raise RuntimeError("PyTorch غير مثبت.")
        if torch.cuda.is_available():
            dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
            return "cuda", dtype
        mps = getattr(torch.backends, "mps", None)
        if mps is not None and mps.is_available():
            return "mps", torch.float16
        return "cpu", torch.float32

    def _auth_kwargs(self) -> dict[str, Any]:
        token = self.env.get("HF_TOKEN", "").strip()
        return {"token": token} if token else {}

    def _pipeline(self) -> Any:
        if CogVideoXImageToVideoPipeline is None:
            raise RuntimeError("CogVideoXImageToVideoPipeline غير متاح في Diffusers.")
        device, dtype = self._device_dtype()
        key = (self.cfg.model_id, device, str(dtype))
        if key in self._pipe_cache:
            return self._pipe_cache[key]
        pipe = CogVideoXImageToVideoPipeline.from_pretrained(
            self.cfg.model_id,
            torch_dtype=dtype,
            **self._auth_kwargs(),
        )
        if device == "cuda" and hasattr(pipe, "enable_model_cpu_offload"):
            pipe.enable_model_cpu_offload()
        else:
            pipe.to(device)
        if hasattr(pipe, "vae") and hasattr(pipe.vae, "enable_slicing"):
            pipe.vae.enable_slicing()
        if hasattr(pipe, "vae") and hasattr(pipe.vae, "enable_tiling"):
            pipe.vae.enable_tiling()
        if hasattr(pipe, "enable_attention_slicing"):
            pipe.enable_attention_slicing("auto")
        self._pipe_cache[key] = pipe
        return pipe

    def _extract_last_frame(self, video_path: Path) -> Image.Image:
        if cv2 is None:
            raise RuntimeError("OpenCV مطلوب لاستخراج إطار الاستمرارية.")
        capture = cv2.VideoCapture(str(video_path))
        if not capture.isOpened():
            capture.release()
            raise RuntimeError("تعذر فتح مقطع الفيديو الناتج.")
        total = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        if total > 1:
            capture.set(cv2.CAP_PROP_POS_FRAMES, total - 1)
        ok, frame = capture.read()
        capture.release()
        if not ok or frame is None:
            raise RuntimeError("تعذر استخراج آخر إطار من المقطع.")
        return Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)).convert("RGB")

    def _generate_chunk(
        self,
        prompt: str,
        anchor: Image.Image,
        output_path: Path,
        seed: int,
        width: int,
        height: int,
        duration_seconds: float,
        extra_frames: int = 0,
    ) -> None:
        pipe = self._pipeline()
        device, _ = self._device_dtype()
        generator_device = device if device != "mps" else "cpu"
        generator = torch.Generator(device=generator_device).manual_seed(int(seed))
        kwargs = {
            "image": anchor.resize((width, height)),
            "prompt": prompt,
            "height": height,
            "width": width,
            "num_frames": max(9, int(round(self.cfg.fps * max(0.5, duration_seconds))) + 1 + max(0, int(extra_frames))),
            "num_inference_steps": self.cfg.steps,
            "guidance_scale": self.cfg.guidance_scale,
            "generator": generator,
            "use_dynamic_cfg": True,
        }
        result = pipe(**kwargs)
        frames = result.frames[0]
        if export_to_video is None:
            raise RuntimeError("export_to_video غير متاح في إصدار Diffusers الحالي.")
        export_to_video(frames, str(output_path), fps=self.cfg.fps)

    def _trim_chunk_head(self, input_path: Path, output_path: Path, skip_frames: int) -> None:
        if skip_frames <= 0:
            shutil.copy2(input_path, output_path)
            return
        if cv2 is None:
            raise RuntimeError("OpenCV مطلوب لإزالة الإطارات المتداخلة بين المقاطع.")
        reader = cv2.VideoCapture(str(input_path))
        if not reader.isOpened():
            raise RuntimeError("تعذر فتح المقطع لقص الإطارات المتداخلة.")
        fps = reader.get(cv2.CAP_PROP_FPS) or self.cfg.fps
        width = int(reader.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(reader.get(cv2.CAP_PROP_FRAME_HEIGHT))
        writer = cv2.VideoWriter(str(output_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height))
        if not writer.isOpened():
            reader.release()
            raise RuntimeError("تعذر إنشاء المقطع بعد قص الإطارات.")
        try:
            for _ in range(skip_frames):
                if not reader.grab():
                    break
            while True:
                ok, frame = reader.read()
                if not ok:
                    break
                writer.write(frame)
        finally:
            reader.release()
            writer.release()
        if not output_path.exists():
            raise RuntimeError("فشل حفظ المقطع بعد قص التداخل.")

    def _concat_chunks(self, chunk_paths: list[Path], output_path: Path) -> None:
        ffmpeg = self._ffmpeg()
        with tempfile.TemporaryDirectory(prefix="nova_concat_") as temp_dir:
            concat_file = Path(temp_dir) / "concat.txt"
            lines = [f"file '{p.as_posix().replace("'", "'\\''")}'" for p in chunk_paths]
            concat_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
            command = [
                ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
                "-c:v", "libx264", "-preset", "medium", "-crf", "18",
                "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-threads", str(self.cfg.ffmpeg_threads),
                str(output_path),
            ]
            proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            if proc.returncode != 0 or not output_path.exists():
                raise RuntimeError(f"تعذر دمج المقاطع: {proc.stderr.decode('utf-8', errors='ignore')[-4000:]}")

    def _interpolate(self, input_path: Path, output_path: Path) -> None:
        if not self.cfg.use_interpolation or self.cfg.interpolation_fps <= self.cfg.fps:
            shutil.copy2(input_path, output_path)
            return
        ffmpeg = self._ffmpeg()
        filter_value = f"minterpolate=fps={self.cfg.interpolation_fps}:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1"
        command = [
            ffmpeg, "-y", "-i", str(input_path), "-vf", filter_value,
            "-c:v", "libx264", "-preset", "medium", "-crf", "18",
            "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-threads", str(self.cfg.ffmpeg_threads),
            str(output_path),
        ]
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        if proc.returncode != 0 or not output_path.exists():
            raise RuntimeError(f"تعذر تنفيذ interpolation: {proc.stderr.decode('utf-8', errors='ignore')[-4000:]}")

    def synthesize_xtts(
        self,
        text: str,
        output_path: Path,
        language: str | None = None,
        speaker_wav: str | None = None,
        speed: float = 1.0,
    ) -> Path:
        if TTS is None:
            raise RuntimeError("حزمة coqui-tts غير مثبتة؛ لا يمكن تشغيل XTTS-v2 المحلي.")
        language = (language or self.cfg.audio_language or "en").strip().lower()
        device, _ = self._device_dtype()
        key = (self.cfg.tts_model, device == "cuda")
        if key not in self._tts_cache:
            self._tts_cache[key] = TTS(self.cfg.tts_model, gpu=device == "cuda")
        model = self._tts_cache[key]
        kwargs: dict[str, Any] = {
            "text": text.strip(),
            "file_path": str(output_path),
            "language": language,
            "split_sentences": True,
        }
        if speaker_wav:
            kwargs["speaker_wav"] = [speaker_wav]
        else:
            kwargs["speaker"] = self.env.get("XTTS_DEFAULT_SPEAKER", "Ana Florence")
        model.tts_to_file(**kwargs)
        speed = max(0.5, min(2.0, float(speed)))
        if abs(speed - 1.0) > 0.001:
            ffmpeg = self._ffmpeg()
            adjusted = output_path.with_name(output_path.stem + "_speed.wav")
            tempo = speed
            filters: list[str] = []
            while tempo < 0.5:
                filters.append("atempo=0.5")
                tempo *= 2.0
            while tempo > 2.0:
                filters.append("atempo=2.0")
                tempo /= 2.0
            filters.append(f"atempo={tempo:g}")
            command = [ffmpeg, "-y", "-i", str(output_path), "-filter:a", ",".join(filters), str(adjusted)]
            proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            if proc.returncode != 0 or not adjusted.exists():
                raise RuntimeError("تعذر ضبط سرعة الصوت المحلي XTTS.")
            adjusted.replace(output_path)
        return output_path

    def apply_owned_overlay_cleanup(self, input_path: Path, output_path: Path, rectangles: list[dict[str, float]]) -> Path:
        """Clean only explicitly declared user-owned overlays.

        This function intentionally requires caller-provided normalized rectangles. It does not
        detect or remove arbitrary third-party watermarks or logos.
        """
        if not rectangles:
            shutil.copy2(input_path, output_path)
            return output_path
        if cv2 is None:
            raise RuntimeError("OpenCV مطلوب لمعالجة overlay المملوك.")
        reader = cv2.VideoCapture(str(input_path))
        if not reader.isOpened():
            raise RuntimeError("تعذر فتح الفيديو لتنظيف الـoverlay المملوك.")
        fps = reader.get(cv2.CAP_PROP_FPS) or self.cfg.fps
        width = int(reader.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(reader.get(cv2.CAP_PROP_FRAME_HEIGHT))
        codec = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(output_path), codec, fps, (width, height))
        if not writer.isOpened():
            reader.release()
            raise RuntimeError("تعذر إنشاء ملف الفيديو النهائي.")
        try:
            while True:
                ok, frame = reader.read()
                if not ok:
                    break
                mask = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) * 0
                for rect in rectangles:
                    x1 = max(0, min(width - 1, int(float(rect.get("x", 0.0)) * width)))
                    y1 = max(0, min(height - 1, int(float(rect.get("y", 0.0)) * height)))
                    x2 = max(x1 + 1, min(width, int((float(rect.get("x", 0.0)) + float(rect.get("w", 0.0))) * width)))
                    y2 = max(y1 + 1, min(height, int((float(rect.get("y", 0.0)) + float(rect.get("h", 0.0))) * height)))
                    mask[y1:y2, x1:x2] = 255
                if self.env.get("OWNED_OVERLAY_AUTO_DETECT", "0").lower() in {"1", "true", "yes", "on"}:
                    detected_mask = auto_corner_overlay_mask(frame)
                    mask = cv2.bitwise_or(mask, detected_mask)
                if mask.any():
                    frame = cv2.inpaint(frame, mask, 3, cv2.INPAINT_TELEA)
                writer.write(frame)
        finally:
            reader.release()
            writer.release()
        if not output_path.exists():
            raise RuntimeError("فشل إخراج الفيديو بعد overlay cleanup.")
        return output_path

    def mux_audio(self, video_path: Path, audio_path: Path, output_path: Path) -> Path:
        ffmpeg = self._ffmpeg()
        command = [
            ffmpeg, "-y", "-i", str(video_path), "-stream_loop", "-1", "-i", str(audio_path),
            "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy",
            "-af", "aresample=async=1:first_pts=0", "-c:a", "aac", "-b:a", "192k",
            "-shortest", "-movflags", "+faststart", str(output_path),
        ]
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        if proc.returncode != 0 or not output_path.exists():
            raise RuntimeError(f"تعذر دمج الصوت: {proc.stderr.decode('utf-8', errors='ignore')[-4000:]}")
        return output_path

    def optional_lipsync(self, video_path: Path, audio_path: Path, output_path: Path) -> Path:
        engine_name = self.env.get("LIPSYNC_ENGINE", "wav2lip").strip().lower()
        if engine_name in {"wav2lip", "local"}:
            engine = Wav2LipLocalEngine(self.work_root / "lipsync", self.env)
            try:
                return engine.sync(video_path, audio_path, output_path)
            except Exception:
                if self.env.get("LIPSYNC_STRICT", "0").lower() in {"1", "true", "yes", "on"}:
                    raise
        endpoint = self.env.get("LIPSYNC_ENDPOINT", "").strip()
        if endpoint:
            import requests
            with video_path.open("rb") as video_file, audio_path.open("rb") as audio_file:
                response = requests.post(
                    endpoint,
                    files={"video": (video_path.name, video_file, "video/mp4"), "audio": (audio_path.name, audio_file, "audio/wav")},
                    timeout=(15, 1800),
                )
            response.raise_for_status()
            output_path.write_bytes(response.content)
            return output_path
        shutil.copy2(video_path, output_path)
        return output_path

    def generate(
        self,
        prompt: str,
        total_seconds: int,
        width: int,
        height: int,
        seed: int | None = None,
        reference_image_path: str | None = None,
        narration_text: str | None = None,
        narration_language: str | None = None,
        speaker_wav_path: str | None = None,
        tts_speed: float = 1.0,
        progress: ProgressCallback | None = None,
    ) -> dict[str, Any]:
        if not prompt.strip():
            raise ValueError("وصف الفيديو لا يمكن أن يكون فارغًا.")
        total_seconds = int(total_seconds)
        if total_seconds < 1 or total_seconds > self.cfg.max_seconds:
            raise ValueError(f"المدة يجب أن تكون بين 1 و{self.cfg.max_seconds} ثانية.")
        seed = self.cfg.seed if seed is None else int(seed)
        run_id = uuid.uuid4().hex
        run_dir = self.work_root / f"long_video_{run_id}"
        run_dir.mkdir(parents=True, exist_ok=True)
        chunk_paths: list[Path] = []
        try:
            if reference_image_path:
                anchor = Image.open(reference_image_path).convert("RGB")
            else:
                try:
                    from controlled_generation import ControlledGenerationService
                    starter_service = ControlledGenerationService(self.work_root / "starter_models", self.env)
                    starter_bytes = starter_service.generate_flux(
                        prompt=prompt,
                        width=width,
                        height=height,
                        guidance_scale=self.cfg.guidance_scale,
                        steps=max(16, self.cfg.steps),
                        seed=seed,
                    )
                    starter_path = run_dir / "starter.png"
                    starter_path.write_bytes(starter_bytes)
                    anchor = Image.open(starter_path).convert("RGB")
                except Exception as exc:
                    raise RuntimeError(f"تعذر إنشاء الإطار الابتدائي تلقائيًا عبر Flux: {exc}") from exc
            effective_chunk_seconds = max(1, min(self.cfg.chunk_seconds, self.hardware.recommended_video_chunk_seconds))
            chunks = max(1, math.ceil(total_seconds / effective_chunk_seconds))
            for index in range(chunks):
                start_second = index * effective_chunk_seconds
                remaining = total_seconds - start_second
                chunk_seconds = min(effective_chunk_seconds, remaining)
                chunk_path = run_dir / f"chunk_{index:04d}.mp4"
                continuation = (
                    f"Continue the same shot seamlessly from the anchor frame. Maintain exact character identity, face, clothing, lighting, environment, camera style and color grade. "
                    f"Scene segment {index + 1}/{chunks}, target duration about {chunk_seconds} seconds. {prompt.strip()}"
                )
                overlap_extra = self.cfg.overlap_frames if index > 0 else 0
                self._generate_chunk(
                    continuation,
                    anchor,
                    chunk_path,
                    seed + index,
                    width,
                    height,
                    duration_seconds=chunk_seconds,
                    extra_frames=overlap_extra,
                )
                anchor = self._extract_last_frame(chunk_path)
                if index > 0 and self.cfg.overlap_frames > 0:
                    trimmed_path = run_dir / f"chunk_{index:04d}_trimmed.mp4"
                    skip_frames = min(
                        self.cfg.overlap_frames,
                        max(0, int(round(self.cfg.fps * chunk_seconds)) - 1),
                    )
                    self._trim_chunk_head(chunk_path, trimmed_path, skip_frames)
                    chunk_paths.append(trimmed_path)
                else:
                    chunk_paths.append(chunk_path)
                try:
                    import gc
                    gc.collect()
                    if torch is not None and self.hardware.device == "cuda":
                        torch.cuda.empty_cache()
                except Exception:
                    pass
                if progress:
                    progress(10 + int(((index + 1) / chunks) * 55), f"تم توليد المقطع {index + 1} من {chunks}")

            concatenated = run_dir / "concatenated.mp4"
            self._concat_chunks(chunk_paths, concatenated)
            if progress:
                progress(70, "تم دمج المقاطع مع الحفاظ على نقطة استمرارية لكل جزء")

            interpolated = run_dir / "interpolated.mp4"
            self._interpolate(concatenated, interpolated)
            if progress:
                progress(78, "تمت معالجة الإطارات لرفع سلاسة الحركة")

            final_video = interpolated
            if narration_text and narration_text.strip():
                audio_path = run_dir / "narration.wav"
                self.synthesize_xtts(narration_text, audio_path, narration_language, speaker_wav_path, tts_speed)
                lipsynced = run_dir / "lipsynced.mp4"
                self.optional_lipsync(final_video, audio_path, lipsynced)
                muxed = run_dir / "final_with_audio.mp4"
                self.mux_audio(lipsynced, audio_path, muxed)
                final_video = muxed
                if progress:
                    progress(92, "تم توليد XTTS-v2 ودمج الصوت مع الفيديو")

            cleanup_rects = json.loads(self.env.get("OWNED_OVERLAY_RECTS", "[]") or "[]")
            auto_cleanup = self.env.get("OWNED_OVERLAY_AUTO_DETECT", "0").lower() in {"1", "true", "yes", "on"}
            if cleanup_rects or auto_cleanup:
                cleaned = run_dir / "cleaned.mp4"
                self.apply_owned_overlay_cleanup(final_video, cleaned, cleanup_rects)
                final_video = cleaned
                if progress:
                    progress(97, "تم تنظيف overlays المملوكة وفق المناطق المحددة")

            result_path = run_dir / "result.mp4"
            shutil.copy2(final_video, result_path)
            if progress:
                progress(100, "اكتمل إنتاج الفيديو الطويل")
            return {
                "path": str(result_path),
                "mime_type": "video/mp4",
                "duration_seconds": total_seconds,
                "chunks": chunks,
                "fps": self.cfg.interpolation_fps if self.cfg.use_interpolation and self.cfg.interpolation_fps > self.cfg.fps else self.cfg.fps,
                "run_id": run_id,
                "hardware": {
                    "device": self.hardware.device,
                    "gpu": self.hardware.gpu_name,
                    "gpu_memory_gb": self.hardware.gpu_memory_gb,
                    "recommended_quantization": self.hardware.recommended_quantization,
                },
            }
        except Exception:
            raise


@lru_cache(maxsize=2)
def get_long_video_engine(work_root: str) -> UltraLongVideoEngine:
    return UltraLongVideoEngine(work_root)
