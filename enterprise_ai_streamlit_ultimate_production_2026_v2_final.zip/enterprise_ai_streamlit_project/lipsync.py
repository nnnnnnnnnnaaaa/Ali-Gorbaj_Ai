from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Iterable

try:
    import requests
except ImportError:
    requests = None

try:
    import gdown
except ImportError:
    gdown = None


class Wav2LipLocalEngine:
    """Local Wav2Lip runner with deterministic bootstrap and OOM-aware retries."""

    DEFAULT_REPO = "https://github.com/Rudrabha/Wav2Lip.git"
    DEFAULT_GAN_FILE_ID = "15G3U08c8xsCkOqQxE38Z2XXDnPcOptNk"

    def __init__(self, root: str | Path, env: dict[str, str] | None = None) -> None:
        self.root = Path(root).resolve()
        self.repo = self.root / "Wav2Lip"
        self.checkpoints = self.repo / "checkpoints"
        self.env = env or os.environ
        self.root.mkdir(parents=True, exist_ok=True)
        self.checkpoints.mkdir(parents=True, exist_ok=True)

    @property
    def checkpoint_path(self) -> Path:
        return self.checkpoints / self.env.get("WAV2LIP_CHECKPOINT_NAME", "wav2lip_gan.pth")

    def _run(self, command: list[str], timeout: int = 3600) -> subprocess.CompletedProcess[str]:
        proc = subprocess.run(
            command,
            cwd=str(self.repo) if self.repo.exists() else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
            check=False,
            env={**os.environ, **self.env},
        )
        if proc.returncode != 0:
            raise RuntimeError(proc.stdout[-8000:])
        return proc

    def _verify_sha256(self, path: Path) -> None:
        expected = self.env.get("WAV2LIP_CHECKPOINT_SHA256", "").strip().lower()
        if not expected:
            return
        digest = hashlib.sha256(path.read_bytes()).hexdigest().lower()
        if digest != expected:
            raise RuntimeError(f"Wav2Lip checkpoint SHA256 mismatch: expected {expected}, got {digest}")

    def ensure_repo(self) -> Path:
        if (self.repo / "inference.py").exists() and (self.repo / "models.py").exists():
            return self.repo
        if not shutil.which("git"):
            raise RuntimeError("Git is required to bootstrap the local Wav2Lip runtime.")
        repo_url = self.env.get("WAV2LIP_REPO_URL", self.DEFAULT_REPO).strip()
        branch = self.env.get("WAV2LIP_REPO_REF", "master").strip()
        tmp_dir = self.root / "Wav2Lip.bootstrap"
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir)
        self._run_git_clone(repo_url, branch, tmp_dir)
        if self.repo.exists():
            shutil.rmtree(self.repo)
        tmp_dir.rename(self.repo)
        return self.repo

    def _run_git_clone(self, repo_url: str, branch: str, target: Path) -> None:
        command = ["git", "clone", "--depth", "1", "--branch", branch, repo_url, str(target)]
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=900, check=False)
        if proc.returncode != 0:
            raise RuntimeError(f"تعذر تنزيل Wav2Lip محليًا: {proc.stdout[-8000:]}")

    def ensure_checkpoint(self) -> Path:
        self.ensure_repo()
        if self.checkpoint_path.exists() and self.checkpoint_path.stat().st_size > 20_000_000:
            self._verify_sha256(self.checkpoint_path)
            return self.checkpoint_path
        if gdown is None and not requests:
            raise RuntimeError("gdown أو requests مطلوبان لتنزيل وزن Wav2Lip مرة واحدة.")
        url = self.env.get("WAV2LIP_CHECKPOINT_URL", "").strip()
        file_id = self.env.get("WAV2LIP_CHECKPOINT_FILE_ID", self.DEFAULT_GAN_FILE_ID).strip()
        target = self.checkpoint_path
        partial = target.with_suffix(target.suffix + ".part")
        if partial.exists():
            partial.unlink()
        if url.startswith("https://drive.google.com/") and gdown is not None:
            gdown.download(url=url, output=str(partial), quiet=False, fuzzy=True, resume=True)
        elif file_id and gdown is not None:
            gdown.download(id=file_id, output=str(partial), quiet=False, resume=True)
        elif url and requests is not None:
            with requests.get(url, stream=True, timeout=(15, 1800)) as response:
                response.raise_for_status()
                with partial.open("wb") as handle:
                    for chunk in response.iter_content(chunk_size=1024 * 1024):
                        if chunk:
                            handle.write(chunk)
        else:
            raise RuntimeError("لم يتم تعريف WAV2LIP_CHECKPOINT_URL أو WAV2LIP_CHECKPOINT_FILE_ID صالح.")
        if not partial.exists() or partial.stat().st_size < 20_000_000:
            raise RuntimeError("فشل تنزيل وزن Wav2Lip أو كان الملف ناقصًا.")
        partial.replace(target)
        self._verify_sha256(target)
        return target

    def install_runtime_dependencies(self) -> None:
        required = ("librosa", "scipy", "tqdm")
        missing = [name for name in required if __import__("importlib").util.find_spec(name) is None]
        if missing:
            raise RuntimeError(
                "متطلبات Wav2Lip غير متاحة في بيئة التطبيق: " + ", ".join(missing) + ". "
                "ثبت requirements.txt الخاص بالمشروع قبل تشغيل Wav2Lip."
            )

    def prepare(self) -> Path:
        if os.getenv("WAV2LIP_AUTO_BOOTSTRAP", "0").lower() not in {"1", "true", "yes", "on"}:
            if not (self.repo / "inference.py").exists() or not self.checkpoint_path.exists():
                raise RuntimeError("Wav2Lip غير مهيأ محليًا. فعّل WAV2LIP_AUTO_BOOTSTRAP=1 للتهيئة التلقائية.")
        self.ensure_repo()
        self.install_runtime_dependencies()
        return self.ensure_checkpoint()

    def _candidate_batch_sizes(self) -> Iterable[int]:
        raw = self.env.get("WAV2LIP_BATCH_SIZES", "16,8,4,2,1")
        for item in raw.split(","):
            try:
                value = max(1, int(item.strip()))
            except ValueError:
                continue
            yield value

    def sync(self, video_path: str | Path, audio_path: str | Path, output_path: str | Path, pads: tuple[int, int, int, int] = (0, 10, 0, 0)) -> Path:
        video_path = Path(video_path).resolve()
        audio_path = Path(audio_path).resolve()
        output_path = Path(output_path).resolve()
        if not video_path.is_file() or not audio_path.is_file():
            raise FileNotFoundError("فيديو أو صوت الإدخال غير موجود.")
        checkpoint = self.prepare()
        inference = self.repo / "inference.py"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="wav2lip_") as temp:
            temp_output = Path(temp) / "synced.mp4"
            base = [
                sys.executable,
                str(inference),
                "--checkpoint_path", str(checkpoint),
                "--face", str(video_path),
                "--audio", str(audio_path),
                "--outfile", str(temp_output),
                "--pads", *[str(x) for x in pads],
            ]
            last_error = ""
            for batch_size in self._candidate_batch_sizes():
                command = [*base, "--face_det_batch_size", str(batch_size), "--wav2lip_batch_size", str(batch_size)]
                try:
                    self._run(command, timeout=int(self.env.get("WAV2LIP_TIMEOUT_SECONDS", "10800")))
                    if temp_output.exists() and temp_output.stat().st_size > 100_000:
                        shutil.copy2(temp_output, output_path)
                        return output_path
                except (RuntimeError, subprocess.TimeoutExpired) as exc:
                    last_error = str(exc)
                    if "out of memory" not in last_error.lower() and "cuda" not in last_error.lower():
                        raise
            raise RuntimeError(f"فشل Wav2Lip بعد خفض batch size تدريجيًا: {last_error[-5000:]}")
