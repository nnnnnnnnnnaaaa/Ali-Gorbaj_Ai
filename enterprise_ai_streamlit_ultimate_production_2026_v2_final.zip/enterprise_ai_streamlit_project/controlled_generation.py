from __future__ import annotations

import io
import os
import tempfile
from pathlib import Path
from typing import Any

from PIL import Image

try:
    import numpy as np
except ImportError:
    np = None

try:
    import torch
except ImportError:
    torch = None

try:
    from diffusers import (
        CogVideoXFunControlPipeline,
        CogVideoXImageToVideoPipeline,
        CogVideoXPipeline,
        FluxControlNetModel,
        FluxControlNetPipeline,
        FluxPipeline,
    )
    from diffusers.utils import export_to_video, load_video
except ImportError:
    CogVideoXFunControlPipeline = None
    CogVideoXImageToVideoPipeline = None
    CogVideoXPipeline = None
    FluxControlNetModel = None
    FluxControlNetPipeline = None
    FluxPipeline = None
    export_to_video = None
    load_video = None

try:
    import cv2
except ImportError:
    cv2 = None


class ControlledGenerationService:
    """Local image/video generation service with control and reference consistency.

    Pipelines are retained in a small in-process cache because Streamlit reruns the
    Python script frequently. This avoids re-downloading/rebuilding the same model
    on every button click while keeping cache scope limited to the current process.
    """

    def __init__(self, cache_dir: str | Path, env: dict[str, str] | None = None) -> None:
        self.cache_dir = Path(cache_dir).resolve()
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.env = env or os.environ
        self._flux_cache: dict[tuple[Any, ...], Any] = {}
        self._cog_cache: dict[tuple[Any, ...], Any] = {}

    def _require_diffusers(self) -> None:
        if torch is None or FluxPipeline is None:
            raise RuntimeError("لم يتم تثبيت PyTorch/Diffusers. ثبّت الاعتماديات المحلية للجيل المتحكم به.")

    def _device(self) -> str:
        if torch is not None and torch.cuda.is_available():
            return "cuda"
        if torch is not None and getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
            return "mps"
        return "cpu"

    def _dtype(self) -> Any:
        device = self._device()
        if device == "cuda":
            return torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        if device == "mps":
            return torch.float16
        return torch.float32

    def _auth_kwargs(self) -> dict[str, Any]:
        token = self.env.get("HF_TOKEN", "").strip()
        return {"token": token} if token else {}

    @staticmethod
    def _dtype_name(dtype: Any) -> str:
        return str(dtype).replace("torch.", "")

    def _move_or_offload(self, pipe: Any, device: str) -> Any:
        if device == "cuda" and hasattr(pipe, "enable_model_cpu_offload"):
            pipe.enable_model_cpu_offload()
        else:
            pipe.to(device)
        return pipe

    def prepare_control_image(self, image: Image.Image, mode: str) -> Image.Image:
        rgb = image.convert("RGB")
        if mode == "canny":
            if cv2 is None or np is None:
                raise RuntimeError("OpenCV وNumPy مطلوبان لإنشاء Canny ControlNet.")
            arr = cv2.cvtColor(np.array(rgb), cv2.COLOR_RGB2GRAY)
            edges = cv2.Canny(arr, 100, 200)
            return Image.fromarray(edges).convert("RGB")
        if mode in {"depth", "pose", "sketch"}:
            return rgb
        raise ValueError("نوع التحكم غير معروف.")

    def _load_flux_pipeline(
        self,
        base_model: str,
        control_model: str,
        use_control: bool,
        reference_enabled: bool,
        ip_repo: str,
        ip_weight: str,
        image_encoder: str,
        dtype: Any,
        device: str,
    ) -> Any:
        key = (
            base_model,
            control_model,
            use_control,
            reference_enabled,
            ip_repo,
            ip_weight,
            image_encoder,
            self._dtype_name(dtype),
            device,
        )
        if key in self._flux_cache:
            return self._flux_cache[key]
        kwargs = {"torch_dtype": dtype, **self._auth_kwargs()}
        if use_control:
            if FluxControlNetPipeline is None or FluxControlNetModel is None:
                raise RuntimeError("Flux ControlNet غير متاح في إصدار Diffusers الحالي.")
            controlnet = FluxControlNetModel.from_pretrained(control_model, **kwargs)
            pipe = FluxControlNetPipeline.from_pretrained(base_model, controlnet=controlnet, **kwargs)
        else:
            pipe = FluxPipeline.from_pretrained(base_model, **kwargs)
        if reference_enabled:
            pipe.load_ip_adapter(
                ip_repo,
                weight_name=ip_weight,
                image_encoder_pretrained_model_name_or_path=image_encoder,
            )
        pipe = self._move_or_offload(pipe, device)
        self._flux_cache[key] = pipe
        return pipe

    def generate_flux(
        self,
        prompt: str,
        width: int,
        height: int,
        guidance_scale: float,
        steps: int,
        seed: int,
        control_image: Image.Image | None = None,
        reference_image: Image.Image | None = None,
        control_mode: str = "canny",
        controlnet_scale: float | None = None,
        ip_adapter_scale: float = 0.75,
    ) -> bytes:
        self._require_diffusers()
        base_model = self.env.get("LOCAL_IMAGE_MODEL_ID", "black-forest-labs/FLUX.1-dev")
        control_model = self.env.get("LOCAL_CONTROLNET_MODEL_ID", "InstantX/FLUX.1-dev-Controlnet-Canny")
        ip_repo = self.env.get("LOCAL_IP_ADAPTER_REPO", "XLabs-AI/flux-ip-adapter")
        ip_weight = self.env.get("LOCAL_IP_ADAPTER_WEIGHT", "ip_adapter.safetensors")
        image_encoder = self.env.get("LOCAL_IP_ADAPTER_IMAGE_ENCODER", "openai/clip-vit-large-patch14")
        dtype = self._dtype()
        device = self._device()
        pipe = self._load_flux_pipeline(
            base_model,
            control_model,
            control_image is not None,
            reference_image is not None,
            ip_repo,
            ip_weight,
            image_encoder,
            dtype,
            device,
        )
        if reference_image is not None:
            if not hasattr(pipe, "set_ip_adapter_scale"):
                raise RuntimeError("النموذج الحالي لا يدعم IP-Adapter عبر Diffusers.")
            pipe.set_ip_adapter_scale(float(ip_adapter_scale))
        generator_device = device if device != "mps" else "cpu"
        generator = torch.Generator(device=generator_device).manual_seed(int(seed))
        call_kwargs: dict[str, Any] = {
            "prompt": prompt,
            "width": int(width),
            "height": int(height),
            "guidance_scale": float(guidance_scale),
            "num_inference_steps": int(steps),
            "generator": generator,
        }
        if control_image is not None:
            prepared = self.prepare_control_image(control_image, control_mode)
            call_kwargs.update(
                {
                    "control_image": prepared,
                    "controlnet_conditioning_scale": float(
                        self.env.get("LOCAL_CONTROLNET_SCALE", "0.9")
                        if controlnet_scale is None
                        else controlnet_scale
                    ),
                    "control_guidance_start": 0.0,
                    "control_guidance_end": 1.0,
                }
            )
        if reference_image is not None:
            call_kwargs["ip_adapter_image"] = reference_image.convert("RGB")
        result = pipe(**call_kwargs).images[0]
        output = io.BytesIO()
        result.save(output, format="PNG", optimize=True)
        return output.getvalue()

    def _load_cog_pipeline(self, mode: str, model_id: str, dtype: Any, device: str) -> Any:
        key = (mode, model_id, self._dtype_name(dtype), device)
        if key in self._cog_cache:
            return self._cog_cache[key]
        auth = self._auth_kwargs()
        if mode == "control":
            if CogVideoXFunControlPipeline is None:
                raise RuntimeError("CogVideoXFunControlPipeline غير متاح.")
            pipe = CogVideoXFunControlPipeline.from_pretrained(model_id, torch_dtype=dtype, **auth)
        elif mode == "i2v":
            if CogVideoXImageToVideoPipeline is None:
                raise RuntimeError("CogVideoXImageToVideoPipeline غير متاح.")
            pipe = CogVideoXImageToVideoPipeline.from_pretrained(model_id, torch_dtype=dtype, **auth)
        else:
            if CogVideoXPipeline is None:
                raise RuntimeError("CogVideoXPipeline غير متاح.")
            pipe = CogVideoXPipeline.from_pretrained(model_id, torch_dtype=dtype, **auth)
        pipe = self._move_or_offload(pipe, device)
        self._cog_cache[key] = pipe
        return pipe

    def generate_cogvideox(
        self,
        prompt: str,
        guidance_scale: float = 6.0,
        steps: int = 30,
        seed: int = 42,
        control_video_bytes: bytes | None = None,
        reference_image: Image.Image | None = None,
        width: int = 768,
        height: int = 480,
    ) -> bytes:
        self._require_diffusers()
        dtype = self._dtype()
        device = self._device()
        control_model = self.env.get("LOCAL_VIDEO_CONTROL_MODEL_ID", "alibaba-pai/CogVideoX-Fun-V1.1-5b-Pose")
        base_model = self.env.get("LOCAL_VIDEO_MODEL_ID", "THUDM/CogVideoX-2b")
        if control_video_bytes is not None:
            if load_video is None:
                raise RuntimeError("دالة تحميل الفيديو غير متاحة في إصدار Diffusers الحالي.")
            with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as handle:
                handle.write(control_video_bytes)
                control_path = handle.name
            try:
                control_video = load_video(control_path)
            finally:
                Path(control_path).unlink(missing_ok=True)
            pipe = self._load_cog_pipeline("control", control_model, dtype, device)
            generation_kwargs: dict[str, Any] = {
                "prompt": prompt,
                "control_video": control_video,
                "guidance_scale": float(guidance_scale),
                "num_inference_steps": int(steps),
            }
        elif reference_image is not None:
            pipe = self._load_cog_pipeline("i2v", base_model, dtype, device)
            generation_kwargs = {
                "prompt": prompt,
                "image": reference_image.convert("RGB"),
                "guidance_scale": float(guidance_scale),
                "num_inference_steps": int(steps),
                "height": int(height),
                "width": int(width),
            }
        else:
            pipe = self._load_cog_pipeline("t2v", base_model, dtype, device)
            generation_kwargs = {
                "prompt": prompt,
                "guidance_scale": float(guidance_scale),
                "num_inference_steps": int(steps),
                "height": int(height),
                "width": int(width),
            }
        generator_device = device if device != "mps" else "cpu"
        generation_kwargs["generator"] = torch.Generator(device=generator_device).manual_seed(int(seed))
        frames = pipe(**generation_kwargs).frames[0]
        if export_to_video is None:
            raise RuntimeError("تصدير الفيديو غير متاح في إصدار Diffusers الحالي.")
        out_path = self.cache_dir / f"cogvideox_{os.getpid()}_{seed}.mp4"
        export_to_video(frames, str(out_path), fps=8)
        data = out_path.read_bytes()
        out_path.unlink(missing_ok=True)
        return data
