from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import html
import io
import ipaddress
import json
import mimetypes
import os
import re
import secrets
import socket
import sqlite3
import subprocess
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

import pandas as pd
import requests
import streamlit as st
from dotenv import load_dotenv
from fpdf import FPDF
from PIL import Image

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import torch
except ImportError:
    torch = None

try:
    from transformers import AutoModelForCausalLM, AutoTokenizer
except ImportError:
    AutoModelForCausalLM = None
    AutoTokenizer = None

try:
    from groq import Groq
except ImportError:
    Groq = None

from knowledge_engine import KnowledgeEngine, stable_source_hash
from controlled_generation import ControlledGenerationService
from omni_multimodal import decode_data_url, omni_capture
from task_queue import enqueue_long_video, enqueue_pollinations_image, task_state
from hardware import configure_runtime, model_load_kwargs
from swarm_orchestrator import SwarmOrchestrator


APP_DIR = Path(__file__).resolve().parent
ENV_FILE = APP_DIR / ".env"
DB_DEFAULT = APP_DIR / "data" / "app.db"
DATA_DIR = APP_DIR / "data"
MEDIA_ROOT = DATA_DIR / "media"
KNOWLEDGE_ROOT = DATA_DIR / "knowledge"
CONTROLLED_MODELS_ROOT = DATA_DIR / "controlled_models"
ALLOWED_SCHEMES = {"https"}
MAX_TEXT_CONTEXT_CHARS = 35_000
MAX_HISTORY_MESSAGES = 40
MAX_UPLOAD_SIZE_MB = 200
REQUEST_TIMEOUT = (8, 45)
PASSWORD_ITERATIONS = 600_000

load_dotenv(dotenv_path=ENV_FILE, override=False)


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "Nova Enterprise AI")
    developer_name: str = "Ali Ahmed Gorbaj"
    groq_api_key: str = os.getenv("GROQ_API_KEY", "")
    groq_model: str = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
    groq_vision_model: str = os.getenv("GROQ_VISION_MODEL", "qwen/qwen3.8-27b")
    pollinations_api_key: str = os.getenv("POLLINATIONS_API_KEY", "")
    local_model_id: str = os.getenv("LOCAL_MODEL_ID", "microsoft/Phi-3-mini-4k-instruct")
    database_url: str = os.getenv("DATABASE_URL", f"sqlite:///{DB_DEFAULT.as_posix()}")
    rate_limit_max: int = int(os.getenv("RATE_LIMIT_MAX", "20"))
    rate_limit_window_seconds: int = int(os.getenv("RATE_LIMIT_WINDOW_SECONDS", "300"))
    max_history_messages: int = int(os.getenv("MAX_HISTORY_MESSAGES", str(MAX_HISTORY_MESSAGES)))
    max_file_context_chars: int = int(os.getenv("MAX_FILE_CONTEXT_CHARS", str(MAX_TEXT_CONTEXT_CHARS)))
    http_timeout_seconds: int = int(os.getenv("HTTP_TIMEOUT_SECONDS", "45"))
    max_url_chars: int = int(os.getenv("MAX_URL_CONTENT_CHARS", "30000"))
    max_url_download_bytes: int = int(os.getenv("MAX_URL_DOWNLOAD_BYTES", "5242880"))
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "sentence-transformers/paraphrase-multilingual-mpnet-base-v2")
    knowledge_top_k: int = int(os.getenv("KNOWLEDGE_TOP_K", "5"))
    memory_index_interactions: bool = os.getenv("MEMORY_INDEX_INTERACTIONS", "1").strip().lower() in {"1", "true", "yes", "on"}
    local_image_model_id: str = os.getenv("LOCAL_IMAGE_MODEL_ID", "black-forest-labs/FLUX.1-dev")
    local_controlnet_model_id: str = os.getenv("LOCAL_CONTROLNET_MODEL_ID", "InstantX/FLUX.1-dev-Controlnet-Canny")
    local_ip_adapter_repo: str = os.getenv("LOCAL_IP_ADAPTER_REPO", "XLabs-AI/flux-ip-adapter")
    local_video_model_id: str = os.getenv("LOCAL_VIDEO_MODEL_ID", "THUDM/CogVideoX-2b")
    local_video_control_model_id: str = os.getenv("LOCAL_VIDEO_CONTROL_MODEL_ID", "alibaba-pai/CogVideoX-Fun-V1.1-5b-Pose")
    omni_interval_ms: int = int(os.getenv("OMNI_INTERVAL_MS", "1500"))
    omni_auto_response_seconds: int = int(os.getenv("OMNI_AUTO_RESPONSE_SECONDS", "8"))
    omni_ws_url: str = os.getenv("OMNI_WS_URL", "ws://localhost:8000/ws/omni")
    omni_gateway_secret: str = os.getenv("OMNI_GATEWAY_SECRET", "change-me-in-production")
    celery_broker_url: str = os.getenv("CELERY_BROKER_URL", os.getenv("REDIS_URL", ""))
    background_workers: int = int(os.getenv("LOCAL_BACKGROUND_WORKERS", "1"))
    swarm_enabled: bool = os.getenv("SWARM_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}
    swarm_trigger_length: int = int(os.getenv("SWARM_TRIGGER_LENGTH", "900"))
    long_video_max_seconds: int = int(os.getenv("LONG_VIDEO_MAX_SECONDS", "300"))
    long_video_chunk_seconds: int = int(os.getenv("LONG_VIDEO_CHUNK_SECONDS", "6"))


CFG = Settings()
HARDWARE = configure_runtime()

LANGUAGE_OPTIONS: dict[str, str] = {
    "auto": "مجاراة لغة المستخدم تلقائيًا",
    "ar": "العربية — الفصحى",
    "ar-libya": "العربية — الليبية",
    "ar-gulf": "العربية — الخليجية",
    "ar-levant": "العربية — الشامية",
    "ar-egypt": "العربية — المصرية",
    "ar-maghrib": "العربية — المغربية",
    "ar-algeria": "العربية — الجزائرية",
    "ar-tunisia": "العربية — التونسية",
    "en": "English",
    "fr": "Français",
    "es": "Español",
    "pt": "Português",
    "de": "Deutsch",
    "it": "Italiano",
    "tr": "Türkçe",
    "nl": "Nederlands",
    "sv": "Svenska",
    "no": "Norsk",
    "da": "Dansk",
    "fi": "Suomi",
    "pl": "Polski",
    "cs": "Čeština",
    "sk": "Slovenčina",
    "uk": "Українська",
    "ru": "Русский",
    "bg": "Български",
    "ro": "Română",
    "hu": "Magyar",
    "el": "Ελληνικά",
    "he": "עברית",
    "fa": "فارسی",
    "ur": "اردو",
    "hi": "हिन्दी",
    "bn": "বাংলা",
    "ta": "தமிழ்",
    "te": "తెలుగు",
    "mr": "मराठी",
    "gu": "ગુજરાતી",
    "pa": "ਪੰਜਾਬੀ",
    "id": "Bahasa Indonesia",
    "ms": "Bahasa Melayu",
    "vi": "Tiếng Việt",
    "th": "ไทย",
    "ko": "한국어",
    "ja": "日本語",
    "zh": "中文",
    "sw": "Kiswahili",
    "am": "አማርኛ",
}

ARABIC_DIALECTS = {
    "auto": "مجاراة اللهجة في رسالة المستخدم",
    "ar": "العربية الفصحى",
    "ar-libya": "اللهجة الليبية",
    "ar-gulf": "اللهجة الخليجية",
    "ar-levant": "اللهجة الشامية",
    "ar-egypt": "اللهجة المصرية",
    "ar-maghrib": "اللهجة المغربية",
    "ar-algeria": "اللهجة الجزائرية",
    "ar-tunisia": "اللهجة التونسية",
}

VOICE_PROFILES = {
    "balanced": ("nova", "صوت متوازن"),
    "warm": ("shimmer", "صوت دافئ"),
    "deep": ("onyx", "صوت عميق"),
    "clear": ("alloy", "صوت واضح"),
    "neutral": ("echo", "صوت محايد"),
    "story": ("fable", "صوت قصصي"),
}

VOICE_GENDER_HINTS = {
    "female": {"nova", "shimmer"},
    "male": {"onyx", "echo", "fable"},
    "neutral": {"alloy"},
}


def language_code_for_stt(language_key: str) -> str | None:
    if language_key == "auto":
        return None
    return language_key.split("-", 1)[0]


def language_instruction(language_key: str, dialect_key: str) -> str:
    target = LANGUAGE_OPTIONS.get(language_key, LANGUAGE_OPTIONS["auto"])
    dialect = ARABIC_DIALECTS.get(dialect_key, ARABIC_DIALECTS["auto"])
    if language_key == "auto":
        lang_rule = "استنتج لغة المستخدم من الرسالة ورد باللغة نفسها ما لم يطلب غير ذلك."
    elif language_key.startswith("ar"):
        lang_rule = f"أجب بالعربية مع الالتزام بالنمط المطلوب: {target}."
    else:
        lang_rule = f"أجب باللغة المطلوبة: {target}."
    dialect_rule = f"عند استخدام العربية، راعِ تفضيل اللهجة: {dialect}. وإذا اختار المستخدم لهجة محددة فطبّق مفرداتها وتركيبها بصورة طبيعية دون مبالغة."
    return f"{lang_rule}\n{dialect_rule}"


def get_db_path() -> Path:
    value = CFG.database_url.strip()
    if value.startswith("sqlite:///"):
        raw = value[len("sqlite:///"):]
        path = Path(raw)
        if not path.is_absolute():
            path = APP_DIR / path
    elif value.startswith("sqlite://"):
        raw = value[len("sqlite://"):]
        path = Path(raw)
        if not path.is_absolute():
            path = APP_DIR / path
    else:
        raise RuntimeError("DATABASE_URL must use a SQLite URL such as sqlite:///data/app.db")
    path.parent.mkdir(parents=True, exist_ok=True)
    return path.resolve()


DB_PATH = get_db_path()
KNOWLEDGE_ROOT.mkdir(parents=True, exist_ok=True)
CONTROLLED_MODELS_ROOT.mkdir(parents=True, exist_ok=True)


@st.cache_resource(show_spinner=False)
def get_knowledge_engine(user_id: int) -> KnowledgeEngine:
    return KnowledgeEngine(KNOWLEDGE_ROOT, int(user_id), CFG.embedding_model)


@st.cache_resource(show_spinner=False)
def get_controlled_generation_service() -> ControlledGenerationService:
    return ControlledGenerationService(CONTROLLED_MODELS_ROOT)


def db_connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    MEDIA_ROOT.mkdir(parents=True, exist_ok=True)
    with db_connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                last_login_at TEXT
            );

            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_conversations_user_updated
            ON conversations(user_id, updated_at DESC);

            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL,
                user_id INTEGER NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
                content TEXT NOT NULL,
                provider TEXT,
                media_id TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_messages_conversation_created
            ON messages(conversation_id, created_at ASC, id ASC);

            CREATE TABLE IF NOT EXISTS user_settings (
                user_id INTEGER PRIMARY KEY,
                appearance TEXT NOT NULL DEFAULT 'auto',
                language_key TEXT NOT NULL DEFAULT 'auto',
                arabic_dialect TEXT NOT NULL DEFAULT 'auto',
                image_preset TEXT NOT NULL DEFAULT 'square',
                image_quality TEXT NOT NULL DEFAULT 'high',
                guidance_scale REAL NOT NULL DEFAULT 7.5,
                video_aspect TEXT NOT NULL DEFAULT '16:9',
                video_resolution TEXT NOT NULL DEFAULT '1080p',
                video_duration INTEGER NOT NULL DEFAULT 5,
                voice_gender TEXT NOT NULL DEFAULT 'neutral',
                voice_profile TEXT NOT NULL DEFAULT 'balanced',
                tts_speed REAL NOT NULL DEFAULT 1.0,
                video_voiceover INTEGER NOT NULL DEFAULT 1,
                controlnet_scale REAL NOT NULL DEFAULT 0.9,
                ip_adapter_scale REAL NOT NULL DEFAULT 0.75,
                knowledge_top_k INTEGER NOT NULL DEFAULT 5,
                omni_interval_seconds INTEGER NOT NULL DEFAULT 2,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS media_assets (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                kind TEXT NOT NULL CHECK(kind IN ('image', 'video', 'audio')),
                filename TEXT NOT NULL,
                mime_type TEXT NOT NULL,
                storage_path TEXT NOT NULL,
                byte_size INTEGER NOT NULL,
                prompt TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_media_assets_user_created
            ON media_assets(user_id, created_at DESC);
            """
        )
        columns = {row[1] for row in conn.execute("PRAGMA table_info(messages)").fetchall()}
        if "media_id" not in columns:
            conn.execute("ALTER TABLE messages ADD COLUMN media_id TEXT")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_media_id ON messages(media_id)")
        setting_columns = {row[1] for row in conn.execute("PRAGMA table_info(user_settings)").fetchall()}
        migrations = {
            "controlnet_scale": "ALTER TABLE user_settings ADD COLUMN controlnet_scale REAL NOT NULL DEFAULT 0.9",
            "ip_adapter_scale": "ALTER TABLE user_settings ADD COLUMN ip_adapter_scale REAL NOT NULL DEFAULT 0.75",
            "knowledge_top_k": "ALTER TABLE user_settings ADD COLUMN knowledge_top_k INTEGER NOT NULL DEFAULT 5",
            "omni_interval_seconds": "ALTER TABLE user_settings ADD COLUMN omni_interval_seconds INTEGER NOT NULL DEFAULT 2",
        }
        for column, statement in migrations.items():
            if column not in setting_columns:
                conn.execute(statement)


def normalize_username(username: str) -> str:
    username = username.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username):
        raise ValueError("اسم المستخدم يجب أن يكون من 3 إلى 32 محرفًا ويحتوي على الحروف الإنجليزية والأرقام و . _ - فقط.")
    return username.lower()


def validate_password(password: str) -> None:
    if not 10 <= len(password) <= 128:
        raise ValueError("كلمة المرور يجب أن تتراوح بين 10 و128 محرفًا.")


def hash_password(password: str, salt: bytes | None = None) -> tuple[str, str]:
    validate_password(password)
    salt = salt or secrets.token_bytes(32)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS)
    return base64.b64encode(digest).decode("ascii"), base64.b64encode(salt).decode("ascii")


def verify_password(password: str, stored_hash: str, stored_salt: str) -> bool:
    try:
        salt = base64.b64decode(stored_salt.encode("ascii"), validate=True)
        expected = base64.b64decode(stored_hash.encode("ascii"), validate=True)
    except (binascii.Error, ValueError):
        return False
    actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS)
    return secrets.compare_digest(actual, expected)


def create_user(username: str, password: str) -> tuple[bool, str]:
    try:
        normalized = normalize_username(username)
        password_hash, salt = hash_password(password)
        with db_connect() as conn:
            conn.execute(
                "INSERT INTO users(username, password_hash, salt) VALUES (?, ?, ?)",
                (normalized, password_hash, salt),
            )
        return True, "تم إنشاء الحساب بنجاح."
    except sqlite3.IntegrityError:
        return False, "اسم المستخدم مستخدم بالفعل."
    except ValueError as exc:
        return False, str(exc)
    except Exception:
        return False, "تعذر إنشاء الحساب بسبب خطأ داخلي."


def authenticate_user(username: str, password: str) -> tuple[bool, dict[str, Any] | None, str]:
    try:
        normalized = normalize_username(username)
    except ValueError as exc:
        return False, None, str(exc)
    try:
        with db_connect() as conn:
            row = conn.execute(
                "SELECT id, username, password_hash, salt FROM users WHERE username = ?",
                (normalized,),
            ).fetchone()
            if row is None or not verify_password(password, row["password_hash"], row["salt"]):
                return False, None, "اسم المستخدم أو كلمة المرور غير صحيحة."
            conn.execute(
                "UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?",
                (row["id"],),
            )
        return True, {"id": int(row["id"]), "username": str(row["username"])}, "تم تسجيل الدخول."
    except Exception:
        return False, None, "تعذر تسجيل الدخول بسبب خطأ داخلي."


def create_conversation(user_id: int, title: str = "محادثة جديدة") -> str:
    conversation_id = str(uuid.uuid4())
    clean_title = re.sub(r"\s+", " ", title.strip())[:80] or "محادثة جديدة"
    with db_connect() as conn:
        conn.execute(
            "INSERT INTO conversations(id, user_id, title) VALUES (?, ?, ?)",
            (conversation_id, user_id, clean_title),
        )
    return conversation_id


def list_conversations(user_id: int) -> list[sqlite3.Row]:
    with db_connect() as conn:
        return conn.execute(
            "SELECT id, title, created_at, updated_at FROM conversations WHERE user_id = ? ORDER BY updated_at DESC",
            (user_id,),
        ).fetchall()


def get_messages(user_id: int, conversation_id: str) -> list[sqlite3.Row]:
    with db_connect() as conn:
        owner = conn.execute(
            "SELECT id FROM conversations WHERE id = ? AND user_id = ?",
            (conversation_id, user_id),
        ).fetchone()
        if owner is None:
            return []
        return conn.execute(
            "SELECT id, role, content, provider, media_id, created_at FROM messages WHERE conversation_id = ? AND user_id = ? ORDER BY created_at ASC, id ASC",
            (conversation_id, user_id),
        ).fetchall()


def save_message(user_id: int, conversation_id: str, role: str, content: str, provider: str = "", media_id: str | None = None) -> None:
    with db_connect() as conn:
        valid = conn.execute(
            "SELECT id FROM conversations WHERE id = ? AND user_id = ?",
            (conversation_id, user_id),
        ).fetchone()
        if valid is None:
            raise ValueError("المحادثة غير صالحة لهذا المستخدم.")
        conn.execute(
            "INSERT INTO messages(conversation_id, user_id, role, content, provider, media_id) VALUES (?, ?, ?, ?, ?, ?)",
            (conversation_id, user_id, role, content, provider, media_id),
        )
        conn.execute(
            "UPDATE conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?",
            (conversation_id, user_id),
        )


def get_user_settings(user_id: int) -> dict[str, Any]:
    defaults = {
        "appearance": "auto",
        "language_key": "auto",
        "arabic_dialect": "auto",
        "image_preset": "square",
        "image_quality": "high",
        "guidance_scale": 7.5,
        "video_aspect": "16:9",
        "video_resolution": "1080p",
        "video_duration": 5,
        "voice_gender": "neutral",
        "voice_profile": "balanced",
        "tts_speed": 1.0,
        "video_voiceover": 1,
        "controlnet_scale": 0.9,
        "ip_adapter_scale": 0.75,
        "knowledge_top_k": 5,
        "omni_interval_seconds": 2,
    }
    with db_connect() as conn:
        row = conn.execute("SELECT * FROM user_settings WHERE user_id = ?", (user_id,)).fetchone()
        if row is None:
            conn.execute("INSERT INTO user_settings(user_id) VALUES (?)", (user_id,))
            return defaults
        result = dict(row)
    defaults.update(result)
    return defaults


def save_user_settings(user_id: int, settings: dict[str, Any]) -> None:
    allowed = {
        "appearance", "language_key", "arabic_dialect", "image_preset", "image_quality",
        "guidance_scale", "video_aspect", "video_resolution", "video_duration",
        "voice_gender", "voice_profile", "tts_speed", "video_voiceover",
        "controlnet_scale", "ip_adapter_scale", "knowledge_top_k", "omni_interval_seconds",
    }
    clean = {k: settings[k] for k in allowed if k in settings}
    with db_connect() as conn:
        row = conn.execute("SELECT user_id FROM user_settings WHERE user_id = ?", (user_id,)).fetchone()
        if row is None:
            conn.execute("INSERT INTO user_settings(user_id) VALUES (?)", (user_id,))
        assignments = ", ".join([f"{key} = ?" for key in clean])
        if assignments:
            conn.execute(
                f"UPDATE user_settings SET {assignments}, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?",
                [*clean.values(), user_id],
            )


def clear_chat_history(user_id: int) -> None:
    with db_connect() as conn:
        conn.execute("DELETE FROM conversations WHERE user_id = ?", (user_id,))
    user_dir = MEDIA_ROOT / str(user_id)
    if user_dir.exists():
        for child in user_dir.iterdir():
            if child.is_file():
                try:
                    child.unlink()
                except OSError:
                    pass
    with db_connect() as conn:
        conn.execute("DELETE FROM media_assets WHERE user_id = ?", (user_id,))


def change_password(user_id: int, current_password: str, new_password: str) -> tuple[bool, str]:
    validate_password(current_password)
    validate_password(new_password)
    if current_password == new_password:
        return False, "كلمة المرور الجديدة يجب أن تختلف عن الحالية."
    with db_connect() as conn:
        row = conn.execute("SELECT password_hash, salt FROM users WHERE id = ?", (user_id,)).fetchone()
        if row is None or not verify_password(current_password, row["password_hash"], row["salt"]):
            return False, "كلمة المرور الحالية غير صحيحة."
        password_hash, salt = hash_password(new_password)
        conn.execute(
            "UPDATE users SET password_hash = ?, salt = ? WHERE id = ?",
            (password_hash, salt, user_id),
        )
    return True, "تم تغيير كلمة المرور بنجاح."


def user_media_dir(user_id: int) -> Path:
    path = (MEDIA_ROOT / str(int(user_id))).resolve()
    root = MEDIA_ROOT.resolve()
    if root not in path.parents and path != root:
        raise RuntimeError("مسار التخزين غير صالح.")
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_media_filename(filename: str, fallback_extension: str) -> str:
    base = Path(filename).stem
    base = re.sub(r"[^A-Za-z0-9_.-]+", "_", base).strip("._")[:80] or "generated"
    ext = Path(filename).suffix.lower() or fallback_extension
    if ext not in {".png", ".jpg", ".jpeg", ".webp", ".mp4", ".webm", ".mp3", ".wav"}:
        ext = fallback_extension
    return f"{base}_{uuid.uuid4().hex[:12]}{ext}"


def save_media_asset(user_id: int, kind: str, data: bytes, mime_type: str, filename: str, prompt: str = "") -> str:
    fallback_extension = {"image": ".png", "video": ".mp4", "audio": ".mp3"}.get(kind, ".bin")
    if kind not in {"image", "video", "audio"}:
        raise ValueError("نوع الوسائط غير صالح.")
    clean_filename = safe_media_filename(filename, fallback_extension)
    path = user_media_dir(user_id) / clean_filename
    path.write_bytes(data)
    media_id = str(uuid.uuid4())
    with db_connect() as conn:
        conn.execute(
            "INSERT INTO media_assets(id, user_id, kind, filename, mime_type, storage_path, byte_size, prompt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (media_id, user_id, kind, clean_filename, mime_type, str(path), len(data), prompt[:1000]),
        )
    return media_id


def get_media_asset(user_id: int, media_id: str) -> dict[str, Any] | None:
    with db_connect() as conn:
        row = conn.execute(
            "SELECT id, kind, filename, mime_type, storage_path, byte_size, prompt, created_at FROM media_assets WHERE id = ? AND user_id = ?",
            (media_id, user_id),
        ).fetchone()
    if row is None:
        return None
    path = Path(str(row["storage_path"])).resolve()
    root = user_media_dir(user_id).resolve()
    if root not in path.parents:
        return None
    if not path.exists() or not path.is_file():
        return None
    return {**dict(row), "path": path}


def list_media_assets(user_id: int) -> list[dict[str, Any]]:
    with db_connect() as conn:
        rows = conn.execute(
            "SELECT id, kind, filename, mime_type, storage_path, byte_size, prompt, created_at FROM media_assets WHERE user_id = ? ORDER BY created_at DESC",
            (user_id,),
        ).fetchall()
    result: list[dict[str, Any]] = []
    root = user_media_dir(user_id).resolve()
    for row in rows:
        path = Path(str(row["storage_path"])).resolve()
        if root in path.parents and path.exists() and path.is_file():
            result.append({**dict(row), "path": path})
    return result


def total_media_storage(user_id: int) -> int:
    return sum(int(item["byte_size"]) for item in list_media_assets(user_id))


def human_size(byte_count: int) -> str:
    size = float(byte_count)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{byte_count} B"


def update_conversation_title(user_id: int, conversation_id: str, title: str) -> None:
    clean_title = re.sub(r"\s+", " ", title.strip())[:80]
    if not clean_title:
        return
    with db_connect() as conn:
        conn.execute(
            "UPDATE conversations SET title = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?",
            (clean_title, conversation_id, user_id),
        )


def delete_conversation(user_id: int, conversation_id: str) -> None:
    with db_connect() as conn:
        conn.execute(
            "DELETE FROM conversations WHERE id = ? AND user_id = ?",
            (conversation_id, user_id),
        )


def build_omni_gateway_token(user_id: int, ttl_seconds: int = 300) -> str:
    expires = int(time.time()) + max(30, int(ttl_seconds))
    body = f"{int(user_id)}:{expires}".encode("utf-8")
    signature = hmac.new(CFG.omni_gateway_secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    payload = {"uid": int(user_id), "exp": expires, "sig": signature}
    encoded = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode("utf-8")).decode("ascii")
    return encoded.rstrip("=")


def build_omni_ws_url(user_id: int) -> str:
    base = CFG.omni_ws_url.rstrip("/")
    token = build_omni_gateway_token(user_id)
    return f"{base}/{int(user_id)}?token={token}"


def init_session() -> None:
    defaults = {
        "authenticated": False,
        "user": None,
        "conversation_id": None,
        "rate_timestamps": [],
        "last_provider": None,
        "pending_audio_hash": None,
        "pending_audio_text": "",
        "active_file_context": "",
        "active_url_context": "",
        "active_image_data_uris": [],
        "last_file_hash": None,
        "auth_attempt_timestamps": [],
        "settings": None,
        "recent_media_id": None,
        "pending_input_text": "",
        "latest_omni_event": None,
        "last_omni_fusion_at": 0.0,
        "last_omni_event_timestamp": 0,
        "omni_auto_enabled": False,
        "character_reference_media_id": None,
        "knowledge_ready": False,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def enforce_rate_limit() -> None:
    now = time.monotonic()
    timestamps = [
        t for t in st.session_state.get("rate_timestamps", [])
        if now - float(t) < CFG.rate_limit_window_seconds
    ]
    if len(timestamps) >= CFG.rate_limit_max:
        oldest = min(timestamps) if timestamps else now
        wait_seconds = max(1, int(CFG.rate_limit_window_seconds - (now - oldest)))
        raise RuntimeError(f"تم بلوغ حد الطلبات المؤقت. أعد المحاولة بعد نحو {wait_seconds} ثانية.")
    timestamps.append(now)
    st.session_state["rate_timestamps"] = timestamps


def is_fixed_identity_question(text: str) -> bool:
    lowered = text.strip().lower()
    patterns = [
        "من صانعك",
        "من طورك",
        "من صنعك",
        "who created you",
        "who made you",
        "who developed you",
    ]
    return any(p in lowered for p in patterns)


def is_capability_media_question(text: str) -> bool:
    lowered = text.strip().lower()
    markers = ["تصميم صور", "تصمم صور", "تصميم فيديو", "تصمم فيديو", "generate images", "generate videos", "create images", "create videos"]
    return any(p in lowered for p in markers)


def contains_science_math(text: str) -> bool:
    markers = [
        "رياضيات", "فيزياء", "كيمياء", "علوم", "معادلة", "احسب", "مسألة", "تفاضل", "تكامل", "مصفوفة", "متجه",
        "math", "physics", "science", "equation", "integral", "derivative", "matrix", "calculate",
    ]
    return any(marker in text.lower() for marker in markers) or bool(re.search(r"[=∫∑√πΔ]+|\\\\[([a-zA-Z]+)", text))


def build_system_prompt() -> str:
    user_state = st.session_state.get("user") or {}
    user_id = user_state.get("id")
    user_settings = st.session_state.get("settings") or ({"language_key": "auto", "arabic_dialect": "auto"} if user_id is None else get_user_settings(int(user_id)))
    lang_rules = language_instruction(str(user_settings.get("language_key", "auto")), str(user_settings.get("arabic_dialect", "auto")))
    science_rule = r"""
عند التعامل مع الرياضيات أو الفيزياء أو العلوم: اعرض الحل بخطوات واضحة، استخدم LaTeX داخل \(...\) و\[...\]، عرّف الرموز والوحدات، تحقق من الوحدات والنتيجة النهائية، ولا تخترع ثوابت أو بيانات غير موجودة.
"""
    return f"""
أنت مساعد مؤسسي متعدد اللغات عالي الاعتمادية اسمه {CFG.app_name}.
المطور الرئيسي المسجل في هوية التطبيق: {CFG.developer_name}.
{lang_rules}
افهم النصوص العربية بمختلف الصياغات واللهجات المحلية، بما فيها الليبية والخليجية والشامية والمصرية والمغربية والجزائرية والتونسية، وافهم الاختصارات والأخطاء الإملائية والسياق المحكي قدر الإمكان.
اجعل الإجابات دقيقة ومنظمة ومباشرة، واستخدم Markdown عند الحاجة.
{science_rule}
عند تحليل ملفات أو روابط، ميّز بوضوح بين المعلومات المستخرجة والمعلومات التي استنتجتها.
لا تدّع أنك نفذت إجراءً خارج التطبيق أو أنك تحققت من الإنترنت إلا إذا كانت البيانات متاحة فعلاً في السياق المرسل لك.
إذا احتوت الرسالة على كود، حافظ على سلامة الصياغة البرمجية ولا تقطع الكتل.
""".strip()


def coerce_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def build_message_history(rows: list[sqlite3.Row], current_user_prompt: str, system_prompt: str, context: str = "") -> list[dict[str, Any]]:
    history: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]
    for row in rows[-CFG.max_history_messages:]:
        role = str(row["role"])
        if role in {"user", "assistant", "system"}:
            history.append({"role": role, "content": str(row["content"])})
    user_content = current_user_prompt
    if context.strip():
        user_content = f"{current_user_prompt}\n\n--- سياق مرفقات/روابط ---\n{context[:CFG.max_file_context_chars]}\n--- نهاية السياق ---"
    history.append({"role": "user", "content": user_content})
    return history


def get_knowledge_context(user_id: int, prompt: str) -> str:
    try:
        engine = get_knowledge_engine(int(user_id))
        top_k = int((st.session_state.get("settings") or {}).get("knowledge_top_k", CFG.knowledge_top_k))
        return engine.context_for(prompt, n_results=max(1, min(10, top_k)), max_chars=min(14000, CFG.max_file_context_chars))
    except Exception as exc:
        st.session_state["knowledge_last_error"] = str(exc)
        return ""


def index_knowledge(user_id: int, source_name: str, source_kind: str, text: str, source_hash: str | None = None) -> dict[str, Any]:
    engine = get_knowledge_engine(int(user_id))
    return engine.index_document(source_name, source_kind, text, source_hash=source_hash)


def get_groq_client() -> Any:
    if Groq is None:
        raise RuntimeError("مكتبة groq غير مثبتة.")
    if not CFG.groq_api_key:
        raise RuntimeError("GROQ_API_KEY غير مضبوط.")
    return Groq(api_key=CFG.groq_api_key)


def groq_chat(messages: list[dict[str, Any]], stream: bool = False, model: str | None = None) -> str:
    client = get_groq_client()
    response = client.chat.completions.create(
        model=model or CFG.groq_model,
        messages=messages,
        temperature=0.2,
        max_completion_tokens=4096,
        stream=stream,
    )
    if stream:
        chunks: list[str] = []
        for chunk in response:
            delta = getattr(getattr(chunk, "choices", [None])[0], "delta", None)
            content = getattr(delta, "content", None) if delta is not None else None
            if content:
                chunks.append(str(content))
        return "".join(chunks)
    content = getattr(getattr(response, "choices", [None])[0], "message", None)
    text = getattr(content, "content", None) if content is not None else None
    if not text:
        raise RuntimeError("لم تُرجع Groq محتوى نصيًا صالحًا.")
    return str(text)


@st.cache_resource(show_spinner=False)
def load_local_model() -> tuple[Any, Any, str]:
    if AutoTokenizer is None or AutoModelForCausalLM is None or torch is None:
        raise RuntimeError("الاعتماديات المحلية Transformers/PyTorch غير مكتملة.")
    tokenizer = AutoTokenizer.from_pretrained(CFG.local_model_id, trust_remote_code=True)
    load_kwargs = model_load_kwargs()
    load_kwargs["trust_remote_code"] = True
    load_kwargs = {key: value for key, value in load_kwargs.items() if value is not None}
    model = AutoModelForCausalLM.from_pretrained(CFG.local_model_id, **load_kwargs)
    if HARDWARE.device == "cuda":
        device = "cuda"
    elif HARDWARE.device == "mps":
        model.to("mps")
        device = "mps"
    else:
        model.to("cpu")
        device = "cpu"
    model.eval()
    return tokenizer, model, device


def local_chat(messages: list[dict[str, Any]]) -> str:
    tokenizer, model, device = load_local_model()
    local_messages: list[dict[str, str]] = []
    for message in messages[-12:]:
        role = str(message.get("role", "user"))
        content = message.get("content", "")
        if isinstance(content, list):
            flattened = []
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    flattened.append(str(part.get("text", "")))
            content = "\n".join(flattened)
        local_messages.append({"role": role, "content": str(content)[-3500:]})
    if hasattr(tokenizer, "apply_chat_template"):
        prompt = tokenizer.apply_chat_template(local_messages, tokenize=False, add_generation_prompt=True)
    else:
        prompt = "".join(f"<|{m['role']}|>\n{m['content']}\n" for m in local_messages) + "<|assistant|>\n"
    encoded = tokenizer(prompt, return_tensors="pt")
    encoded = {k: v.to(device) for k, v in encoded.items()}
    input_len = encoded["input_ids"].shape[1]
    with torch.inference_mode():
        output = model.generate(
            **encoded,
            max_new_tokens=1536,
            do_sample=False,
            repetition_penalty=1.05,
            pad_token_id=tokenizer.eos_token_id,
        )
    generated = output[0][input_len:]
    result = tokenizer.decode(generated, skip_special_tokens=True).strip()
    if not result:
        raise RuntimeError("النموذج المحلي لم يُرجع نصًا.")
    return result


def multimodal_groq_message(prompt: str, image_data_uris: list[str], context: str = "") -> list[dict[str, Any]]:
    content: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
    if context:
        content.append({"type": "text", "text": f"سياق إضافي:\n{context[:CFG.max_file_context_chars]}"})
    for uri in image_data_uris[:3]:
        content.append({"type": "image_url", "image_url": {"url": uri}})
    return [
        {"role": "system", "content": build_system_prompt()},
        {"role": "user", "content": content},
    ]


def generate_response(rows: list[sqlite3.Row], prompt: str, context: str = "", image_data_uris: list[str] | None = None) -> tuple[str, str]:
    if is_fixed_identity_question(prompt):
        return "صانعي هو Ali Ahmed Gorbaj", "identity-rule"
    if is_capability_media_question(prompt):
        return "نعم، بكل تأكيد! يمكنني تصميم صور وفيديوهات بأعلى جودة.", "identity-rule"
    enforce_rate_limit()
    system_prompt = build_system_prompt()
    image_data_uris = image_data_uris or []
    user_state = st.session_state.get("user") or {}
    user_id = int(user_state.get("id")) if user_state.get("id") is not None else None
    knowledge_context = get_knowledge_context(user_id, prompt) if user_id is not None else ""
    merged_context = "\n\n".join(part for part in [context, knowledge_context] if part.strip())
    try:
        if image_data_uris and CFG.groq_api_key:
            response = groq_chat(multimodal_groq_message(prompt, image_data_uris, merged_context), stream=False, model=CFG.groq_vision_model)
        elif CFG.swarm_enabled and len(prompt.strip()) >= CFG.swarm_trigger_length and CFG.groq_api_key:
            orchestrator = SwarmOrchestrator(lambda msgs: groq_chat(msgs, stream=False))
            swarm = orchestrator.run(prompt, merged_context)
            response = swarm.answer
        elif CFG.swarm_enabled and SwarmOrchestrator.should_swarm(prompt) and CFG.groq_api_key:
            orchestrator = SwarmOrchestrator(lambda msgs: groq_chat(msgs, stream=False))
            response = orchestrator.run(prompt, merged_context).answer
        else:
            messages = build_message_history(rows, prompt, system_prompt, merged_context)
            response = groq_chat(messages, stream=False)
        return response, "groq-swarm" if CFG.swarm_enabled and SwarmOrchestrator.should_swarm(prompt) and not image_data_uris else "groq"
    except Exception as groq_exc:
        try:
            if image_data_uris:
                fallback_context = f"{merged_context}\n\nتم إرفاق صور مع الرسالة، لكن مسار النموذج المحلي الحالي للنص لا يستطيع رؤية الصور مباشرة. استخدم فقط السياق النصي المتاح ولا تدّع رؤية الصورة."
                messages = build_message_history(rows, prompt, system_prompt, fallback_context)
            else:
                messages = build_message_history(rows, prompt, system_prompt, merged_context)
            return local_chat(messages), "local-phi3"
        except Exception as local_exc:
            return (
                "تعذر الحصول على رد من Groq وكذلك من النموذج المحلي. "
                f"Groq={type(groq_exc).__name__}; Local={type(local_exc).__name__}",
                "error-fallback",
            )


def is_safe_public_url(url: str) -> bool:
    parsed = urlparse(url.strip())
    if parsed.scheme.lower() not in ALLOWED_SCHEMES:
        return False
    if not parsed.hostname:
        return False
    hostname = parsed.hostname.rstrip(".").lower()
    blocked_names = {"localhost", "localhost.localdomain", "metadata.google.internal"}
    if hostname in blocked_names or hostname.endswith(".local") or hostname.endswith(".internal"):
        return False
    try:
        addresses = socket.getaddrinfo(hostname, parsed.port or 443, type=socket.SOCK_STREAM)
    except socket.gaierror:
        return False
    for result in addresses:
        ip = ipaddress.ip_address(result[4][0])
        if any((ip.is_private, ip.is_loopback, ip.is_link_local, ip.is_reserved, ip.is_multicast, ip.is_unspecified)):
            return False
    return True


def normalize_url(url: str) -> str:
    url = url.strip()
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        url = "https://" + url
    parsed = urlparse(url)
    if parsed.scheme.lower() != "https" or not parsed.netloc:
        raise ValueError("يُسمح بروابط HTTPS العامة فقط.")
    clean_query = [(k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=True) if k.lower() not in {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content"}]
    normalized = urlunparse(("https", parsed.netloc, parsed.path or "/", parsed.params, urlencode(clean_query), parsed.fragment))
    if not is_safe_public_url(normalized):
        raise ValueError("الرابط غير مسموح به لأسباب أمنية.")
    return normalized


def extract_links_from_html(source_url: str, body: str, limit: int = 25) -> list[dict[str, str]]:
    links: list[dict[str, str]] = []
    pattern = re.compile(r"<a[^>]+href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", re.I | re.S)
    for href, label in pattern.findall(body):
        if len(links) >= limit:
            break
        absolute = urljoin(source_url, href)
        try:
            safe_absolute = normalize_url(absolute)
        except ValueError:
            continue
        text_label = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", label)).strip()[:160]
        links.append({"label": text_label or safe_absolute, "url": safe_absolute})
    return links


def fetch_url(url: str) -> dict[str, Any]:
    normalized = normalize_url(url)
    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; NovaEnterpriseAI/1.0; +https://streamlit.io/)",
        "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.8",
    }
    current_url = normalized
    response = None
    for _ in range(5):
        checked_url = normalize_url(current_url)
        response = requests.get(
            checked_url,
            headers=headers,
            timeout=(8, CFG.http_timeout_seconds),
            allow_redirects=False,
            stream=True,
        )
        if response.is_redirect or response.is_permanent_redirect:
            location = response.headers.get("Location")
            response.close()
            if not location:
                raise RuntimeError("أعاد الخادم تحويلًا بلا عنوان وجهة.")
            current_url = urljoin(checked_url, location)
            continue
        break
    if response is None:
        raise RuntimeError("تعذر تنفيذ طلب HTTP.")
    if response.is_redirect or response.is_permanent_redirect:
        response.close()
        raise RuntimeError("تجاوز الرابط الحد الأقصى للتحويلات المسموح بها.")
    response.raise_for_status()
    final_url = normalize_url(current_url)
    content_type = response.headers.get("Content-Type", "").lower()
    content_length = response.headers.get("Content-Length")
    if content_length and content_length.isdigit() and int(content_length) > CFG.max_url_download_bytes:
        response.close()
        raise RuntimeError("حجم محتوى الرابط أكبر من الحد الأمني المسموح.")
    chunks: list[bytes] = []
    total = 0
    try:
        for chunk in response.iter_content(chunk_size=65_536):
            if not chunk:
                continue
            total += len(chunk)
            if total > CFG.max_url_download_bytes:
                raise RuntimeError("حجم محتوى الرابط تجاوز الحد الأمني أثناء التنزيل.")
            chunks.append(chunk)
    finally:
        response.close()
    raw = b"".join(chunks)
    charset = response.encoding or "utf-8"
    text = raw.decode(charset, errors="replace")[: CFG.max_url_chars]
    links: list[dict[str, str]] = []
    if "html" in content_type:
        links = extract_links_from_html(final_url, text)
        visible = re.sub(r"<script\b[^>]*>.*?</script>", " ", text, flags=re.I | re.S)
        visible = re.sub(r"<style\b[^>]*>.*?</style>", " ", visible, flags=re.I | re.S)
        visible = re.sub(r"<[^>]+>", " ", visible)
        visible = html.unescape(re.sub(r"\s+", " ", visible)).strip()
    else:
        visible = text
    context = f"الرابط الأصلي: {normalized}\nالرابط النهائي بعد التحويل: {final_url}\nنوع المحتوى: {content_type}\n\n{visible[:CFG.max_url_chars]}"
    return {"url": normalized, "final_url": final_url, "content_type": content_type, "text": visible, "links": links, "context": context}

def file_to_data_uri(file_bytes: bytes, mime_type: str) -> str:
    encoded = base64.b64encode(file_bytes).decode("ascii")
    return f"data:{mime_type};base64,{encoded}"


def read_pdf(data: bytes) -> str:
    import fitz

    output: list[str] = []
    with fitz.open(stream=data, filetype="pdf") as document:
        for page_number, page in enumerate(document, start=1):
            output.append(f"[صفحة {page_number}]\n{page.get_text('text')}")
    return "\n\n".join(output)


def read_plain_text(data: bytes) -> str:
    for encoding in ("utf-8", "utf-8-sig", "cp1256", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def summarize_video_metadata(data: bytes, suffix: str) -> tuple[str, list[bytes]]:
    if cv2 is None:
        return "تحليل الفيديو التفصيلي يحتاج OpenCV، لكن الملف تم استلامه بنجاح.", []
    frames: list[bytes] = []
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as handle:
        handle.write(data)
        temp_path = handle.name
    try:
        cap = cv2.VideoCapture(temp_path)
        if not cap.isOpened():
            raise RuntimeError("تعذر فتح الفيديو.")
        fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        duration = frame_count / fps if fps > 0 else 0.0
        for ratio in (0.15, 0.5, 0.85):
            target = max(0, int(frame_count * ratio))
            cap.set(cv2.CAP_PROP_POS_FRAMES, target)
            ok, frame = cap.read()
            if not ok:
                continue
            success, encoded = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 88])
            if success:
                frames.append(bytes(encoded))
        cap.release()
        summary = f"دقة الفيديو: {width}x{height}\nمعدل الإطارات: {fps:.2f}\nعدد الإطارات: {frame_count}\nالمدة التقريبية: {duration:.2f} ثانية"
        return summary, frames
    finally:
        try:
            os.unlink(temp_path)
        except OSError:
            pass


def analyze_uploaded_file(uploaded_file: Any) -> dict[str, Any]:
    name = str(uploaded_file.name)
    mime_type = str(uploaded_file.type or mimetypes.guess_type(name)[0] or "application/octet-stream")
    data = uploaded_file.getvalue()
    extension = Path(name).suffix.lower()
    result: dict[str, Any] = {
        "name": name,
        "mime_type": mime_type,
        "size": len(data),
        "context": "",
        "image_data_uris": [],
        "preview": None,
    }
    if mime_type == "application/pdf" or extension == ".pdf":
        text = read_pdf(data)[: CFG.max_file_context_chars]
        result["context"] = f"اسم الملف: {name}\nنوع الملف: PDF\n\n{text}"
    elif mime_type.startswith("text/") or extension in {".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".c", ".cpp", ".h", ".hpp", ".html", ".css", ".json", ".yaml", ".yml", ".md", ".sql", ".sh", ".toml", ".xml", ".csv", ".txt"}:
        text = read_plain_text(data)[: CFG.max_file_context_chars]
        result["context"] = f"اسم الملف: {name}\nنوع الملف: {mime_type}\n\n{text}"
    elif mime_type.startswith("image/"):
        try:
            image = Image.open(io.BytesIO(data))
            result["preview"] = image.copy()
        except Exception as exc:
            raise ValueError(f"ملف الصورة غير صالح: {exc}") from exc
        result["image_data_uris"] = [file_to_data_uri(data, mime_type)]
        result["context"] = f"صورة مرفوعة: {name}\nنوع MIME: {mime_type}\nالحجم: {len(data)} بايت."
    elif mime_type.startswith("video/"):
        metadata, frames = summarize_video_metadata(data, extension or ".mp4")
        result["context"] = f"فيديو مرفوع: {name}\n{metadata}"
        result["image_data_uris"] = [file_to_data_uri(frame, "image/jpeg") for frame in frames[:3]]
    elif mime_type.startswith("audio/"):
        result["context"] = f"ملف صوتي مرفوع: {name}\nالحجم: {len(data)} بايت. استخدم ميزة النسخ الصوتي لتحويله إلى نص."
    else:
        raise ValueError("نوع الملف غير مدعوم للتحليل.")
    return result


def image_dimensions_from_preset(preset: str) -> tuple[int, int]:
    presets = {
        "square": (1024, 1024),
        "portrait": (832, 1216),
        "landscape": (1216, 832),
        "phone": (720, 1280),
        "cinema": (1280, 720),
    }
    return presets.get(preset, presets["square"])


def generate_image(
    prompt: str,
    width: int,
    height: int,
    model: str,
    enhance: bool,
    seed: int | None,
    quality: str = "high",
    guidance_scale: float = 7.5,
) -> tuple[bytes, str]:
    if not CFG.pollinations_api_key:
        raise RuntimeError("POLLINATIONS_API_KEY غير مضبوط.")
    quality = quality if quality in {"low", "medium", "high", "hd", "standard"} else "high"
    guidance_scale = max(1.0, min(20.0, float(guidance_scale)))
    enhancement = "ultra-detailed, high fidelity, cinematic lighting, crisp focus, clean composition, professional color grading, artifact-free, no text unless requested" if enhance else ""
    final_prompt = ", ".join(part for part in [prompt.strip(), enhancement] if part)
    params = {
        "model": model.strip() or "flux",
        "width": int(width),
        "height": int(height),
        "enhance": "true" if enhance else "false",
        "nologo": "true",
        "safe": "true",
        "quality": quality,
        "guidance_scale": f"{guidance_scale:g}",
    }
    if seed is not None:
        params["seed"] = str(seed)
    url = "https://gen.pollinations.ai/image/" + requests.utils.quote(final_prompt, safe="")
    response = requests.get(
        url,
        headers={"Authorization": f"Bearer {CFG.pollinations_api_key}"},
        params=params,
        timeout=(10, 180),
    )
    response.raise_for_status()
    content_type = response.headers.get("Content-Type", "image/png").split(";", 1)[0]
    if not content_type.startswith("image/"):
        raise RuntimeError("خدمة الصور أعادت نوع محتوى غير متوقع.")
    return response.content, content_type


def generate_video(prompt: str, duration: int, aspect_ratio: str, resolution: str = "1080p") -> tuple[bytes, str]:
    if not CFG.pollinations_api_key:
        raise RuntimeError("POLLINATIONS_API_KEY غير مضبوط.")
    if aspect_ratio not in {"16:9", "9:16", "1:1"}:
        raise ValueError("نسبة أبعاد الفيديو غير مدعومة.")
    if resolution not in {"480p", "720p", "1080p", "4k"}:
        resolution = "1080p"
    url = "https://gen.pollinations.ai/video/" + requests.utils.quote(prompt.strip(), safe="")
    response = requests.get(
        url,
        headers={"Authorization": f"Bearer {CFG.pollinations_api_key}"},
        params={"duration": int(duration), "aspectRatio": aspect_ratio, "resolution": resolution},
        timeout=(10, 600),
    )
    response.raise_for_status()
    content_type = response.headers.get("Content-Type", "video/mp4").split(";", 1)[0]
    if not content_type.startswith("video/"):
        raise RuntimeError("خدمة الفيديو أعادت نوع محتوى غير متوقع.")
    return response.content, content_type


def speech_to_text(audio_bytes: bytes, filename: str = "audio.wav", language_key: str = "auto", dialect_key: str = "auto", mime_type: str | None = None) -> str:
    if not CFG.pollinations_api_key:
        raise RuntimeError("POLLINATIONS_API_KEY غير مضبوط.")
    language = language_code_for_stt(language_key)
    prompt_hint = ""
    if dialect_key.startswith("ar-"):
        prompt_hint = f"Arabic dialect hint: {ARABIC_DIALECTS.get(dialect_key, 'Arabic')}. Preserve colloquial words and names."
    elif dialect_key == "ar":
        prompt_hint = "Modern Standard Arabic. Preserve names and punctuation."
    data: dict[str, str] = {"model": "whisper-large-v3", "response_format": "json", "temperature": "0"}
    if language:
        data["language"] = language
    if prompt_hint:
        data["prompt"] = prompt_hint
    response = requests.post(
        "https://gen.pollinations.ai/v1/audio/transcriptions",
        headers={"Authorization": f"Bearer {CFG.pollinations_api_key}"},
        files={"file": (filename, audio_bytes, mime_type or mimetypes.guess_type(filename)[0] or "audio/wav")},
        data=data,
        timeout=(10, 180),
    )
    response.raise_for_status()
    payload = response.json()
    text_value = payload.get("text") if isinstance(payload, dict) else None
    if not text_value:
        raise RuntimeError("لم يتم إرجاع نص من خدمة النسخ الصوتي.")
    return str(text_value).strip()


def text_to_speech(text: str, voice: str = "nova", speed: float = 1.0) -> tuple[bytes, str]:
    if not CFG.pollinations_api_key:
        raise RuntimeError("POLLINATIONS_API_KEY غير مضبوط.")
    voice = voice if voice in {"alloy", "echo", "fable", "onyx", "nova", "shimmer"} else "nova"
    speed = max(0.5, min(2.0, float(speed)))
    response = requests.post(
        "https://gen.pollinations.ai/v1/audio/speech",
        headers={
            "Authorization": f"Bearer {CFG.pollinations_api_key}",
            "Content-Type": "application/json",
        },
        json={"model": "tts-1", "input": text.strip(), "voice": voice, "response_format": "mp3", "speed": speed},
        timeout=(10, 180),
    )
    response.raise_for_status()
    return response.content, response.headers.get("Content-Type", "audio/mpeg").split(";", 1)[0]


def mux_audio(video_bytes: bytes, audio_bytes: bytes) -> bytes:
    try:
        import imageio_ffmpeg
    except ImportError as exc:
        raise RuntimeError("imageio-ffmpeg غير مثبت.") from exc
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    with tempfile.TemporaryDirectory() as temp_dir:
        video_path = Path(temp_dir) / "video.mp4"
        audio_path = Path(temp_dir) / "audio.mp3"
        output_path = Path(temp_dir) / "output.mp4"
        video_path.write_bytes(video_bytes)
        audio_path.write_bytes(audio_bytes)
        command = [
            ffmpeg,
            "-y",
            "-i", str(video_path),
            "-i", str(audio_path),
            "-map", "0:v:0",
            "-map", "1:a:0",
            "-c:v", "copy",
            "-c:a", "aac",
            "-shortest",
            str(output_path),
        ]
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        if proc.returncode != 0 or not output_path.exists():
            raise RuntimeError("تعذر دمج الصوت مع الفيديو.")
        return output_path.read_bytes()


def find_unicode_font() -> Path | None:
    candidates = [
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed.ttf"),
        Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"),
        APP_DIR / "DejaVuSans.ttf",
    ]
    return next((p for p in candidates if p.exists()), None)


def build_pdf(messages: Iterable[sqlite3.Row]) -> bytes:
    pdf = FPDF(format="A4")
    pdf.set_auto_page_break(auto=True, margin=16)
    pdf.add_page()
    font_path = find_unicode_font()
    if font_path:
        pdf.add_font("AppFont", fname=str(font_path))
        pdf.set_font("AppFont", size=11)
        try:
            pdf.set_text_shaping(True)
        except Exception:
            pass
    else:
        pdf.set_font("Helvetica", size=10)
    pdf.cell(text=f"{CFG.app_name} — Chat Export", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)
    for row in messages:
        role = str(row["role"])
        label = {"user": "المستخدم", "assistant": "المساعد", "system": "النظام"}.get(role, role)
        content = str(row["content"])
        pdf.set_font(size=11)
        pdf.multi_cell(0, 7, f"{label}:\n{content}")
        pdf.ln(2)
    return bytes(pdf.output())


def build_excel(messages: Iterable[sqlite3.Row]) -> bytes:
    rows = [{
        "id": int(row["id"]),
        "role": str(row["role"]),
        "content": str(row["content"]),
        "provider": str(row["provider"] or ""),
        "created_at": str(row["created_at"]),
    } for row in messages]
    df = pd.DataFrame(rows)
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Chat")
    return buffer.getvalue()


def build_txt(messages: Iterable[sqlite3.Row]) -> bytes:
    lines: list[str] = []
    for row in messages:
        label = {"user": "المستخدم", "assistant": "المساعد", "system": "النظام"}.get(str(row["role"]), str(row["role"]))
        lines.append(f"[{row['created_at']}] {label}\n{row['content']}\n")
    return "\n".join(lines).encode("utf-8")


def render_copy_button(text_value: str, button_label: str = "نسخ الرد") -> None:
    encoded = base64.b64encode(text_value.encode("utf-8")).decode("ascii")
    component = f"""
    <script>
    const value = atob('{encoded}');
    document.open();
    document.write(`
      <button id=\"copy-btn\" style=\"width:100%;padding:0.55rem 0.8rem;border:1px solid rgba(127,127,127,.35);border-radius:9px;background:transparent;color:inherit;cursor:pointer;font-size:14px\">{html.escape(button_label)}</button>
    `);
    document.close();
    const btn = document.getElementById('copy-btn');
    btn.addEventListener('click', async () => {{
      try {{
        await navigator.clipboard.writeText(value);
        btn.textContent = 'تم النسخ ✓';
      }} catch (error) {{
        btn.textContent = 'تعذر النسخ التلقائي';
      }}
    }});
    </script>
    """
    st.components.v1.html(component, height=50, scrolling=False)


def inject_styles() -> None:
    appearance = (st.session_state.get("settings") or {}).get("appearance", "auto")
    theme_class = "theme-dark" if appearance == "dark" else "theme-light" if appearance == "light" else "theme-auto"
    st.markdown(
        f"""
        <div id="app-theme-marker" class="{theme_class}"></div>
        <style>
        .stApp {{ max-width: 1480px; margin: 0 auto; }}
        .block-container {{ padding-top: 1.2rem; padding-bottom: 4rem; }}
        .hero {{
          padding: 1.1rem 1.25rem; border: 1px solid rgba(127,127,127,.20); border-radius: 18px;
          background: linear-gradient(135deg, rgba(127,127,127,.08), rgba(127,127,127,.02)); margin-bottom: 1rem;
        }}
        .hero h1 {{ margin-bottom: .2rem; }}
        .muted {{ opacity: .72; }}
        .pill {{ display:inline-block; padding:.25rem .6rem; border-radius:999px; border:1px solid rgba(127,127,127,.22); margin:.15rem .15rem .15rem 0; font-size:.82rem; }}
        .settings-card {{ padding: .9rem 1rem; border: 1px solid rgba(127,127,127,.2); border-radius: 16px; margin-bottom: .75rem; }}
        .metric-card {{ padding: .8rem; border-radius: 14px; background: rgba(127,127,127,.06); border: 1px solid rgba(127,127,127,.16); }}
        .media-card {{ padding: .8rem; border-radius: 16px; border: 1px solid rgba(127,127,127,.2); margin: .5rem 0 1rem 0; }}
        .theme-dark ~ * {{ color-scheme: dark; }}
        @media (prefers-color-scheme: dark) {{ .theme-auto ~ * {{ color-scheme: dark; }} }}
        .theme-light ~ * {{ color-scheme: light; }}
        body:has(#app-theme-marker.theme-light) [data-testid="stAppViewContainer"] {{ background: #f8fafc !important; }}
        body:has(#app-theme-marker.theme-light) [data-testid="stMain"] {{ color: #111827 !important; }}
        body:has(#app-theme-marker.theme-dark) [data-testid="stAppViewContainer"] {{ background: #0b1020 !important; }}
        @media (prefers-color-scheme: dark) {{ body:has(#app-theme-marker.theme-auto) [data-testid="stAppViewContainer"] {{ background: #0b1020 !important; }} }}
        @media (max-width: 900px) {{ .block-container {{ padding-left: .75rem; padding-right: .75rem; }} }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_login() -> None:
    st.markdown(f"<div class='hero'><h1>{html.escape(CFG.app_name)}</h1><div class='muted'>منصة ذكاء اصطناعي مؤسسية — {html.escape(CFG.developer_name)}</div></div>", unsafe_allow_html=True)
    login_tab, signup_tab = st.tabs(["تسجيل الدخول", "إنشاء حساب"])
    with login_tab:
        with st.form("login_form", clear_on_submit=False):
            username = st.text_input("اسم المستخدم")
            password = st.text_input("كلمة المرور", type="password")
            submitted = st.form_submit_button("دخول", use_container_width=True)
        if submitted:
            now = time.monotonic()
            attempts = [t for t in st.session_state.get("auth_attempt_timestamps", []) if now - float(t) < 300]
            if len(attempts) >= 8:
                st.error("تم إيقاف محاولات تسجيل الدخول مؤقتًا بعد عدد كبير من المحاولات الفاشلة.")
                return
            attempts.append(now)
            st.session_state["auth_attempt_timestamps"] = attempts
            ok, user, message = authenticate_user(username, password)
            if ok and user:
                st.session_state["authenticated"] = True
                st.session_state["user"] = user
                st.session_state["conversation_id"] = None
                st.rerun()
            st.error(message)
    with signup_tab:
        with st.form("signup_form", clear_on_submit=True):
            username = st.text_input("اسم مستخدم جديد")
            password = st.text_input("كلمة مرور", type="password")
            password2 = st.text_input("تأكيد كلمة المرور", type="password")
            submitted = st.form_submit_button("إنشاء الحساب", use_container_width=True)
        if submitted:
            if password != password2:
                st.error("كلمتا المرور غير متطابقتين.")
            else:
                ok, message = create_user(username, password)
                if ok:
                    st.success(message + " يمكنك الآن تسجيل الدخول.")
                else:
                    st.error(message)


def ensure_conversation(user_id: int) -> str:
    current = st.session_state.get("conversation_id")
    if current:
        rows = get_messages(user_id, current)
        conversations = {row["id"] for row in list_conversations(user_id)}
        if current in conversations:
            return current
    conversation_id = create_conversation(user_id)
    st.session_state["conversation_id"] = conversation_id
    return conversation_id


def render_media_asset(user_id: int, media_id: str) -> None:
    asset = get_media_asset(user_id, media_id)
    if asset is None:
        st.warning("تعذر العثور على ملف الوسائط المحفوظ.")
        return
    data = asset["path"].read_bytes()
    st.markdown("<div class='media-card'>", unsafe_allow_html=True)
    if asset["kind"] == "image":
        st.image(data, use_container_width=True)
    elif asset["kind"] == "video":
        st.video(data, format=asset["mime_type"], subtitles=None)
    elif asset["kind"] == "audio":
        st.audio(data, format=asset["mime_type"])
    st.download_button(
        f"⬇️ تنزيل {asset['filename']}",
        data=data,
        file_name=asset["filename"],
        mime=asset["mime_type"],
        use_container_width=True,
        key=f"download_{media_id}",
    )
    st.caption(f"{human_size(int(asset['byte_size']))} • {asset['created_at']}")
    st.markdown("</div>", unsafe_allow_html=True)


def render_settings_panel(user_id: int) -> None:
    current = st.session_state.get("settings") or get_user_settings(user_id)
    st.sidebar.markdown("### ⚙️ الإعدادات المتقدمة")
    with st.sidebar.expander("المظهر واللغة", expanded=False):
        appearance_options = {"auto": "تلقائي حسب الجهاز", "dark": "داكن", "light": "فاتح"}
        appearance = st.selectbox("مظهر الواجهة", list(appearance_options), index=list(appearance_options).index(str(current.get("appearance", "auto"))), format_func=appearance_options.get, key="settings_appearance")
        language = st.selectbox("لغة الإجابة", list(LANGUAGE_OPTIONS), index=list(LANGUAGE_OPTIONS).index(str(current.get("language_key", "auto"))), format_func=LANGUAGE_OPTIONS.get, key="settings_language")
        dialect = st.selectbox("اللهجة العربية", list(ARABIC_DIALECTS), index=list(ARABIC_DIALECTS).index(str(current.get("arabic_dialect", "auto"))), format_func=ARABIC_DIALECTS.get, key="settings_dialect")
    with st.sidebar.expander("التوليد المرئي", expanded=False):
        image_presets = {"square": "مربع 1:1", "portrait": "عمودي للهاتف", "landscape": "عرضي للشاشات", "phone": "عمودي 9:16", "cinema": "سينمائي 16:9"}
        image_preset = st.selectbox("أبعاد الصور", list(image_presets), index=list(image_presets).index(str(current.get("image_preset", "square"))), format_func=image_presets.get, key="settings_image_preset")
        image_quality = st.selectbox("جودة الصور", ["low", "medium", "high", "hd"], index=["low", "medium", "high", "hd"].index(str(current.get("image_quality", "high"))), key="settings_image_quality")
        guidance = st.slider("قوة الالتزام بالنص", 1.0, 20.0, float(current.get("guidance_scale", 7.5)), 0.5, key="settings_guidance")
        video_aspect = st.selectbox("أبعاد الفيديو", ["16:9", "9:16", "1:1"], index=["16:9", "9:16", "1:1"].index(str(current.get("video_aspect", "16:9"))), key="settings_video_aspect")
        video_resolution = st.selectbox("دقة الفيديو", ["480p", "720p", "1080p", "4k"], index=["480p", "720p", "1080p", "4k"].index(str(current.get("video_resolution", "1080p"))), key="settings_video_resolution")
        video_duration = st.slider("مدة الفيديو الافتراضية", 3, 12, int(current.get("video_duration", 5)), 1, key="settings_video_duration")
        voiceover = st.toggle("إضافة صوت مولد للفيديو", bool(current.get("video_voiceover", 1)), key="settings_video_voiceover")
    with st.sidebar.expander("الصوت", expanded=False):
        gender = st.radio("نوع الصوت", ["neutral", "female", "male"], index=["neutral", "female", "male"].index(str(current.get("voice_gender", "neutral"))), format_func={"neutral": "محايد", "female": "نسائي", "male": "رجالي"}.get, horizontal=True, key="settings_voice_gender")
        profile = st.selectbox("طبقة/طابع الصوت", list(VOICE_PROFILES), index=list(VOICE_PROFILES).index(str(current.get("voice_profile", "balanced"))), format_func=lambda k: VOICE_PROFILES[k][1], key="settings_voice_profile")
        speed = st.slider("سرعة النطق", 0.5, 2.0, float(current.get("tts_speed", 1.0)), 0.05, key="settings_tts_speed")
    with st.sidebar.expander("الإدراك والمعرفة المحلية", expanded=False):
        controlnet_scale = st.slider("قوة ControlNet", 0.1, 1.5, float(current.get("controlnet_scale", 0.9)), 0.05, key="settings_controlnet_scale")
        ip_adapter_scale = st.slider("قوة تثبيت الشخصية IP-Adapter", 0.0, 1.5, float(current.get("ip_adapter_scale", 0.75)), 0.05, key="settings_ip_adapter_scale")
        knowledge_top_k = st.slider("عدد مقاطع المعرفة المسترجعة", 1, 10, int(current.get("knowledge_top_k", CFG.knowledge_top_k)), 1, key="settings_knowledge_top_k")
        omni_interval = st.slider("فاصل لقطات Omni بالثواني", 1, 10, int(current.get("omni_interval_seconds", 2)), 1, key="settings_omni_interval")
    updated = {
        "appearance": appearance,
        "language_key": language,
        "arabic_dialect": dialect,
        "image_preset": image_preset,
        "image_quality": image_quality,
        "guidance_scale": guidance,
        "video_aspect": video_aspect,
        "video_resolution": video_resolution,
        "video_duration": video_duration,
        "voice_gender": gender,
        "voice_profile": profile,
        "tts_speed": speed,
        "video_voiceover": 1 if voiceover else 0,
        "controlnet_scale": controlnet_scale,
        "ip_adapter_scale": ip_adapter_scale,
        "knowledge_top_k": knowledge_top_k,
        "omni_interval_seconds": omni_interval,
    }
    if updated != {k: current.get(k) for k in updated}:
        save_user_settings(user_id, updated)
        st.session_state["settings"] = {**current, **updated}
        st.rerun()


def render_account_management(user_id: int) -> None:
    st.markdown("#### 👤 إدارة الحساب")
    with st.form("change_password_form", clear_on_submit=True):
        current_password = st.text_input("كلمة المرور الحالية", type="password")
        new_password = st.text_input("كلمة المرور الجديدة", type="password")
        confirm_password = st.text_input("تأكيد كلمة المرور الجديدة", type="password")
        submitted = st.form_submit_button("تغيير كلمة المرور", use_container_width=True)
    if submitted:
        if new_password != confirm_password:
            st.error("كلمتا المرور الجديدتان غير متطابقتين.")
        else:
            try:
                ok, message = change_password(user_id, current_password, new_password)
                (st.success if ok else st.error)(message)
            except ValueError as exc:
                st.error(str(exc))
    st.divider()
    st.markdown("#### 🧹 سجل المحادثات")
    st.caption("سيؤدي المسح إلى حذف جميع المحادثات والوسائط المحفوظة لهذا الحساب.")
    if st.button("حذف سجل المحادثات والوسائط", type="secondary", use_container_width=True):
        clear_chat_history(user_id)
        st.session_state["conversation_id"] = None
        st.session_state["recent_media_id"] = None
        st.success("تم حذف السجل والملفات بنجاح.")
        st.rerun()
    st.divider()
    st.markdown("#### 🧠 الذاكرة المعرفية المتجهية")
    st.caption("هذا مستقل عن سجل المحادثات: يمسح ChromaDB المحلي لهذا الحساب ولا يحذف ملفات التنزيل.")
    if st.button("مسح الذاكرة المعرفية", type="secondary", use_container_width=True):
        try:
            get_knowledge_engine(user_id).delete_all()
            st.session_state["knowledge_last_error"] = ""
            st.success("تم مسح الذاكرة المعرفية لهذا الحساب.")
            st.rerun()
        except Exception as exc:
            st.error(f"تعذر مسح الذاكرة المعرفية: {exc}")


def render_download_library(user_id: int) -> None:
    assets = list_media_assets(user_id)
    total = total_media_storage(user_id)
    st.markdown("#### 📁 ملفاتي التنزيلية")
    st.markdown(f"<div class='metric-card'><strong>المساحة المستخدمة:</strong> {human_size(total)} &nbsp; • &nbsp; <strong>عدد الملفات:</strong> {len(assets)}</div>", unsafe_allow_html=True)
    if not assets:
        st.info("لا توجد ملفات مولدة محفوظة بعد.")
        return
    for asset in assets[:30]:
        with st.container(border=True):
            st.write(f"**{asset['filename']}**")
            st.caption(f"{asset['kind']} • {human_size(int(asset['byte_size']))} • {asset['created_at']}")
            render_media_asset(user_id, str(asset["id"]))


def render_sidebar(user_id: int) -> None:
    with st.sidebar:
        st.markdown(f"### {html.escape(CFG.app_name)}")
        st.caption(f"المستخدم: {html.escape(st.session_state['user']['username'])}")
        render_settings_panel(user_id)
        if st.button("➕ محادثة جديدة", use_container_width=True):
            st.session_state["conversation_id"] = create_conversation(user_id)
            st.rerun()
        conversations = list_conversations(user_id)
        if conversations:
            labels = {row["id"]: row["title"] for row in conversations}
            current = st.session_state.get("conversation_id")
            options = list(labels.keys())
            selected_index = options.index(current) if current in options else 0
            selected = st.selectbox("المحادثات", options, index=selected_index, format_func=lambda key: labels[key])
            if selected != current:
                st.session_state["conversation_id"] = selected
                st.rerun()
            col1, col2 = st.columns(2)
            with col1:
                if st.button("🗑️ حذف", use_container_width=True):
                    delete_conversation(user_id, selected)
                    st.session_state["conversation_id"] = None
                    st.rerun()
            with col2:
                if st.button("🚪 خروج", use_container_width=True):
                    st.session_state["authenticated"] = False
                    st.session_state["user"] = None
                    st.session_state["conversation_id"] = None
                    st.rerun()
        else:
            if st.button("🚪 خروج", use_container_width=True):
                st.session_state["authenticated"] = False
                st.session_state["user"] = None
                st.rerun()
        st.divider()
        st.caption(f"حد الطلبات: {CFG.rate_limit_max} لكل {CFG.rate_limit_window_seconds} ثانية/جلسة")
        try:
            knowledge_stats = get_knowledge_engine(user_id).stats()
            st.caption(f"الذاكرة المتجهية: {knowledge_stats['chunks']} مقطع")
        except Exception as exc:
            st.caption(f"الذاكرة المتجهية: غير جاهزة ({type(exc).__name__})")
        st.caption(f"LLM: {CFG.groq_model}")
        st.caption(f"Vision: {CFG.groq_vision_model}")
        st.caption(f"Local Fallback: {CFG.local_model_id}")


def render_chat_tab(user_id: int) -> None:
    conversation_id = ensure_conversation(user_id)
    rows = get_messages(user_id, conversation_id)
    st.markdown("### المحادثة")
    if st.session_state.get("pending_input_text"):
        with st.container(border=True):
            st.markdown("**نص صوتي جاهز للإرسال:**")
            st.text_area("", value=st.session_state["pending_input_text"], key="pending_input_preview", height=100)
            if st.button("إرسال النص الصوتي", type="primary", use_container_width=True):
                prompt = st.session_state["pending_input_preview"].strip()
                st.session_state["pending_input_text"] = prompt
                st.session_state["force_chat_prompt"] = prompt
                st.rerun()
    if not rows:
        st.info("ابدأ برسالتك الأولى. الذاكرة محفوظة في SQLite حتى بعد تحديث الصفحة.")
    else:
        for row in rows:
            if row["role"] == "system":
                continue
            with st.chat_message(row["role"]):
                st.markdown(str(row["content"]))
                if row["role"] == "assistant":
                    render_copy_button(str(row["content"]))
                    if row["media_id"]:
                        render_media_asset(user_id, str(row["media_id"]))
                    provider = row["provider"] or ""
                    if provider and provider not in {"identity-rule"}:
                        st.caption(f"المصدر: {provider}")
    prompt = st.session_state.pop("force_chat_prompt", None) or st.chat_input("اكتب رسالتك...")
    if prompt:
        st.session_state["pending_input_text"] = ""
        user_context_parts = []
        if st.session_state.get("active_file_context"):
            user_context_parts.append(st.session_state["active_file_context"])
        if st.session_state.get("active_url_context"):
            user_context_parts.append(st.session_state["active_url_context"])
        context = "\n\n".join(user_context_parts)
        image_uris: list[str] = []
        raw_file_uris = st.session_state.get("active_image_data_uris", [])
        image_uris.extend(raw_file_uris[:3])
        save_message(user_id, conversation_id, "user", prompt, "user-input")
        with st.chat_message("assistant"):
            with st.spinner("جاري التفكير..."):
                try:
                    answer, provider = generate_response(rows, prompt, context, image_uris)
                except Exception as exc:
                    answer = f"حدث خطأ أثناء المعالجة: {exc}"
                    provider = "error"
            st.markdown(answer)
            render_copy_button(answer)
            st.caption(f"المصدر: {provider}")
            settings = st.session_state.get("settings") or {}
            if st.button("🔊 قراءة الرد", key=f"tts_chat_{uuid.uuid4().hex[:8]}"):
                try:
                    voice = select_voice_for_profile(str(settings.get("voice_profile", "balanced")), str(settings.get("voice_gender", "neutral")))
                    audio_data, mime = text_to_speech(answer, voice, float(settings.get("tts_speed", 1.0)))
                    st.audio(audio_data, format=mime)
                except Exception as exc:
                    st.warning(f"تعذر النطق: {exc}")
        save_message(user_id, conversation_id, "assistant", answer, provider)
        if CFG.memory_index_interactions:
            try:
                get_knowledge_engine(user_id).index_interaction(prompt, answer, conversation_id)
            except Exception as knowledge_exc:
                st.session_state["knowledge_last_error"] = str(knowledge_exc)
        if len(rows) == 0:
            update_conversation_title(user_id, conversation_id, prompt[:60])
        st.session_state["active_file_context"] = ""
        st.session_state["active_url_context"] = ""
        st.session_state["active_image_data_uris"] = []
        st.rerun()


def register_background_result(user_id: int, result: dict[str, Any], prompt: str) -> str:
    path = Path(str(result.get("path", ""))).resolve()
    allowed_root = (DATA_DIR / "jobs").resolve()
    allowed_media = MEDIA_ROOT.resolve()
    if not path.exists() or not path.is_file():
        raise FileNotFoundError("ملف ناتج المهمة الخلفية غير موجود.")
    if not (allowed_root in path.parents or allowed_media in path.parents):
        raise PermissionError("مسار نتيجة المهمة غير مسموح به.")
    data = path.read_bytes()
    mime = str(result.get("mime_type", "application/octet-stream")).split(";", 1)[0].lower()
    if mime.startswith("image/"):
        kind = "image"
        extension = ".png" if mime == "image/png" else ".jpg"
        filename = f"background_image_{int(time.time())}{extension}"
    elif mime.startswith("video/"):
        kind = "video"
        mime = "video/mp4"
        filename = f"ultra_long_{int(time.time())}.mp4"
    else:
        raise ValueError("نوع ملف المهمة الخلفية غير مسموح به.")
    return save_media_asset(user_id, kind, data, mime, filename, prompt)


def select_voice_for_profile(profile: str, gender: str) -> str:
    voice = VOICE_PROFILES.get(profile, VOICE_PROFILES["balanced"])[0]
    if gender in {"female", "male", "neutral"}:
        if voice not in VOICE_GENDER_HINTS.get(gender, {voice}):
            preferred = sorted(VOICE_GENDER_HINTS[gender])
            voice = preferred[0] if preferred else voice
    return voice


def render_background_jobs_tab(user_id: int) -> None:
    st.markdown("### 🛰️ الإنتاج الخلفي المتوازي")
    settings = st.session_state.get("settings") or get_user_settings(user_id)
    queue_backend = "Celery + Redis" if CFG.celery_broker_url else "Local Thread Executor"
    st.caption(f"المحرّك: {queue_backend} • الصور والفيديوهات الثقيلة تعمل خارج دورة واجهة Streamlit.")
    job_type = st.radio("نوع المهمة", ["🎬 فيديو طويل", "🖼️ صورة"], horizontal=True, key="background_job_type")

    if job_type == "🖼️ صورة":
        with st.form("background_image_form"):
            prompt = st.text_area("وصف الصورة", height=130, placeholder="مشهد سينمائي عالي الجودة...", key="background_image_prompt")
            c1, c2, c3, c4 = st.columns(4)
            preset = c1.selectbox("الأبعاد", ["1:1", "16:9", "9:16"], index=["1:1", "16:9", "9:16"].index(str(settings.get("image_preset", "1:1"))))
            quality = c2.selectbox("الجودة", ["standard", "high", "ultra"], index=["standard", "high", "ultra"].index(str(settings.get("image_quality", "high"))))
            model = c3.text_input("الموديل", value="flux")
            enhance = c4.checkbox("تحسين تلقائي", value=True)
            submitted = st.form_submit_button("🚀 إرسال الصورة إلى الطابور", type="primary", use_container_width=True)
        if submitted:
            if not prompt.strip():
                st.warning("اكتب وصف الصورة أولًا.")
            else:
                try:
                    enforce_rate_limit()
                    dims = {"1:1": (1024, 1024), "16:9": (1344, 768), "9:16": (768, 1344)}
                    width, height = dims[preset]
                    DATA_DIR.joinpath("jobs").mkdir(parents=True, exist_ok=True)
                    task_id = enqueue_pollinations_image(
                        work_root=str(DATA_DIR / "jobs"),
                        prompt=prompt, model=model, width=width, height=height,
                        enhance=enhance, quality=quality,
                    )
                    st.session_state["background_media_task_id"] = task_id
                    st.session_state["background_media_task_kind"] = "image"
                    st.session_state["background_media_registered"] = None
                    st.success(f"تم إرسال الصورة إلى الطابور. المعرّف: {task_id}")
                except Exception as exc:
                    st.error(f"تعذر إرسال المهمة: {exc}")
    else:
        with st.form("ultra_long_video_form"):
            prompt = st.text_area("وصف الفيلم الطويل", height=140, placeholder="اكتب المشهد أو السيناريو بالتفصيل مع وصف الشخصية والبيئة والحركة.", key="background_video_prompt")
            reference = st.file_uploader("الإطار المرجعي الاختياري للشخصية/المشهد", type=["png", "jpg", "jpeg", "webp"], key="ultra_reference")
            narration_text = st.text_area("نص التعليق الصوتي الاختياري", height=110, placeholder="سيتم استخدام XTTS-v2 المحلي عند تثبيته وتكوين البيئة.", key="background_video_narration")
            speaker = st.file_uploader("مرجع صوتي اختياري لـ XTTS-v2", type=["wav", "mp3", "flac"], key="ultra_speaker")
            c1, c2, c3, c4 = st.columns(4)
            total_seconds = c1.slider("المدة", 6, CFG.long_video_max_seconds, min(60, CFG.long_video_max_seconds), 6)
            aspect = c2.selectbox("النسبة", ["16:9", "9:16", "1:1"], index=["16:9", "9:16", "1:1"].index(str(settings.get("video_aspect", "16:9"))), key="background_video_aspect")
            language = c3.selectbox("لغة XTTS", ["ar", "en", "fr", "de", "es", "it", "pt", "tr", "ru", "zh-cn", "ja", "ko"], index=0, key="background_video_language")
            speed = c4.slider("سرعة الصوت", 0.5, 2.0, float(settings.get("tts_speed", 1.0)), 0.05, key="background_video_speed")
            submitted = st.form_submit_button("🚀 إرسال الفيديو إلى الطابور", type="primary", use_container_width=True)
        if submitted:
            if not prompt.strip():
                st.warning("اكتب وصف الفيديو أولاً.")
            else:
                try:
                    enforce_rate_limit()
                    reference_path = None
                    if reference is not None:
                        reference_data = reference.getvalue()
                        reference_media_id = save_media_asset(user_id, "image", reference_data, str(reference.type or "image/png"), "long_video_reference.png", "مرجع فيديو طويل")
                        reference_record = get_media_asset(user_id, reference_media_id)
                        reference_path = str(reference_record["storage_path"]) if reference_record else None
                    speaker_path = None
                    if speaker is not None:
                        speaker_media_id = save_media_asset(user_id, "audio", speaker.getvalue(), str(speaker.type or "audio/wav"), "xtts_reference.wav", "مرجع صوت XTTS")
                        speaker_record = get_media_asset(user_id, speaker_media_id)
                        speaker_path = str(speaker_record["storage_path"]) if speaker_record else None
                    dims = {"16:9": (768, 432), "9:16": (432, 768), "1:1": (512, 512)}
                    width, height = dims[aspect]
                    DATA_DIR.joinpath("jobs").mkdir(parents=True, exist_ok=True)
                    task_id = enqueue_long_video(
                        work_root=str(DATA_DIR / "jobs"), prompt=prompt, total_seconds=int(total_seconds),
                        width=int(width), height=int(height), seed=int(st.session_state.get("character_seed", 42)),
                        reference_image_path=reference_path, narration_text=narration_text.strip() or None,
                        narration_language=language, speaker_wav_path=speaker_path, tts_speed=float(speed),
                    )
                    st.session_state["background_media_task_id"] = task_id
                    st.session_state["background_media_task_kind"] = "video"
                    st.session_state["background_media_registered"] = None
                    st.success(f"تم إرسال الفيديو إلى الطابور. المعرّف: {task_id}")
                except Exception as exc:
                    st.error(f"تعذر إرسال المهمة: {exc}")

    active_task = str(st.session_state.get("background_media_task_id") or "").strip()
    if not active_task:
        st.info("لا توجد مهمة خلفية قيد المراقبة.")
        return

    @st.fragment(run_every="1s")
    def monitor_task() -> None:
        state = task_state(active_task)
        progress = max(0, min(100, int(state.get("progress", 0))))
        st.progress(progress, text=f"{state.get('message', 'جارٍ التنفيذ')} — {progress}%")
        st.caption(f"الحالة: {state.get('state', 'UNKNOWN')} • النوع: {st.session_state.get('background_media_task_kind', 'media')}")
        error = str(state.get("error", "")).strip()
        if error:
            st.error(error)
        if str(state.get("state")) == "SUCCESS" and not st.session_state.get("background_media_registered"):
            try:
                result = state.get("result") or {}
                media_id = register_background_result(user_id, result, "إنتاج وسائط في عامل الخلفية")
                conversation_id = ensure_conversation(user_id)
                kind = "فيديو" if st.session_state.get("background_media_task_kind") == "video" else "صورة"
                save_message(user_id, conversation_id, "assistant", f"✅ اكتمل {kind} في عامل الخلفية وتم حفظه في المكتبة.", "background-worker", media_id)
                st.session_state["background_media_registered"] = media_id
            except Exception as exc:
                st.error(f"اكتملت المهمة لكن تعذر تسجيل الملف: {exc}")
        registered = st.session_state.get("background_media_registered")
        if registered:
            render_media_asset(user_id, str(registered))

    monitor_task()

def render_media_tab(user_id: int) -> None:
    st.markdown("### 🎨 التوليد المرئي")
    settings = st.session_state.get("settings") or get_user_settings(user_id)
    image_tab, video_tab = st.tabs(["🖼️ صورة", "🎬 فيديو"])
    with image_tab:
        prompt = st.text_area("وصف الصورة", height=120, placeholder="مثال: مشهد سينمائي لمدينة مستقبلية عند الغروب", key="image_prompt")
        width, height = image_dimensions_from_preset(str(settings.get("image_preset", "square")))
        c1, c2, c3 = st.columns(3)
        c1.metric("العرض", f"{width}px")
        c2.metric("الارتفاع", f"{height}px")
        model = c3.text_input("نموذج Pollinations", value="flux", key="image_model")
        enhance = st.checkbox("تحسين تلقائي للجودة", value=True, key="image_enhance")
        seed_text = st.text_input("Seed اختياري", value="", key="image_seed")
        st.caption(f"الجودة: {settings.get('image_quality', 'high')} • Guidance Scale: {settings.get('guidance_scale', 7.5)} • الأبعاد: {width}×{height}")
        if st.button("توليد الصورة وعرضها داخل الشات", type="primary", use_container_width=True, key="generate_image_btn"):
            if not prompt.strip():
                st.warning("اكتب وصفًا للصورة أولًا.")
            else:
                try:
                    seed = int(seed_text) if seed_text.strip() else None
                    enforce_rate_limit()
                    with st.spinner("جاري التوليد..."):
                        data, content_type = generate_image(prompt, width, height, model, enhance, seed, str(settings.get("image_quality", "high")), float(settings.get("guidance_scale", 7.5)))
                        media_id = save_media_asset(user_id, "image", data, content_type, "generated_image.png", prompt)
                    st.success("تم توليد الصورة وحفظها.")
                    render_media_asset(user_id, media_id)
                    conversation_id = ensure_conversation(user_id)
                    save_message(user_id, conversation_id, "assistant", "🖼️ تم توليد صورة جديدة وحفظها في المحادثة وملفاتي التنزيلية.", "pollinations-image", media_id)
                    st.session_state["recent_media_id"] = media_id
                    st.caption("تم طلب إخراج بلا شعار باستخدام الخيار الرسمي nologo.")
                except Exception as exc:
                    st.error(str(exc))
    with video_tab:
        prompt = st.text_area("وصف الفيديو", height=120, placeholder="مثال: لقطة سينمائية لبحر هادئ مع حركة كاميرا بطيئة", key="video_prompt")
        duration = st.slider("المدة بالثواني", 3, 12, int(settings.get("video_duration", 5)), 1, key="video_duration_runtime")
        aspect = st.selectbox("نسبة الأبعاد", ["16:9", "9:16", "1:1"], index=["16:9", "9:16", "1:1"].index(str(settings.get("video_aspect", "16:9"))), key="video_aspect_runtime")
        resolution = st.selectbox("الدقة", ["480p", "720p", "1080p", "4k"], index=["480p", "720p", "1080p", "4k"].index(str(settings.get("video_resolution", "1080p"))), key="video_resolution_runtime")
        voiceover = st.checkbox("إضافة تعليق صوتي للنص", value=bool(settings.get("video_voiceover", 1)), key="video_voiceover_runtime")
        st.caption("سيتم تشغيل الفيديو داخل مشغل Streamlit، مع الصوت المدمج في الملف عند توفره، ويمكن إضافة تعليق صوتي متزامن عبر FFmpeg.")
        if st.button("توليد الفيديو وعرضه داخل الشات", type="primary", use_container_width=True, key="generate_video_btn"):
            if not prompt.strip():
                st.warning("اكتب وصف الفيديو أولًا.")
            else:
                try:
                    enforce_rate_limit()
                    with st.spinner("جاري توليد الفيديو..."):
                        video_data, content_type = generate_video(prompt, duration, aspect, resolution)
                        if voiceover:
                            voice = select_voice_for_profile(str(settings.get("voice_profile", "balanced")), str(settings.get("voice_gender", "neutral")))
                            audio_data, _ = text_to_speech(prompt, voice, float(settings.get("tts_speed", 1.0)))
                            video_data = mux_audio(video_data, audio_data)
                            content_type = "video/mp4"
                        media_id = save_media_asset(user_id, "video", video_data, content_type, "generated_video.mp4", prompt)
                    st.success("تم توليد الفيديو وحفظه.")
                    render_media_asset(user_id, media_id)
                    conversation_id = ensure_conversation(user_id)
                    save_message(user_id, conversation_id, "assistant", "🎬 تم توليد فيديو جديد وحفظه في المحادثة وملفاتي التنزيلية.", "pollinations-video", media_id)
                    st.session_state["recent_media_id"] = media_id
                except Exception as exc:
                    st.error(str(exc))


def render_omni_tab(user_id: int) -> None:
    st.markdown("### 🧠 الإدراك الحي متعدد الأنماط")
    settings = st.session_state.get("settings") or get_user_settings(user_id)
    st.caption("يلتقط محرك Omni الكاميرا والميكروفون ومشاركة الشاشة في جلسة متزامنة داخل المتصفح، ثم يرسل لقطات مضغوطة وصوتًا قصيرًا لمحرك الدمج عند الحاجة.")
    c1, c2, c3 = st.columns(3)
    enabled = c1.toggle("تشغيل الالتقاط الحي", value=bool(st.session_state.get("omni_auto_enabled", False)), key="omni_capture_enabled")
    include_system_audio = c2.toggle("صوت الشاشة/النظام", value=False, key="omni_system_audio")
    auto_fuse = c3.toggle("استجابة تلقائية كل فترة", value=bool(st.session_state.get("omni_auto_enabled", False)), key="omni_auto_fuse")
    if enabled:
        st.session_state["omni_auto_enabled"] = auto_fuse
        event = omni_capture(
            key=f"omni_capture_{user_id}",
            enabled=True,
            interval_ms=max(500, int(settings.get("omni_interval_seconds", 2)) * 1000),
            jpeg_quality=0.52,
            width=640,
            include_system_audio=include_system_audio,
            default=st.session_state.get("latest_omni_event"),
            websocket_url=build_omni_ws_url(user_id),
            language=str(settings.get("language_key", "auto")),
            dialect=str(settings.get("arabic_dialect", "auto")),
        )
        if event:
            st.session_state["latest_omni_event"] = event
    event = st.session_state.get("latest_omni_event") or {}
    gateway_answer = str(event.get("gateway_answer", "")).strip()
    gateway_audio = str(event.get("gateway_audio", "")).strip()
    if gateway_answer:
        st.markdown("#### ⚡ استجابة WebSocket منخفضة الكمون")
        st.markdown(gateway_answer)
        render_copy_button(gateway_answer, "نسخ استجابة البث الحي")
    if gateway_audio.startswith("data:audio/"):
        try:
            audio_raw, audio_mime = decode_data_url(gateway_audio)
            if audio_raw:
                st.audio(audio_raw, format=audio_mime)
        except Exception as exc:
            st.caption(f"تعذر تشغيل صوت البوابة الحية: {exc}")
    status = str(event.get("status", "idle"))
    if status == "error":
        st.error(str(event.get("error", "تعذر تشغيل الالتقاط الحي.")))
    elif status == "streaming":
        st.success("محرك Omni يلتقط الكاميرا والميكروفون ومشاركة الشاشة حاليًا.")
    elif status == "stopped":
        st.info("تم إيقاف الالتقاط الحي.")
    if event.get("fused_frame"):
        image_bytes, mime = decode_data_url(str(event["fused_frame"]))
        if image_bytes:
            st.image(image_bytes, caption="اللقطة المدمجة الحالية", use_container_width=True)
    preview_cols = st.columns(2)
    if event.get("camera_frame"):
        camera_bytes, _ = decode_data_url(str(event["camera_frame"]))
        if camera_bytes:
            with preview_cols[0]:
                st.image(camera_bytes, caption="الكاميرا", use_container_width=True)
    if event.get("screen_frame"):
        screen_bytes, _ = decode_data_url(str(event["screen_frame"]))
        if screen_bytes:
            with preview_cols[1]:
                st.image(screen_bytes, caption="الشاشة", use_container_width=True)
    st.divider()
    save_result = st.checkbox("حفظ التحليل في المحادثة", value=True, key="omni_save_chat")
    if st.button("🔎 تحليل اللقطة والصوت الآن", type="primary", use_container_width=True, key="omni_analyze_now"):
        if not event.get("fused_frame"):
            st.warning("ابدأ الالتقاط الحي أولًا وانتظر وصول لقطة.")
        else:
            try:
                fused_bytes, fused_mime = decode_data_url(str(event.get("fused_frame", "")))
                audio_bytes, audio_mime = decode_data_url(str(event.get("audio_chunk", "")))
                transcript = ""
                if audio_bytes:
                    transcript = speech_to_text(
                        audio_bytes,
                        "omni_audio.webm" if audio_mime == "audio/webm" else "omni_audio.bin",
                        str(settings.get("language_key", "auto")),
                        str(settings.get("arabic_dialect", "auto")),
                        mime_type=audio_mime,
                    )
                prompt = "حلل هذه اللقطة الحية المشتركة بين الكاميرا والشاشة."
                if transcript:
                    prompt += f"\nالنص المنسوخ من الميكروفون: {transcript}"
                image_uri = file_to_data_uri(fused_bytes, fused_mime or "image/jpeg")
                with st.spinner("دمج الرؤية والصوت والسياق المعرفي..."):
                    answer, provider = generate_response(get_messages(user_id, ensure_conversation(user_id)), prompt, transcript, [image_uri])
                st.markdown("#### الاستجابة الفورية")
                st.markdown(answer)
                render_copy_button(answer)
                voice = select_voice_for_profile(str(settings.get("voice_profile", "balanced")), str(settings.get("voice_gender", "neutral")))
                try:
                    audio_out, audio_out_mime = text_to_speech(answer, voice, float(settings.get("tts_speed", 1.0)))
                    st.audio(audio_out, format=audio_out_mime)
                except Exception as exc:
                    st.caption(f"تعذر إخراج الصوت: {exc}")
                if save_result:
                    conversation_id = ensure_conversation(user_id)
                    save_message(user_id, conversation_id, "user", transcript or "لقطة Omni حية", "omni-input")
                    save_message(user_id, conversation_id, "assistant", answer, provider)
                    if CFG.memory_index_interactions:
                        try:
                            get_knowledge_engine(user_id).index_interaction(transcript or prompt, answer, conversation_id)
                        except Exception as exc:
                            st.caption(f"لم تُحفظ ذاكرة التفاعل المتجهية: {exc}")
            except Exception as exc:
                st.error(str(exc))
    if enabled and auto_fuse and event.get("status") == "streaming":
        now = time.monotonic()
        event_timestamp = int(event.get("timestamp", 0))
        last_event = int(st.session_state.get("last_omni_event_timestamp", 0))
        if event_timestamp > last_event:
            st.session_state["last_omni_event_timestamp"] = event_timestamp
            if now - float(st.session_state.get("last_omni_fusion_at", 0.0)) >= max(5, CFG.omni_auto_response_seconds):
                st.session_state["last_omni_fusion_at"] = now
                try:
                    fused_bytes, fused_mime = decode_data_url(str(event.get("fused_frame", "")))
                    audio_bytes, audio_mime = decode_data_url(str(event.get("audio_chunk", "")))
                    transcript = ""
                    if audio_bytes:
                        transcript = speech_to_text(audio_bytes, "auto_omni.webm", str(settings.get("language_key", "auto")), str(settings.get("arabic_dialect", "auto")), mime_type=audio_mime)
                    prompt = "أعطني استجابة فورية لما يظهر على الشاشة وما تقوله الكاميرا/الميكروفون معًا."
                    if transcript:
                        prompt += f"\nالصوت الأخير: {transcript}"
                    uri = file_to_data_uri(fused_bytes, fused_mime or "image/jpeg")
                    answer, provider = generate_response(get_messages(user_id, ensure_conversation(user_id)), prompt, transcript, [uri])
                    st.session_state["omni_last_answer"] = answer
                    st.session_state["omni_last_provider"] = provider
                    try:
                        voice = select_voice_for_profile(
                            str(settings.get("voice_profile", "balanced")),
                            str(settings.get("voice_gender", "neutral")),
                        )
                        auto_audio, auto_audio_mime = text_to_speech(
                            answer, voice, float(settings.get("tts_speed", 1.0))
                        )
                        st.session_state["omni_last_audio"] = auto_audio
                        st.session_state["omni_last_audio_mime"] = auto_audio_mime
                    except Exception as audio_exc:
                        st.session_state["omni_last_audio"] = None
                        st.session_state["omni_last_audio_mime"] = None
                        st.session_state["omni_last_error"] = f"تمت الإجابة النصية، وتعذر إخراج الصوت: {audio_exc}"
                except Exception as exc:
                    st.session_state["omni_last_error"] = str(exc)
        if st.session_state.get("omni_last_answer"):
            st.info("آخر استجابة تلقائية")
            st.markdown(st.session_state["omni_last_answer"])
            render_copy_button(str(st.session_state["omni_last_answer"]), "نسخ استجابة Omni")
            if st.session_state.get("omni_last_audio"):
                st.audio(
                    st.session_state["omni_last_audio"],
                    format=st.session_state.get("omni_last_audio_mime") or "audio/mpeg",
                )
        if st.session_state.get("omni_last_error"):
            st.caption(f"تنبيه Omni: {st.session_state['omni_last_error']}")


def persist_reference_image(user_id: int, uploaded: Any) -> tuple[Image.Image, str]:
    data = uploaded.getvalue()
    digest = hashlib.sha256(data).hexdigest()
    current_hash = st.session_state.get("character_reference_hash")
    if current_hash != digest:
        media_id = save_media_asset(user_id, "image", data, str(uploaded.type or "image/png"), f"character_reference_{digest[:12]}.png", "مرجع شخصية ثابت")
        st.session_state["character_reference_hash"] = digest
        st.session_state["character_reference_media_id"] = media_id
    return Image.open(io.BytesIO(data)).convert("RGB"), digest


def get_persisted_reference_image(user_id: int) -> Image.Image | None:
    media_id = st.session_state.get("character_reference_media_id")
    if not media_id:
        return None
    asset = get_media_asset(user_id, str(media_id))
    if not asset:
        return None
    try:
        return Image.open(io.BytesIO(asset["data"])).convert("RGB")
    except Exception:
        return None


def render_controlled_generation_tab(user_id: int) -> None:
    st.markdown("### 🧭 التوليد المحلي المتحكم به وثبات الشخصية")
    st.caption("يستخدم Flux/ControlNet/IP-Adapter للصور وCogVideoX للتحكم بالفيديو عند تفعيل النماذج المحلية. الأوزان تُحمّل كسولياً، وتحتاج بيئة GPU مناسبة للوصول إلى سرعات عملية.")
    settings = st.session_state.get("settings") or get_user_settings(user_id)
    ref_upload = st.file_uploader("صورة مرجعية للشخصية", type=["png", "jpg", "jpeg", "webp"], key="controlled_reference")
    reference_image = get_persisted_reference_image(user_id)
    if ref_upload is not None:
        try:
            reference_image, _ = persist_reference_image(user_id, ref_upload)
        except Exception as exc:
            st.error(f"تعذر حفظ المرجع: {exc}")
            reference_image = None
    if reference_image is not None:
        st.image(reference_image, caption="مرجع الشخصية المثبت", width=220)
        st.caption("يُعاد استخدام هذا المرجع في الأجيال المتعاقبة للحفاظ على الهوية البصرية بأكبر قدر تسمح به الأوزان المستخدمة؛ لا يوجد ضمان رياضي لهوية وجه مطابقة 100% عبر كل إطار.")
    image_control, video_control = st.tabs(["🖼️ Flux + ControlNet/IP-Adapter", "🎬 CogVideoX Control"])
    with image_control:
        prompt = st.text_area("Prompt محلي", height=120, key="controlled_image_prompt")
        control_upload = st.file_uploader("صورة تخطيط/وضعية للتحكم الهيكلي", type=["png", "jpg", "jpeg", "webp"], key="control_image_upload")
        mode = st.selectbox("نوع التحكم", ["canny", "depth", "pose", "sketch"], format_func={"canny": "Canny Edges", "depth": "Depth / مرجع عمق", "pose": "Pose / مرجع وضعية", "sketch": "Sketch / مخطط"}.get, key="control_mode")
        c1, c2, c3 = st.columns(3)
        width, height = image_dimensions_from_preset(str(settings.get("image_preset", "square")))
        c1.metric("الأبعاد", f"{width}×{height}")
        control_scale = c2.slider("ControlNet Scale", 0.1, 1.5, float(settings.get("controlnet_scale", 0.9)), 0.05, key="runtime_controlnet_scale")
        ip_scale = c3.slider("IP-Adapter Scale", 0.0, 1.5, float(settings.get("ip_adapter_scale", 0.75)), 0.05, key="runtime_ip_scale")
        steps = st.slider("Inference Steps", 4, 40, 20, 1, key="controlled_image_steps")
        seed_text = st.text_input("Seed ثابت للاتساق", value=str(st.session_state.get("character_seed", 42)), key="character_seed_input")
        if st.button("⚡ توليد صورة محلية متحكم بها", type="primary", use_container_width=True, key="controlled_image_btn"):
            if not prompt.strip():
                st.warning("اكتب Prompt أولًا.")
            elif control_upload is None and reference_image is None:
                st.warning("ارفع صورة مرجعية أو صورة تحكم هيكلي واحدة على الأقل.")
            else:
                try:
                    enforce_rate_limit()
                    seed = int(seed_text.strip() or "42")
                    st.session_state["character_seed"] = seed
                    control_image = Image.open(io.BytesIO(control_upload.getvalue())).convert("RGB") if control_upload else None
                    service = get_controlled_generation_service()
                    with st.spinner("تحميل/تشغيل Flux + ControlNet/IP-Adapter..."):
                        data = service.generate_flux(
                            prompt=prompt,
                            width=width,
                            height=height,
                            guidance_scale=float(settings.get("guidance_scale", 7.5)),
                            steps=steps,
                            seed=seed,
                            control_image=control_image,
                            reference_image=reference_image,
                            control_mode=mode,
                            controlnet_scale=float(control_scale),
                            ip_adapter_scale=ip_scale,
                        )
                    media_id = save_media_asset(user_id, "image", data, "image/png", f"controlled_flux_{seed}.png", prompt)
                    render_media_asset(user_id, media_id)
                    conversation_id = ensure_conversation(user_id)
                    save_message(user_id, conversation_id, "assistant", "🧭 تم توليد صورة محلية مع تحكم هيكلي/مرجع شخصية.", "local-flux-control", media_id)
                except Exception as exc:
                    st.error(str(exc))
    with video_control:
        prompt = st.text_area("Prompt الفيديو المحلي", height=120, key="controlled_video_prompt")
        control_video = st.file_uploader("فيديو تحكم اختياري للحركة والوضعية", type=["mp4", "mov", "webm"], key="control_video_upload")
        c1, c2, c3 = st.columns(3)
        aspect = str(settings.get("video_aspect", "16:9"))
        dims = {"16:9": (768, 432), "9:16": (432, 768), "1:1": (512, 512)}
        width, height = dims.get(aspect, (768, 432))
        c1.metric("الأبعاد", f"{width}×{height}")
        c2.metric("نموذج الفيديو", CFG.local_video_model_id)
        c3.metric("GPU", "CUDA" if torch is not None and torch.cuda.is_available() else "CPU")
        steps = st.slider("Inference Steps للفيديو", 10, 50, 30, 2, key="controlled_video_steps")
        seed = st.number_input("Seed", min_value=0, max_value=2_147_483_647, value=int(st.session_state.get("character_seed", 42)), step=1, key="controlled_video_seed")
        if st.button("⚡ توليد فيديو محلي متحكم به", type="primary", use_container_width=True, key="controlled_video_btn"):
            if not prompt.strip():
                st.warning("اكتب Prompt الفيديو أولًا.")
            else:
                try:
                    enforce_rate_limit()
                    control_bytes = control_video.getvalue() if control_video else None
                    service = get_controlled_generation_service()
                    with st.spinner("تشغيل CogVideoX؛ قد يحتاج وقتًا وذاكرة كبيرة..."):
                        data = service.generate_cogvideox(
                            prompt=prompt,
                            guidance_scale=float(settings.get("guidance_scale", 6.0)),
                            steps=int(steps),
                            seed=int(seed),
                            control_video_bytes=control_bytes,
                            reference_image=reference_image,
                            width=width,
                            height=height,
                        )
                    media_id = save_media_asset(user_id, "video", data, "video/mp4", f"controlled_cogvideox_{int(seed)}.mp4", prompt)
                    render_media_asset(user_id, media_id)
                    conversation_id = ensure_conversation(user_id)
                    save_message(user_id, conversation_id, "assistant", "🎬 تم توليد فيديو محلي باستخدام CogVideoX مع التحكم المتاح.", "local-cogvideox-control", media_id)
                except Exception as exc:
                    st.error(str(exc))


def render_files_tab(user_id: int) -> None:
    st.markdown("### 📎 الملفات والروابط")
    uploaded = st.file_uploader(
        "ارفع PDF أو نصًا أو كودًا أو صورة أو فيديو أو ملفًا صوتيًا",
        type=["pdf", "txt", "md", "csv", "json", "yaml", "yml", "toml", "py", "js", "ts", "tsx", "jsx", "java", "c", "cpp", "h", "hpp", "html", "css", "sql", "sh", "png", "jpg", "jpeg", "webp", "mp4", "mov", "mkv", "webm", "wav", "mp3", "m4a"],
        key="universal_file_uploader",
    )
    if uploaded is not None:
        if uploaded.size and uploaded.size > MAX_UPLOAD_SIZE_MB * 1024 * 1024:
            st.error(f"حجم الملف يتجاوز الحد المسموح {MAX_UPLOAD_SIZE_MB} MB.")
        else:
            try:
                file_hash = hashlib.sha256(uploaded.getvalue()).hexdigest()
                if st.session_state.get("last_file_hash") != file_hash:
                    info = analyze_uploaded_file(uploaded)
                    st.session_state["last_file_hash"] = file_hash
                    st.session_state["active_file_context"] = info["context"]
                    st.session_state["active_image_data_uris"] = info.get("image_data_uris", [])
                    try:
                        index_result = index_knowledge(user_id, info["name"], "uploaded-file", info["context"], source_hash=stable_source_hash(info["name"], info["context"]))
                        if index_result.get("duplicate"):
                            st.info("الملف موجود مسبقًا في الذاكرة المعرفية المتجهية.")
                        elif index_result.get("indexed"):
                            st.caption(f"تمت أرشفة الملف معرفيًا في {index_result['chunks']} مقطعًا متجهيًا.")
                    except Exception as knowledge_exc:
                        st.warning(f"تعذر فهرسة الملف في قاعدة المعرفة: {knowledge_exc}")
                    if info.get("preview") is not None:
                        st.image(info["preview"], use_container_width=True)
                    st.success(f"تم تجهيز {info['name']} للتحليل داخل المحادثة والذاكرة المعرفية.")
                else:
                    st.info("هذا الملف مُجهز بالفعل.")
            except Exception as exc:
                st.error(str(exc))
    if st.session_state.get("active_file_context"):
        with st.expander("السياق الحالي للملف", expanded=False):
            st.text(st.session_state["active_file_context"][:CFG.max_file_context_chars])

    st.divider()
    st.markdown("#### قراءة رابط آمن")
    url = st.text_input("الرابط HTTPS", placeholder="https://example.com/page", key="safe_url_input")
    if st.button("قراءة الرابط", use_container_width=True, key="fetch_url_btn"):
        try:
            with st.spinner("جاري جلب الرابط..." ):
                page = fetch_url(url)
            st.session_state["active_url_context"] = page["context"]
            try:
                url_hash = stable_source_hash(page["final_url"], page["context"])
                index_result = index_knowledge(user_id, page["final_url"], "url", page["context"], source_hash=url_hash)
                if index_result.get("indexed"):
                    st.caption(f"تمت فهرسة صفحة الويب في {index_result['chunks']} مقاطع متجهية.")
                elif index_result.get("duplicate"):
                    st.caption("هذه الصفحة موجودة مسبقًا في الذاكرة المعرفية.")
            except Exception as knowledge_exc:
                st.warning(f"تعذر فهرسة الرابط معرفيًا: {knowledge_exc}")
            st.success(f"تمت القراءة. الرابط النهائي: {page['final_url']}")
            if page["links"]:
                st.markdown("**روابط مستخرجة:**")
                for item in page["links"]:
                    st.link_button(item["label"][:80], item["url"], use_container_width=False)
            with st.expander("نص الصفحة", expanded=False):
                st.text(page["text"][:CFG.max_url_chars])
        except Exception as exc:
            st.error(str(exc))


def render_audio_tab(user_id: int) -> None:
    st.markdown("### 🎙️ النظام الصوتي العالمي")
    settings = st.session_state.get("settings") or get_user_settings(user_id)
    st.caption("يدعم التسجيل الصوتي، والنسخ التلقائي مع Whisper، والنطق متعدد اللغات. اختيار اللهجة العربية يعمل كإشارة سياقية للنسخ والرد.")
    audio = st.audio_input("🎙️ سجل رسالتك", sample_rate=16000, key="global_audio_input")
    if audio is not None:
        audio_bytes = audio.getvalue()
        digest = hashlib.sha256(audio_bytes).hexdigest()
        st.audio(audio_bytes)
        if st.session_state.get("pending_audio_hash") != digest:
            if st.button("تحويل الكلام إلى نص", use_container_width=True, key="transcribe_btn"):
                try:
                    with st.spinner("جاري النسخ الصوتي..." ):
                        text_value = speech_to_text(
                            audio_bytes,
                            "recording.wav",
                            str(settings.get("language_key", "auto")),
                            str(settings.get("arabic_dialect", "auto")),
                        )
                    st.session_state["pending_audio_hash"] = digest
                    st.session_state["pending_audio_text"] = text_value
                    st.session_state["pending_input_text"] = text_value
                except Exception as exc:
                    st.error(str(exc))
        if st.session_state.get("pending_audio_text"):
            text_value = st.text_area("النص المستخرج", value=st.session_state["pending_audio_text"], height=120, key="transcribed_text_editor")
            if st.button("إرسال النص للمحادثة", type="primary", use_container_width=True, key="send_transcribed_btn"):
                st.session_state["pending_input_text"] = text_value.strip()
                st.session_state["force_chat_prompt"] = text_value.strip()
                st.session_state["pending_audio_text"] = ""
                st.session_state["active_tab_hint"] = "chat"
                st.rerun()
            render_copy_button(text_value, "نسخ النص")
    st.divider()
    tts_text = st.text_area("نص للنطق", height=120, key="tts_input")
    voice = select_voice_for_profile(str(settings.get("voice_profile", "balanced")), str(settings.get("voice_gender", "neutral")))
    st.caption(f"الصوت: {voice} • السرعة: {float(settings.get('tts_speed', 1.0)):.2f}x")
    if st.button("🔊 إنشاء صوت", use_container_width=True, key="tts_generate_btn"):
        if not tts_text.strip():
            st.warning("اكتب النص أولًا.")
        else:
            try:
                enforce_rate_limit()
                with st.spinner("جاري إنشاء الصوت..."):
                    data, mime = text_to_speech(tts_text, voice, float(settings.get("tts_speed", 1.0)))
                    media_id = save_media_asset(user_id, "audio", data, mime, "speech.mp3", tts_text)
                st.audio(data, format=mime)
                st.download_button("⬇️ تنزيل الصوت", data=data, file_name="speech.mp3", mime=mime, use_container_width=True, key=f"tts_dl_{media_id}")
                st.success("تم حفظ الصوت داخل ملفاتي التنزيلية.")
            except Exception as exc:
                st.error(str(exc))


def render_export_tab(user_id: int) -> None:
    conversation_id = ensure_conversation(user_id)
    messages = get_messages(user_id, conversation_id)
    st.markdown("### تصدير المحادثة")
    if not messages:
        st.info("لا توجد رسائل لتصديرها.")
        return
    col1, col2, col3 = st.columns(3)
    with col1:
        try:
            pdf_data = build_pdf(messages)
            st.download_button("⬇️ PDF", data=pdf_data, file_name="chat_export.pdf", mime="application/pdf", use_container_width=True)
        except Exception as exc:
            st.error(f"PDF: {exc}")
    with col2:
        try:
            xlsx_data = build_excel(messages)
            st.download_button("⬇️ Excel", data=xlsx_data, file_name="chat_export.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)
        except Exception as exc:
            st.error(f"Excel: {exc}")
    with col3:
        txt_data = build_txt(messages)
        st.download_button("⬇️ TXT", data=txt_data, file_name="chat_export.txt", mime="text/plain; charset=utf-8", use_container_width=True)


def render_settings_tab(user_id: int) -> None:
    st.markdown("### ⚙️ لوحة الإعدادات")
    settings = st.session_state.get("settings") or get_user_settings(user_id)
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("المساحة المستخدمة", human_size(total_media_storage(user_id)))
    with col2:
        st.metric("عدد المحادثات", len(list_conversations(user_id)))
    with col3:
        st.metric("عدد الملفات", len(list_media_assets(user_id)))
    try:
        knowledge_stats = get_knowledge_engine(user_id).stats()
        st.metric("مقاطع الذاكرة المتجهية", knowledge_stats["chunks"])
    except Exception:
        st.metric("مقاطع الذاكرة المتجهية", "غير جاهزة")
    st.divider()
    st.markdown("#### مظهر الواجهة")
    st.info(f"المظهر الحالي: { {'auto': 'تلقائي', 'dark': 'داكن', 'light': 'فاتح'}.get(str(settings.get('appearance', 'auto')), 'تلقائي') }")
    st.markdown("تم ضبط المظهر عبر إعدادات الحساب في الشريط الجانبي، مع دعم ثيمات Streamlit الفاتحة والداكنة.")
    st.divider()
    render_account_management(user_id)
    st.divider()
    render_download_library(user_id)


def main() -> None:
    st.set_page_config(
        page_title=CFG.app_name,
        page_icon="🤖",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    init_db()
    init_session()
    if not st.session_state["authenticated"]:
        inject_styles()
        render_login()
        return
    user = st.session_state["user"]
    if not user:
        st.session_state["authenticated"] = False
        st.rerun()
    user_id = int(user["id"])
    if st.session_state.get("settings") is None:
        st.session_state["settings"] = get_user_settings(user_id)
    inject_styles()
    render_sidebar(user_id)
    st.markdown(
        f"<div class='hero'><h1>🤖 {html.escape(CFG.app_name)}</h1><div class='muted'>مساعد مؤسسي متعدد الوسائط — مطور رئيسي: {html.escape(CFG.developer_name)}</div><div><span class='pill'>Groq</span><span class='pill'>Phi-3 Fallback</span><span class='pill'>SQLite</span><span class='pill'>Vision</span><span class='pill'>PDF / Excel / TXT</span><span class='pill'>STT / TTS</span><span class='pill'>Inline Media</span><span class='pill'>Multi-Language</span><span class='pill'>Omni Live</span><span class='pill'>Vector RAG</span><span class='pill'>ControlNet</span><span class='pill'>IP-Adapter</span><span class='pill'>Flux</span><span class='pill'>CogVideoX</span></div></div>",
        unsafe_allow_html=True,
    )
    chat_tab, media_tab, omni_tab, control_tab, jobs_tab, files_tab, audio_tab, export_tab, settings_tab = st.tabs(["💬 المحادثة", "🎨 الوسائط", "🧠 Omni الحي", "🧭 التوليد المحلي المتحكم", "🛰️ الإنتاج الخلفي", "📎 الملفات والروابط", "🎙️ الصوت", "📤 التصدير", "⚙️ الإعدادات"])
    with chat_tab:
        render_chat_tab(user_id)
    with media_tab:
        render_media_tab(user_id)
    with omni_tab:
        render_omni_tab(user_id)
    with control_tab:
        render_controlled_generation_tab(user_id)
    with jobs_tab:
        render_background_jobs_tab(user_id)
    with files_tab:
        render_files_tab(user_id)
    with audio_tab:
        render_audio_tab(user_id)
    with export_tab:
        render_export_tab(user_id)
    with settings_tab:
        render_settings_tab(user_id)


if __name__ == "__main__":
    main()
