from __future__ import annotations

import os
import platform
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class HardwareProfile:
    platform: str
    python: str
    cpu_count: int
    ram_gb: float
    torch_version: str
    device: str
    gpu_name: str
    gpu_count: int
    gpu_memory_gb: float
    bf16: bool
    fp16: bool
    recommended_dtype: str
    recommended_video_chunk_seconds: int
    recommended_quantization: str


def detect_hardware() -> HardwareProfile:
    import os as _os
    import sys
    ram_gb = 0.0
    try:
        pages = _os.sysconf("SC_PHYS_PAGES")
        page_size = _os.sysconf("SC_PAGE_SIZE")
        ram_gb = pages * page_size / (1024 ** 3)
    except (AttributeError, OSError, ValueError):
        pass
    try:
        import psutil
        ram_gb = float(psutil.virtual_memory().total) / (1024 ** 3)
    except Exception:
        pass

    torch_version = "unavailable"
    device = "cpu"
    gpu_name = ""
    gpu_count = 0
    gpu_memory_gb = 0.0
    bf16 = False
    fp16 = False
    try:
        import torch
        torch_version = str(torch.__version__)
        if torch.cuda.is_available():
            device = "cuda"
            gpu_count = int(torch.cuda.device_count())
            props = torch.cuda.get_device_properties(0)
            gpu_name = str(props.name)
            gpu_memory_gb = float(props.total_memory) / (1024 ** 3)
            bf16 = bool(torch.cuda.is_bf16_supported())
            fp16 = True
        else:
            mps = getattr(torch.backends, "mps", None)
            if mps is not None and mps.is_available():
                device = "mps"
                fp16 = True
    except Exception:
        pass

    if device == "cuda":
        dtype = "bfloat16" if bf16 else "float16"
        if gpu_memory_gb >= 32:
            chunk_seconds = 10
        elif gpu_memory_gb >= 16:
            chunk_seconds = 8
        elif gpu_memory_gb >= 10:
            chunk_seconds = 6
        else:
            chunk_seconds = 4
        quantization = "4bit-bnb" if gpu_memory_gb < 24 else "fp16/bf16"
    elif device == "mps":
        dtype = "float16"
        chunk_seconds = 4
        quantization = "cpu-safe"
    else:
        dtype = "float32"
        chunk_seconds = 2 if ram_gb < 32 else 4
        quantization = "dynamic-int8-when-supported"

    return HardwareProfile(
        platform=platform.platform(),
        python=sys.version.split()[0],
        cpu_count=max(1, int(_os.cpu_count() or 1)),
        ram_gb=round(max(0.0, ram_gb), 2),
        torch_version=torch_version,
        device=device,
        gpu_name=gpu_name,
        gpu_count=gpu_count,
        gpu_memory_gb=round(gpu_memory_gb, 2),
        bf16=bf16,
        fp16=fp16,
        recommended_dtype=dtype,
        recommended_video_chunk_seconds=chunk_seconds,
        recommended_quantization=quantization,
    )


def model_load_kwargs() -> dict[str, Any]:
    profile = detect_hardware()
    kwargs: dict[str, Any] = {
        "device_map": "auto" if profile.device == "cuda" else None,
        "low_cpu_mem_usage": True,
    }
    try:
        import torch
        if profile.device == "cuda":
            kwargs["torch_dtype"] = torch.bfloat16 if profile.bf16 else torch.float16
        elif profile.device == "mps":
            kwargs["torch_dtype"] = torch.float16
        else:
            kwargs["torch_dtype"] = torch.float32
    except Exception:
        pass

    if profile.device == "cuda" and profile.recommended_quantization == "4bit-bnb":
        try:
            from transformers import BitsAndBytesConfig
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type=os.getenv("BNB_4BIT_QUANT_TYPE", "nf4"),
                bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=torch.bfloat16 if profile.bf16 else torch.float16,
            )
            kwargs.pop("torch_dtype", None)
        except Exception:
            pass
    return kwargs


def configure_runtime() -> HardwareProfile:
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    profile = detect_hardware()
    if profile.device == "cuda":
        os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True,max_split_size_mb:256")
    return profile


def as_dict() -> dict[str, Any]:
    return asdict(detect_hardware())
