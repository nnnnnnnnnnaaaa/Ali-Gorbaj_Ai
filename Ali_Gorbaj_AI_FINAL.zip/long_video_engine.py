from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import tempfile
import uuid
from functools import lru_cache
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Callable

from PIL import Image

from hardware import configure_runtime
from ai_acceleration import clear_device_memory, optimize_diffusion_pipeline
from model_manager import select_best
from lipsync import Wav2LipLocalEngine, LipSyncOrchestrator
from media_quality import MediaQualityEngine
from owned_media_cleanup import auto_corner_overlay_mask

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import torch
except ImportError:
    torch = None

try:
    from diffusers import CogVideoXImageToVideoPipeline
except ImportError:
    CogVideoXImageToVideoPipeline = None

try:
    from diffusers.utils import export_to_video, load_image
except ImportError:
    export_to_video = None
    load_image = None

try:
    from TTS.api import TTS
except ImportError:
    TTS = None

try:
    import imageio_ffmpeg
except ImportError:
    imageio_ffmpeg = None

ProgressCallback = Callable[[int, str], None]


@dataclass(frozen=True)
class LongVideoConfig:
    model_id: str = os.getenv("LOCAL_VIDEO_I2V_MODEL_ID", os.getenv("LOCAL_VIDEO_MODEL_ID", "auto"))
    fps: int = int(os.getenv("LONG_VIDEO_FPS", "8"))
    chunk_seconds: int = int(os.getenv("LONG_VIDEO_CHUNK_SECONDS", "6"))
    overlap_frames: int = int(os.getenv("LONG_VIDEO_OVERLAP_FRAMES", "5"))
    max_seconds: int = int(os.getenv("LONG_VIDEO_MAX_SECONDS", "1800"))
    interpolation_fps: int = int(os.getenv("LONG_VIDEO_INTERPOLATION_FPS", "25"))
    use_interpolation: bool = os.getenv("LONG_VIDEO_INTERPOLATION", "1").lower() in {"1", "true", "yes", "on"}
    steps: int = int(os.getenv("LONG_VIDEO_STEPS", "50"))
    guidance_scale: float = float(os.getenv("LONG_VIDEO_GUIDANCE_SCALE", "6.0"))
    seed: int = int(os.getenv("LONG_VIDEO_SEED", "42"))
    audio_language: str = os.getenv("XTTS_LANGUAGE", "ar")
    tts_model: str = os.getenv("XTTS_MODEL_ID", "tts_models/multilingual/multi-dataset/xtts_v2")
    ffmpeg_threads: int = int(os.getenv("FFMPEG_THREADS", "2"))


class UltraLongVideoEngine:
    def __init__(self, work_root: str | Path, env: dict[str, str] | None = None) -> None:
        self.work_root = Path(work_root).resolve()
        self.work_root.mkdir(parents=True, exist_ok=True)
        self.env = env or os.environ
        self.cfg = LongVideoConfig()
        self.hardware = configure_runtime()
        if self.cfg.model_id.strip().lower() in {"", "auto"}:
            self.cfg = replace(self.cfg, model_id=select_best("video-i2v", self.env).repo_id)
        self._pipe_cache: dict[tuple[str, str, str], Any] = {}
        self._tts_cache: dict[tuple[str, bool], Any] = {}

    def _ffmpeg(self) -> str:
        if imageio_ffmpeg is not None:
            return imageio_ffmpeg.get_ffmpeg_exe()
        path = shutil.which("ffmpeg")
        if path:
            return path
        raise RuntimeError("FFmpeg غير متاح. ثبّت imageio-ffmpeg أو ffmpeg على النظام.")

    def _device_dtype(self) -> tuple[str, Any]:
        if torch is None:
            raise RuntimeError("PyTorch غير مثبت.")
        if torch.cuda.is_available():
            dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
            return "cuda", dtype
        mps = getattr(torch.backends, "mps", None)
        if mps is not None and mps.is_available():
            return "mps", torch.float16
        return "cpu", torch.float32

    def _auth_kwargs(self) -> dict[str, Any]:
        token = self.env.get("HF_TOKEN", "").strip()
        return {"token": token} if token else {}

    def _pipeline(self) -> Any:
        if CogVideoXImageToVideoPipeline is None:
            raise RuntimeError("CogVideoXImageToVideoPipeline غير متاح في Diffusers.")
        device, dtype = self._device_dtype()
        key = (self.cfg.model_id, device, str(dtype))
        if key in self._pipe_cache:
            return self._pipe_cache[key]
        pipe = CogVideoXImageToVideoPipeline.from_pretrained(
            self.cfg.model_id,
            torch_dtype=dtype,
            **self._auth_kwargs(),
        )
        pipe, metadata = optimize_diffusion_pipeline(pipe, "cogvideox")
        setattr(pipe, "_ali_acceleration_metadata", metadata)
        self._pipe_cache[key] = pipe
        return pipe

    def _extract_last_frame(self, video_path: Path) -> Image.Image:
        if cv2 is None:
            raise RuntimeError("OpenCV مطلوب لاستخراج إطار الاستمرارية.")
        capture = cv2.VideoCapture(str(video_path))
        if not capture.isOpened():
            capture.release()
            raise RuntimeError("تعذر فتح مقطع الفيديو الناتج.")
        total = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        if total > 1:
            capture.set(cv2.CAP_PROP_POS_FRAMES, total - 1)
        ok, frame = capture.read()
        capture.release()
        if not ok or frame is None:
            raise RuntimeError("تعذر استخراج آخر إطار من المقطع.")
        return Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)).convert("RGB")

    def _generate_chunk(
        self,
        prompt: str,
        anchor: Image.Image,
        output_path: Path,
        seed: int,
        width: int,
        height: int,
        duration_seconds: float,
        extra_frames: int = 0,
    ) -> None:
        pipe = self._pipeline()
        device, _ = self._device_dtype()
        generator_device = device if device != "mps" else "cpu"
        generator = torch.Generator(device=generator_device).manual_seed(int(seed))
        model_name = self.cfg.model_id.lower()
        is_15 = "1.5" in model_name or "1_5" in model_name
        ratio = max(0.25, min(4.0, float(width) / max(1.0, float(height))))
        model_height = 768 if is_15 else max(16, int(height) - int(height) % 16)
        model_width = int(round((model_height * ratio) / 16.0) * 16) if is_15 else max(16, int(width) - int(width) % 16)
        if is_15:
            model_width = max(768, min(1360, model_width))
        frame_count = 81
        if is_15 and duration_seconds > 7.5:
            frame_count = 161
        elif not is_15:
            frame_count = max(49, int(round(self.cfg.fps * max(1.0, duration_seconds))) + 1 + max(0, int(extra_frames)))
        kwargs = {
            "image": anchor.resize((model_width, model_height)),
            "prompt": prompt,
            "height": model_height,
            "width": model_width,
            "num_frames": frame_count,
            "num_inference_steps": self.cfg.steps,
            "guidance_scale": self.cfg.guidance_scale,
            "generator": generator,
            "use_dynamic_cfg": True,
        }
        result = pipe(**kwargs)
        frames = result.frames[0]
        if export_to_video is None:
            raise RuntimeError("export_to_video غير متاح في إصدار Diffusers الحالي.")
        source_fps = 16 if is_15 else self.cfg.fps
        export_to_video(frames, str(output_path), fps=source_fps)

    def _trim_chunk_head(self, input_path: Path, output_path: Path, skip_frames: int) -> None:
        if skip_frames <= 0:
            shutil.copy2(input_path, output_path)
            return
        if cv2 is None:
            raise RuntimeError("OpenCV مطلوب لإزالة الإطارات المتداخلة بين المقاطع.")
        reader = cv2.VideoCapture(str(input_path))
        if not reader.isOpened():
            raise RuntimeError("تعذر فتح المقطع لقص الإطارات المتداخلة.")
        fps = reader.get(cv2.CAP_PROP_FPS) or self.cfg.fps
        width = int(reader.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(reader.get(cv2.CAP_PROP_FRAME_HEIGHT))
        writer = cv2.VideoWriter(str(output_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height))
        if not writer.isOpened():
            reader.release()
            raise RuntimeError("تعذر إنشاء المقطع بعد قص الإطارات.")
        try:
            for _ in range(skip_frames):
                if not reader.grab():
                    break
            while True:
                ok, frame = reader.read()
                if not ok:
                    break
                writer.write(frame)
        finally:
            reader.release()
            writer.release()
        if not output_path.exists():
            raise RuntimeError("فشل حفظ المقطع بعد قص التداخل.")

    def _concat_chunks(self, chunk_paths: list[Path], output_path: Path) -> None:
        ffmpeg = self._ffmpeg()
        with tempfile.TemporaryDirectory(prefix="nova_concat_") as temp_dir:
            concat_file = Path(temp_dir) / "concat.txt"
            lines = [f"file '{p.as_posix().replace("'", "'\\''")}'" for p in chunk_paths]
            concat_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
            command = [
                ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
                "-c:v", "libx264", "-preset", "medium", "-crf", "18",
                "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-threads", str(self.cfg.ffmpeg_threads),
                str(output_path),
            ]
            proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            if proc.returncode != 0 or not output_path.exists():
                raise RuntimeError(f"تعذر دمج المقاطع: {proc.stderr.decode('utf-8', errors='ignore')[-4000:]}")

    def _trim_to_duration(self, input_path: Path, output_path: Path, seconds: float) -> None:
        ffmpeg = self._ffmpeg()
        duration = max(0.1, float(seconds))
        command = [
            ffmpeg, "-y", "-i", str(input_path), "-t", f"{duration:.3f}",
            "-c:v", "libx264", "-preset", "medium", "-crf", "18",
            "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-threads", str(self.cfg.ffmpeg_threads),
            str(output_path),
        ]
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        if proc.returncode != 0 or not output_path.exists():
            raise RuntimeError(f"تعذر ضبط مدة الفيديو: {proc.stderr.decode('utf-8', errors='ignore')[-4000:]}")

    def _interpolate(self, input_path: Path, output_path: Path) -> None:
        if not self.cfg.use_interpolation or self.cfg.interpolation_fps <= self.cfg.fps:
            shutil.copy2(input_path, output_path)
            return
        ffmpeg = self._ffmpeg()
        filter_value = f"minterpolate=fps={self.cfg.interpolation_fps}:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1"
        command = [
            ffmpeg, "-y", "-i", str(input_path), "-vf", filter_value,
            "-c:v", "libx264", "-preset", "medium", "-crf", "18",
            "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-threads", str(self.cfg.ffmpeg_threads),
            str(output_path),
        ]
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        if proc.returncode != 0 or not output_path.exists():
            raise RuntimeError(f"تعذر تنفيذ interpolation: {proc.stderr.decode('utf-8', errors='ignore')[-4000:]}")

    def synthesize_xtts(
        self,
        text: str,
        output_path: Path,
        language: str | None = None,
        speaker_wav: str | None = None,
        speed: float = 1.0,
    ) -> Path:
        if TTS is None:
            raise RuntimeError("حزمة coqui-tts غير مثبتة؛ لا يمكن تشغيل XTTS-v2 المحلي.")
        language = (language or self.cfg.audio_language or "en").strip().lower()
        device, _ = self._device_dtype()
        key = (self.cfg.tts_model, device == "cuda")
        if key not in self._tts_cache:
            self._tts_cache[key] = TTS(self.cfg.tts_model, gpu=device == "cuda")
        model = self._tts_cache[key]
        kwargs: dict[str, Any] = {
            "text": text.strip(),
            "file_path": str(output_path),
            "language": language,
            "split_sentences": True,
        }
        if speaker_wav:
            kwargs["speaker_wav"] = [speaker_wav]
        else:
            kwargs["speaker"] = self.env.get("XTTS_DEFAULT_SPEAKER", "Ana Florence")
        model.tts_to_file(**kwargs)
        speed = max(0.5, min(2.0, float(speed)))
        if abs(speed - 1.0) > 0.001:
            ffmpeg = self._ffmpeg()
            adjusted = output_path.with_name(output_path.stem + "_speed.wav")
            tempo = speed
            filters: list[str] = []
            while tempo < 0.5:
                filters.append("atempo=0.5")
                tempo *= 2.0
            while tempo > 2.0:
                filters.append("atempo=2.0")
                tempo /= 2.0
            filters.append(f"atempo={tempo:g}")
            command = [ffmpeg, "-y", "-i", str(output_path), "-filter:a", ",".join(filters), str(adjusted)]
            proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            if proc.returncode != 0 or not adjusted.exists():
                raise RuntimeError("تعذر ضبط سرعة الصوت المحلي XTTS.")
            adjusted.replace(output_path)
        return output_path

    def apply_owned_overlay_cleanup(self, input_path: Path, output_path: Path, rectangles: list[dict[str, float]]) -> Path:
        """Clean only explicitly declared user-owned overlays.

        This function intentionally requires caller-provided normalized rectangles. It does not
        detect or remove arbitrary third-party watermarks or logos.
        """
        if not rectangles:
            shutil.copy2(input_path, output_path)
            return output_path
        if cv2 is None:
            raise RuntimeError("OpenCV مطلوب لمعالجة overlay المملوك.")
        reader = cv2.VideoCapture(str(input_path))
        if not reader.isOpened():
            raise RuntimeError("تعذر فتح الفيديو لتنظيف الـoverlay المملوك.")
        fps = reader.get(cv2.CAP_PROP_FPS) or self.cfg.fps
        width = int(reader.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(reader.get(cv2.CAP_PROP_FRAME_HEIGHT))
        codec = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(output_path), codec, fps, (width, height))
        if not writer.isOpened():
            reader.release()
            raise RuntimeError("تعذر إنشاء ملف الفيديو النهائي.")
        try:
            while True:
                ok, frame = reader.read()
                if not ok:
                    break
                mask = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) * 0
                for rect in rectangles:
                    x1 = max(0, min(width - 1, int(float(rect.get("x", 0.0)) * width)))
                    y1 = max(0, min(height - 1, int(float(rect.get("y", 0.0)) * height)))
                    x2 = max(x1 + 1, min(width, int((float(rect.get("x", 0.0)) + float(rect.get("w", 0.0))) * width)))
                    y2 = max(y1 + 1, min(height, int((float(rect.get("y", 0.0)) + float(rect.get("h", 0.0))) * height)))
                    mask[y1:y2, x1:x2] = 255
                if self.env.get("OWNED_OVERLAY_AUTO_DETECT", "0").lower() in {"1", "true", "yes", "on"}:
                    detected_mask = auto_corner_overlay_mask(frame)
                    mask = cv2.bitwise_or(mask, detected_mask)
                if mask.any():
                    frame = cv2.inpaint(frame, mask, 3, cv2.INPAINT_TELEA)
                writer.write(frame)
        finally:
            reader.release()
            writer.release()
        if not output_path.exists():
            raise RuntimeError("فشل إخراج الفيديو بعد overlay cleanup.")
        return output_path

    def mux_audio(self, video_path: Path, audio_path: Path, output_path: Path) -> Path:
        quality = MediaQualityEngine(self.work_root / "quality", self.env)
        return quality.master_audio_video(video_path, audio_path, output_path)

    def optional_lipsync(self, video_path: Path, audio_path: Path, output_path: Path) -> Path:
        engine = LipSyncOrchestrator(self.work_root / "lipsync", self.env)
        result = engine.synchronize(video_path, audio_path, output_path)
        return Path(str(result["path"]))

    def generate(
        self,
        prompt: str,
        total_seconds: int,
        width: int,
        height: int,
        seed: int | None = None,
        reference_image_path: str | None = None,
        narration_text: str | None = None,
        narration_language: str | None = None,
        speaker_wav_path: str | None = None,
        tts_speed: float = 1.0,
        progress: ProgressCallback | None = None,
    ) -> dict[str, Any]:
        if not prompt.strip():
            raise ValueError("وصف الفيديو لا يمكن أن يكون فارغًا.")
        total_seconds = int(total_seconds)
        if total_seconds < 1 or total_seconds > self.cfg.max_seconds:
            raise ValueError(f"المدة يجب أن تكون بين 1 و{self.cfg.max_seconds} ثانية.")
        seed = self.cfg.seed if seed is None else int(seed)
        run_id = uuid.uuid4().hex
        run_dir = self.work_root / f"long_video_{run_id}"
        run_dir.mkdir(parents=True, exist_ok=True)
        chunk_paths: list[Path] = []
        narration_audio: Path | None = None
        try:
            if narration_text and narration_text.strip():
                narration_audio = run_dir / "narration_raw.wav"
                self.synthesize_xtts(narration_text, narration_audio, narration_language, speaker_wav_path, tts_speed)
                mastered_audio = run_dir / "narration_master.wav"
                MediaQualityEngine(self.work_root / "quality", self.env).normalize_audio_for_lipsync(narration_audio, mastered_audio)
                narration_audio = mastered_audio
                audio_duration = MediaQualityEngine(self.work_root / "quality", self.env).duration_seconds(narration_audio)
                if audio_duration > total_seconds:
                    total_seconds = int(math.ceil(audio_duration))
                    if total_seconds > self.cfg.max_seconds:
                        raise ValueError(f"مدة التعليق الصوتي ({audio_duration:.1f}s) تتجاوز الحد الأقصى للمشروع ({self.cfg.max_seconds}s).")
            if reference_image_path:
                anchor = Image.open(reference_image_path).convert("RGB")
            else:
                try:
                    from controlled_generation import ControlledGenerationService
                    starter_service = ControlledGenerationService(self.work_root / "starter_models", self.env)
                    starter_bytes = starter_service.generate_flux(
                        prompt=prompt,
                        width=width,
                        height=height,
                        guidance_scale=self.cfg.guidance_scale,
                        steps=max(16, self.cfg.steps),
                        seed=seed,
                    )
                    starter_path = run_dir / "starter.png"
                    starter_path.write_bytes(starter_bytes)
                    anchor = Image.open(starter_path).convert("RGB")
                except Exception as exc:
                    raise RuntimeError(f"تعذر إنشاء الإطار الابتدائي تلقائيًا عبر Flux: {exc}") from exc
            effective_chunk_seconds = max(1, min(self.cfg.chunk_seconds, self.hardware.recommended_video_chunk_seconds))
            chunks = max(1, math.ceil(total_seconds / effective_chunk_seconds))
            for index in range(chunks):
                start_second = index * effective_chunk_seconds
                remaining = total_seconds - start_second
                chunk_seconds = min(effective_chunk_seconds, remaining)
                chunk_path = run_dir / f"chunk_{index:04d}.mp4"
                continuation = (
                    f"Continue the same shot seamlessly from the anchor frame. Maintain exact character identity, face, clothing, lighting, environment, camera style and color grade. "
                    f"Scene segment {index + 1}/{chunks}, target duration about {chunk_seconds} seconds. {prompt.strip()}"
                )
                overlap_extra = self.cfg.overlap_frames if index > 0 else 0
                self._generate_chunk(
                    continuation,
                    anchor,
                    chunk_path,
                    seed + index,
                    width,
                    height,
                    duration_seconds=chunk_seconds,
                    extra_frames=overlap_extra,
                )
                anchor = self._extract_last_frame(chunk_path)
                if index > 0 and self.cfg.overlap_frames > 0:
                    trimmed_path = run_dir / f"chunk_{index:04d}_trimmed.mp4"
                    skip_frames = min(
                        self.cfg.overlap_frames,
                        max(0, int(round(self.cfg.fps * chunk_seconds)) - 1),
                    )
                    self._trim_chunk_head(chunk_path, trimmed_path, skip_frames)
                    chunk_paths.append(trimmed_path)
                else:
                    chunk_paths.append(chunk_path)
                clear_device_memory()
                if progress:
                    progress(10 + int(((index + 1) / chunks) * 55), f"تم توليد المقطع {index + 1} من {chunks}")

            concatenated = run_dir / "concatenated.mp4"
            self._concat_chunks(chunk_paths, concatenated)
            if progress:
                progress(70, "تم دمج المقاطع مع الحفاظ على نقطة استمرارية لكل جزء")

            interpolated = run_dir / "interpolated.mp4"
            self._interpolate(concatenated, interpolated)
            if progress:
                progress(78, "تمت معالجة الإطارات لرفع سلاسة الحركة")

            duration_trimmed = run_dir / "duration_trimmed.mp4"
            self._trim_to_duration(interpolated, duration_trimmed, total_seconds)
            final_video = duration_trimmed
            if progress:
                progress(84, "تم تثبيت المدة النهائية بدقة قبل الصوت والمزامنة")
            if narration_audio is not None:
                lipsynced = run_dir / "lipsynced.mp4"
                sync_result = self.optional_lipsync(final_video, narration_audio, lipsynced)
                muxed = run_dir / "final_with_audio.mp4"
                self.mux_audio(sync_result, narration_audio, muxed)
                final_video = muxed
                if progress:
                    progress(92, "تمت مزامنة الشفاه محليًا ثم إخراج صوت Master بجودة 48kHz/320kbps")

            quality = MediaQualityEngine(self.work_root / "quality", self.env)
            cleaned = run_dir / "cleaned.mp4"
            quality.clean_generated_video(final_video, cleaned)
            final_video = cleaned
            if progress:
                progress(97, "تم تنظيف وإتقان الإخراج المرئي النهائي")

            result_path = run_dir / "result.mp4"
            shutil.copy2(final_video, result_path)
            if progress:
                progress(100, "اكتمل إنتاج الفيديو الطويل")
            return {
                "path": str(result_path),
                "mime_type": "video/mp4",
                "duration_seconds": total_seconds,
                "chunks": chunks,
                "fps": self.cfg.interpolation_fps if self.cfg.use_interpolation and self.cfg.interpolation_fps > self.cfg.fps else self.cfg.fps,
                "run_id": run_id,
                "hardware": {
                    "device": self.hardware.device,
                    "gpu": self.hardware.gpu_name,
                    "gpu_memory_gb": self.hardware.gpu_memory_gb,
                    "recommended_quantization": self.hardware.recommended_quantization,
                },
            }
        except Exception:
            raise


@lru_cache(maxsize=2)
def get_long_video_engine(work_root: str) -> UltraLongVideoEngine:
    return UltraLongVideoEngine(work_root)
