from __future__ import annotations

import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

EXPECTED = {
    ".github/workflows/build-apk.yml",
    "app.py",
    "android/settings.gradle",
    "android/build.gradle",
    "android/app/build.gradle",
    "android/app/src/main/AndroidManifest.xml",
}

FORBIDDEN_TEXT = [
    'android:usesCleartextTraffic="true"',
    'MIXED_CONTENT_COMPATIBILITY_MODE',
    'setAcceptThirdPartyCookies(webView, true)',
    'opencv-python-headless==4.5.1.48',
    'Pillow==9.2.0',
]

SECRET_PATTERNS = [
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    re.compile(r"(?i)\b(?:GROQ|POLLINATIONS)_API_KEY\s*=\s*[^\s#]{12,}"),
]

for rel in EXPECTED:
    path = ROOT / rel
    if not path.is_file():
        raise SystemExit(f"Missing required release file: {rel}")

# Only one workflow in the release package.
workflows = sorted((ROOT / ".github/workflows").glob("*.yml"))
workflows += sorted((ROOT / ".github/workflows").glob("*.yaml"))
if [p.name for p in workflows] != ["build-apk.yml"]:
    raise SystemExit(f"Unexpected workflows: {[p.name for p in workflows]}")

SELF = Path(__file__).resolve()
for path in ROOT.rglob("*"):
    if not path.is_file() or path.resolve() == SELF:
        continue
    if any(part in {".git", "__pycache__", ".pytest_cache"} for part in path.parts):
        raise SystemExit(f"Generated/cache content included: {path}")
    if path.suffix.lower() in {".pyc", ".pyo"}:
        raise SystemExit(f"Compiled Python bytecode included: {path}")
    if path.name == ".env":
        raise SystemExit("Real .env must never ship in the release archive")
    try:
        text = path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        continue
    for needle in FORBIDDEN_TEXT:
        if needle in text:
            raise SystemExit(f"Forbidden insecure setting/dependency found in {path}: {needle}")
    # The example env file is intentionally made of placeholders.
    if path.name != ".env.example":
        for line in text.splitlines():
            if "os.getenv(" in line or "st.secrets" in line or "GITHUB_TOKEN" in line:
                continue
            for pattern in SECRET_PATTERNS:
                if pattern.search(line):
                    raise SystemExit(f"Possible embedded secret found in {path}")

# Basic zip path traversal check for any local test archives.
for archive in ROOT.glob("*.zip"):
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            if name.startswith("/") or name.startswith("../") or "/../" in name or name == "..":
                raise SystemExit(f"Unsafe archive member path: {name}")

print("Release security/integrity checks: OK")
