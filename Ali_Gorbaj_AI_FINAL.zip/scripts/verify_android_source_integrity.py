from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = [
    "app.py",
    "hardware.py",
    "knowledge_engine.py",
    "controlled_generation.py",
    "long_video_engine.py",
    "lipsync.py",
    "task_queue.py",
    "omni_multimodal.py",
    "realtime_gateway.py",
    "swarm_orchestrator.py",
    "owned_media_cleanup.py",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


for name in FILES:
    path = ROOT / name
    if not path.is_file():
        raise SystemExit(f"Missing core source: {name}")
    print(f"{name}: {sha256(path)}")

print("Core source integrity check: OK")
