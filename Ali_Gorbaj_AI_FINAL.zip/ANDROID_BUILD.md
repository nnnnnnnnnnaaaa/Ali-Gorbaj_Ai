# Ali Gorbaj-AI — Standalone Android Runtime

هذه النسخة تضيف طبقة تشغيل Android فقط. تطبيق Streamlit الأساسي وملفات الذكاء الاصطناعي في جذر المشروع تُنسخ تلقائيًا إلى موارد APK عند البناء، ثم تُشغّل عبر Chaquopy على `localhost:8501` داخل عملية التطبيق.

## تجربة المستخدم

1. تثبيت APK.
2. فتح التطبيق.
3. يبدأ Python + Streamlit محليًا تلقائيًا.
4. يفتح WebView على `http://localhost:8501`.
5. لا توجد شاشة لإدخال URL ولا إعداد خادم للمستخدم.

## ما يتم تضمينه

- Python 3.10 runtime داخل APK عبر Chaquopy 17.
- Streamlit 1.65.0.
- حزمة Android المتوافقة من NumPy/Pandas/Pillow/OpenCV.
- SQLite/ملفات التطبيق داخل التخزين الداخلي للتطبيق.
- ChromaDB-compatible persistent local vector store.
- SentenceTransformer-compatible deterministic multilingual encoder للـRAG في وضع Android.
- PyMuPDF-compatible `fitz` adapter فوق pypdf لقراءة PDF.
- WebView camera/microphone/file chooser/download support.

## طبقة AI الأصلية على Android

يتضمن APK مكتبة ExecuTorch Android 1.5.1 مع XNNPACK، ويدعم تشغيل برامج `.pte` التي تم تصديرها والتحقق منها مسبقًا. توجد فئة `EdgeModelRuntime` لتشغيل هذه البرامج من Java، ويجري اختيار backend/برنامج Edge قبل البناء حسب الجهاز المستهدف.

أما PyTorch + Diffusers + Flux + CogVideoX بصيغها الكاملة الخاصة بسطح المكتب/Linux/CUDA فتبقى داخل محرك Python/CUDA الكامل في المشروع. لا يتم ادعاء تشغيل wheel CUDA المكتبي داخل Android؛ بدل ذلك يتم توفير مسار ExecuTorch الأصلي للنماذج التي يمكن تصديرها إلى edge.

## GitHub Actions

الملف `.github/workflows/android-apk.yml` يبني APK Release تلقائيًا، ونتيجة البناء تظهر في Actions كـArtifact باسم `Ali-Gorbaj-AI-Standalone-APK`.

## ملاحظات الأداء

- Streamlit يعمل محليًا، لذلك الاتصال بين الواجهة ومحرك Python داخل الهاتف لا يحتاج إنترنت.
- ميزات تعتمد على API خارجي تحتاج اتصالًا شبكيًا ومفاتيحها كما هو الحال في تطبيق سطح المكتب.
- كل بيانات التطبيق التي ينشئها Python تُكتب تحت `HOME` الخاص بالتطبيق، وبالتالي تبقى بعد إغلاقه وتختفي عند إلغاء تثبيت APK وفق نموذج تخزين Android.
